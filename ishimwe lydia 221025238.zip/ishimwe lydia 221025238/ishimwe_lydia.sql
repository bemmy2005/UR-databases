-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 05:45 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ishimwe lydia`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `lydi` ()  SELECT firstname FROM users WHERE firstname NOT IN(SELECT user_id FROM vaccination)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lydia` ()  UPDATE users set lastname='olga' WHERE user_id='6'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lydie` ()  DELETE from users  WHERE user_id='5'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pro` ()  INSERT INTO users VALUES('7','baidu','bizaza','223456')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `user_pro` ()  SELECT * from users$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `user_procedure` ()  SELECT* from users$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `vacc` ()  INSERT INTO vaccination VALUES('8','2','3','2')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `vaccin` ()  INSERT INTO vaccine VALUES('1','virus')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `vaccination` ()  SELECT* from vaccination$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `vaccin_pro` ()  SELECT * from vaccine$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `vacc_pro` ()  SELECT * from vaccination$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_info`
-- (See below for the actual view)
--
CREATE TABLE `all_info` (
`user_id` int(12)
,`firstname` varchar(100)
,`lastname` varchar(100)
,`nation_id` int(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `info`
-- (See below for the actual view)
--
CREATE TABLE `info` (
`user_id` int(12)
,`firstname` varchar(100)
,`lastname` varchar(100)
,`nation_id` int(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `ishimwe`
-- (See below for the actual view)
--
CREATE TABLE `ishimwe` (
`firstname` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `myview`
-- (See below for the actual view)
--
CREATE TABLE `myview` (
`firstname` varchar(100)
,`nation_id` int(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(12) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `nation_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `nation_id`) VALUES
(1, 'Ishimwe', 'Lydia', 221025238),
(2, 'Kanuma', 'Dylan', 221003422),
(3, 'Keza', 'Daisy', 221010320),
(4, 'Manzi', 'Samy', 224748361),
(5, 'Gasaro ', 'Stella', 224748364),
(6, 'Olga', 'Isengwe', 2245678);

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `ishimwe` AFTER UPDATE ON `users` FOR EACH ROW UPDATE users SET lastname='Bora' WHERE user_id='3'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `kanuma` AFTER DELETE ON `users` FOR EACH ROW DELETE FROM users WHERE user_id='3'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `lydia` AFTER INSERT ON `users` FOR EACH ROW INSERT into users VALUES('10','isimbi','nadine','223456')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `vacc`
-- (See below for the actual view)
--
CREATE TABLE `vacc` (
`vaccination_id` int(12)
,`user_id` int(12)
,`vaccine_id` int(12)
,`dosses` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vaccin`
-- (See below for the actual view)
--
CREATE TABLE `vaccin` (
`vaccine_id` int(12)
,`vaccine_name` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `vaccination`
--

CREATE TABLE `vaccination` (
  `vaccination_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `vaccine_id` int(12) NOT NULL,
  `dosses` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vaccination`
--

INSERT INTO `vaccination` (`vaccination_id`, `user_id`, `vaccine_id`, `dosses`) VALUES
(1, 1, 3, '3'),
(2, 2, 3, '2'),
(3, 3, 2, '2'),
(4, 4, 5, '1'),
(5, 5, 4, '3');

-- --------------------------------------------------------

--
-- Table structure for table `vaccine`
--

CREATE TABLE `vaccine` (
  `vaccine_id` int(12) NOT NULL,
  `vaccine_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vaccine`
--

INSERT INTO `vaccine` (`vaccine_id`, `vaccine_name`) VALUES
(2, 'Modern'),
(3, 'Astrazaneca'),
(4, 'Pfizer'),
(5, 'Johnson');

-- --------------------------------------------------------

--
-- Structure for view `all_info`
--
DROP TABLE IF EXISTS `all_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_info`  AS  select `users`.`user_id` AS `user_id`,`users`.`firstname` AS `firstname`,`users`.`lastname` AS `lastname`,`users`.`nation_id` AS `nation_id` from `users` ;

-- --------------------------------------------------------

--
-- Structure for view `info`
--
DROP TABLE IF EXISTS `info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `info`  AS  select `users`.`user_id` AS `user_id`,`users`.`firstname` AS `firstname`,`users`.`lastname` AS `lastname`,`users`.`nation_id` AS `nation_id` from `users` ;

-- --------------------------------------------------------

--
-- Structure for view `ishimwe`
--
DROP TABLE IF EXISTS `ishimwe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ishimwe`  AS  select `users`.`firstname` AS `firstname` from `users` where (not(`users`.`firstname` in (select `vaccination`.`user_id` from `vaccination`))) ;

-- --------------------------------------------------------

--
-- Structure for view `myview`
--
DROP TABLE IF EXISTS `myview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `myview`  AS  select `users`.`firstname` AS `firstname`,`users`.`nation_id` AS `nation_id` from `users` ;

-- --------------------------------------------------------

--
-- Structure for view `vacc`
--
DROP TABLE IF EXISTS `vacc`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vacc`  AS  select `vaccination`.`vaccination_id` AS `vaccination_id`,`vaccination`.`user_id` AS `user_id`,`vaccination`.`vaccine_id` AS `vaccine_id`,`vaccination`.`dosses` AS `dosses` from `vaccination` ;

-- --------------------------------------------------------

--
-- Structure for view `vaccin`
--
DROP TABLE IF EXISTS `vaccin`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vaccin`  AS  select `vaccine`.`vaccine_id` AS `vaccine_id`,`vaccine`.`vaccine_name` AS `vaccine_name` from `vaccine` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `vaccination`
--
ALTER TABLE `vaccination`
  ADD PRIMARY KEY (`vaccination_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `vaccine_id` (`vaccine_id`);

--
-- Indexes for table `vaccine`
--
ALTER TABLE `vaccine`
  ADD PRIMARY KEY (`vaccine_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `vaccination`
--
ALTER TABLE `vaccination`
  ADD CONSTRAINT `vaccination_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `vaccination_ibfk_2` FOREIGN KEY (`vaccine_id`) REFERENCES `vaccine` (`vaccine_id`),
  ADD CONSTRAINT `vaccination_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `vaccination_ibfk_4` FOREIGN KEY (`vaccine_id`) REFERENCES `vaccine` (`vaccine_id`),
  ADD CONSTRAINT `vaccination_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `vaccination_ibfk_6` FOREIGN KEY (`vaccine_id`) REFERENCES `vaccine` (`vaccine_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
