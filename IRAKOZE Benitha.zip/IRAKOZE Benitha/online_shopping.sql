-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 09:47 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_shopping`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `customerdetails` (IN `custID` INT(10), IN `Cust_name` VARCHAR(50), IN `cust_address` VARCHAR(100), IN `cust_telephone` INT(12), IN `cust_email` VARCHAR(30), IN `sellerID` INT(10), IN `prodID` INT(10), IN `paymentID` INT(10))  BEGIN
INSERT INTO customer VALUES(custID,Cust_name,cust_address,cust_telephone,cust_email,sellerID,prodID,paymentID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `data_update` ()  BEGIN
DELETE FROM `productdetails` WHERE prod_name=(SELECT (prodID=001) FROM product) ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deliverydetails` ()  BEGIN
    select * from delivery;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GETALLPROCEDURES` ()  BEGIN
    select * from customer, delivery, payment, product, seller;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `info_update` ()  BEGIN
UPDATE customerdetails SET `custID`='[value-2]';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `paymentdetails` ()  BEGIN
    select * from payment;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `productdetails` ()  BEGIN
    select * from product;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sellerdetails` ()  BEGIN
    select * from seller;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `custID` int(10) NOT NULL,
  `cust_name` varchar(50) NOT NULL,
  `cust_address` varchar(100) NOT NULL,
  `cust_telephone` int(12) NOT NULL,
  `cust_email` varchar(30) NOT NULL,
  `sellerID` int(10) NOT NULL,
  `prodID` int(10) NOT NULL,
  `paytID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`custID`, `cust_name`, `cust_address`, `cust_telephone`, `cust_email`, `sellerID`, `prodID`, `paytID`) VALUES
(0, 'abimana', 'kigali, gitega, you', 788888888, 'abimana12345@gmail.com', 1, 1, 1);

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `customerone` AFTER INSERT ON `customer` FOR EACH ROW BEGIN  
INSERT INTO customer VALUES (cust_name); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `delivery_ID` int(10) NOT NULL,
  `delivery_fee` varchar(10) NOT NULL,
  `cust_ID` int(10) NOT NULL,
  `prod_ID` int(10) NOT NULL,
  `seller_ID` int(10) NOT NULL,
  `paymentID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`delivery_ID`, `delivery_fee`, `cust_ID`, `prod_ID`, `seller_ID`, `paymentID`) VALUES
(1, '500', 1, 1, 1, 1);

--
-- Triggers `delivery`
--
DELIMITER $$
CREATE TRIGGER `deliveryone` AFTER UPDATE ON `delivery` FOR EACH ROW BEGIN  
UPDATE delivery set deliveryID='006'; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `fifthview`
-- (See below for the actual view)
--
CREATE TABLE `fifthview` (
`delivery_ID` int(10)
,`delivery_fee` varchar(10)
,`cust_ID` int(10)
,`prod_ID` int(10)
,`seller_ID` int(10)
,`paymentID` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `firstview`
-- (See below for the actual view)
--
CREATE TABLE `firstview` (
`sellerID` int(10)
,`seller_name` varchar(30)
,`seller_email` varchar(30)
,`seller_phone` varchar(12)
,`deliveryID` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `fourthview`
-- (See below for the actual view)
--
CREATE TABLE `fourthview` (
`paymentID` int(10)
,`payment_type` varchar(30)
,`sellerID` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentID` int(10) NOT NULL,
  `payment_type` varchar(30) NOT NULL,
  `sellerID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `paymentone` AFTER DELETE ON `payment` FOR EACH ROW BEGIN  
DELETE FROM payment WHERE paymentID='001'; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `paymenttwo` AFTER DELETE ON `payment` FOR EACH ROW BEGIN  
DELETE FROM payment WHERE paymentID='002'; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_ID` int(10) NOT NULL,
  `prod_name` varchar(30) NOT NULL,
  `prod_price` varchar(20) NOT NULL,
  `prod_location` varchar(30) NOT NULL,
  `prod_quantity` varchar(15) NOT NULL,
  `sellerID` int(10) NOT NULL,
  `paymentID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_ID`, `prod_name`, `prod_price`, `prod_location`, `prod_quantity`, `sellerID`, `paymentID`) VALUES
(1, 'sugar', '2500', 'kigali, kanombe, cyahafi', '1kg', 1, 1);

--
-- Triggers `product`
--
DELIMITER $$
CREATE TRIGGER `productone` AFTER UPDATE ON `product` FOR EACH ROW BEGIN  
UPDATE product set prodID='005'; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `producttwo` AFTER DELETE ON `product` FOR EACH ROW BEGIN  
DELETE FROM product WHERE productID='002'; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `secondview`
-- (See below for the actual view)
--
CREATE TABLE `secondview` (
`custID` int(10)
,`cust_name` varchar(50)
,`cust_address` varchar(100)
,`cust_telephone` int(12)
,`cust_email` varchar(30)
,`sellerID` int(10)
,`prodID` int(10)
,`paytID` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `sellerID` int(10) NOT NULL,
  `seller_name` varchar(30) NOT NULL,
  `seller_email` varchar(30) NOT NULL,
  `seller_phone` varchar(12) NOT NULL,
  `deliveryID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`sellerID`, `seller_name`, `seller_email`, `seller_phone`, `deliveryID`) VALUES
(0, 'Ruth', 'ruth12345@gmail.com', '0799999999', 0);

--
-- Triggers `seller`
--
DELIMITER $$
CREATE TRIGGER `sellerone` AFTER INSERT ON `seller` FOR EACH ROW BEGIN  
INSERT INTO seller VALUES (seller_name); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `thirdview`
-- (See below for the actual view)
--
CREATE TABLE `thirdview` (
`prod_ID` int(10)
,`prod_name` varchar(30)
,`prod_price` varchar(20)
,`prod_location` varchar(30)
,`prod_quantity` varchar(15)
,`sellerID` int(10)
,`paymentID` int(10)
);

-- --------------------------------------------------------

--
-- Structure for view `fifthview`
--
DROP TABLE IF EXISTS `fifthview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fifthview`  AS SELECT `delivery`.`delivery_ID` AS `delivery_ID`, `delivery`.`delivery_fee` AS `delivery_fee`, `delivery`.`cust_ID` AS `cust_ID`, `delivery`.`prod_ID` AS `prod_ID`, `delivery`.`seller_ID` AS `seller_ID`, `delivery`.`paymentID` AS `paymentID` FROM `delivery` ;

-- --------------------------------------------------------

--
-- Structure for view `firstview`
--
DROP TABLE IF EXISTS `firstview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `firstview`  AS SELECT `seller`.`sellerID` AS `sellerID`, `seller`.`seller_name` AS `seller_name`, `seller`.`seller_email` AS `seller_email`, `seller`.`seller_phone` AS `seller_phone`, `seller`.`deliveryID` AS `deliveryID` FROM `seller` ;

-- --------------------------------------------------------

--
-- Structure for view `fourthview`
--
DROP TABLE IF EXISTS `fourthview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fourthview`  AS SELECT `payment`.`paymentID` AS `paymentID`, `payment`.`payment_type` AS `payment_type`, `payment`.`sellerID` AS `sellerID` FROM `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `secondview`
--
DROP TABLE IF EXISTS `secondview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `secondview`  AS SELECT `customer`.`custID` AS `custID`, `customer`.`cust_name` AS `cust_name`, `customer`.`cust_address` AS `cust_address`, `customer`.`cust_telephone` AS `cust_telephone`, `customer`.`cust_email` AS `cust_email`, `customer`.`sellerID` AS `sellerID`, `customer`.`prodID` AS `prodID`, `customer`.`paytID` AS `paytID` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `thirdview`
--
DROP TABLE IF EXISTS `thirdview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `thirdview`  AS SELECT `product`.`prod_ID` AS `prod_ID`, `product`.`prod_name` AS `prod_name`, `product`.`prod_price` AS `prod_price`, `product`.`prod_location` AS `prod_location`, `product`.`prod_quantity` AS `prod_quantity`, `product`.`sellerID` AS `sellerID`, `product`.`paymentID` AS `paymentID` FROM `product` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`custID`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`delivery_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`sellerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `custID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `delivery_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `prod_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `sellerID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
