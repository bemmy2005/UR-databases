-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 11:21 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_car_rental_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', 'admin', '2022-07-26 14:27:20'),
(3, 'bwimba', 'qwerty', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `admininfo`
-- (See below for the actual view)
--
CREATE TABLE `admininfo` (
`id` int(11)
,`UserName` varchar(100)
,`Password` varchar(100)
,`updationDate` timestamp
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `bookinginfo`
-- (See below for the actual view)
--
CREATE TABLE `bookinginfo` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `brandsinfo`
-- (See below for the actual view)
--
CREATE TABLE `brandsinfo` (
`id` int(11)
,`BrandName` varchar(120)
,`CreationDate` timestamp
,`UpdationDate` timestamp
);

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `id` int(11) NOT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `VehicleId` int(11) DEFAULT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `userEmail`, `VehicleId`, `FromDate`, `ToDate`, `message`, `PostingDate`) VALUES
(4, 'bwanakwelileon58@gmail.com', 1, '2022-07-25', '2022-07-30', 'very good car', '2022-07-26 18:03:49');

-- --------------------------------------------------------

--
-- Table structure for table `tblbrands`
--

CREATE TABLE `tblbrands` (
  `id` int(11) NOT NULL,
  `BrandName` varchar(120) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbrands`
--

INSERT INTO `tblbrands` (`id`, `BrandName`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Land Rover', '2022-07-25 22:00:00', '2022-07-26 18:11:32'),
(2, 'BMW', '2022-07-25 22:00:00', '2022-07-26 18:11:32'),
(3, 'Audi', '2022-07-25 22:00:00', '2022-07-26 18:11:32'),
(4, 'Nissan', '2022-07-25 22:00:00', '2022-07-26 18:11:32'),
(5, 'Toyota', '2022-07-25 22:00:00', '2022-07-26 18:11:32');

--
-- Triggers `tblbrands`
--
DELIMITER $$
CREATE TRIGGER `brand_information` AFTER INSERT ON `tblbrands` FOR EACH ROW INSERT INTO brand_information VALUES(1,’tesla’)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbltestimonial`
--

CREATE TABLE `tbltestimonial` (
  `id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `Testimonial` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltestimonial`
--

INSERT INTO `tbltestimonial` (`id`, `UserId`, `Testimonial`, `PostingDate`) VALUES
(1, 0, 'Test Test', '2022-07-27 07:44:31');

--
-- Triggers `tbltestimonial`
--
DELIMITER $$
CREATE TRIGGER `information_testimonial` BEFORE INSERT ON `tbltestimonial` FOR EACH ROW INSERT INTO admin_information VALUES(1,1,’testing’)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `UserId` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`UserId`, `FullName`, `Email`, `Password`, `ContactNo`, `dob`, `Address`, `City`, `Country`, `RegDate`, `UpdationDate`) VALUES
(6, 'Bwanakweli leon', 'bwanakwelileon58@gmail.com', 'b955be1ce7a007cf1da8a087cfdf693b', '0781107668', NULL, NULL, NULL, NULL, '2022-07-26 11:51:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblvehicles`
--

CREATE TABLE `tblvehicles` (
  `vehicleId` int(11) NOT NULL,
  `VehiclesTitle` varchar(150) DEFAULT NULL,
  `VehiclesBrand` int(11) DEFAULT NULL,
  `VehiclesOverview` longtext DEFAULT NULL,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `Vimage` varchar(120) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblvehicles`
--

INSERT INTO `tblvehicles` (`vehicleId`, `VehiclesTitle`, `VehiclesBrand`, `VehiclesOverview`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `Vimage`, `RegDate`, `UpdationDate`) VALUES
(3, 'Avanza', 4, 'Nissan Avanza, All new Nissan Avanza ready to go for a trip with this new ride', 563, 'CNG', 2012, 5, 'featured-img-3.jpg', '2017-06-19 16:18:20', '2019-03-22 13:59:52'),
(5, 'Carrera GT', 5, 'Carrera Gt go have a thrilling trip with this Carrera Gt', 345345, 'Petrol', 3453, 7, 'car_755x430.png', '2022-07-20 17:57:09', '2022-08-22 14:00:15');

-- --------------------------------------------------------

--
-- Structure for view `admininfo`
--
DROP TABLE IF EXISTS `admininfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admininfo`  AS SELECT `admin`.`id` AS `id`, `admin`.`UserName` AS `UserName`, `admin`.`Password` AS `Password`, `admin`.`updationDate` AS `updationDate` FROM `admin` ;

-- --------------------------------------------------------

--
-- Structure for view `bookinginfo`
--
DROP TABLE IF EXISTS `bookinginfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bookinginfo`  AS SELECT `tblbooking`.`id` AS `id`, `tblbooking`.`userEmail` AS `userEmail`, `tblbooking`.`VehicleId` AS `VehicleId`, `tblbooking`.`FromDate` AS `FromDate`, `tblbooking`.`ToDate` AS `ToDate`, `tblbooking`.`message` AS `message`, `tblbooking`.`Status` AS `Status`, `tblbooking`.`PostingDate` AS `PostingDate` FROM `tblbooking` ;

-- --------------------------------------------------------

--
-- Structure for view `brandsinfo`
--
DROP TABLE IF EXISTS `brandsinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `brandsinfo`  AS SELECT `tblbrands`.`id` AS `id`, `tblbrands`.`BrandName` AS `BrandName`, `tblbrands`.`CreationDate` AS `CreationDate`, `tblbrands`.`UpdationDate` AS `UpdationDate` FROM `tblbrands` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbrands`
--
ALTER TABLE `tblbrands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`UserId`);

--
-- Indexes for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  ADD PRIMARY KEY (`vehicleId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblbrands`
--
ALTER TABLE `tblbrands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  MODIFY `vehicleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
