-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 27, 2022 at 09:48 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `patient_management_system`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `add_patient`
--
CREATE TABLE IF NOT EXISTS `add_patient` (
`P_id` int(2)
,`F_name` varchar(25)
,`L_name` varchar(25)
,`Gender` varchar(25)
,`Disease_type` varchar(25)
,`Ad_id#` int(30)
,`n_id#` int(30)
,`t_id#` int(30)
,`m_id#` int(30)
,`d_id#` int(30)
);
-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `Ad_id` int(20) NOT NULL,
  `F_name` varchar(30) DEFAULT NULL,
  `L_name` varchar(30) DEFAULT NULL,
  `phone_number` varchar(30) DEFAULT NULL,
  `m_id` int(30) NOT NULL,
  `n_id` int(30) NOT NULL,
  `t_id` int(30) DEFAULT NULL,
  PRIMARY KEY (`Ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Ad_id`, `F_name`, `L_name`, `phone_number`, `m_id`, `n_id`, `t_id`) VALUES
(0, 'NYIRIMANZI', 'Michelle', '0782134901', 0, 0, 0),
(2, 'muhiga', 'charmant', '0788200213', 3, 4, 5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `check_doctor`
--
CREATE TABLE IF NOT EXISTS `check_doctor` (
`D_id` int(30)
,`F_name` varchar(30)
,`L_name` varchar(30)
,`Gender` varchar(30)
,`Specialisation_type` varchar(30)
,`Hospital_name` varchar(30)
,`m_id` int(30)
,`n_id` int(30)
,`t_id` int(30)
);
-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `D_id` int(30) NOT NULL AUTO_INCREMENT,
  `F_name` varchar(30) DEFAULT NULL,
  `L_name` varchar(30) DEFAULT NULL,
  `Gender` varchar(30) DEFAULT NULL,
  `Specialisation_type` varchar(30) DEFAULT NULL,
  `Hospital_name` varchar(30) DEFAULT NULL,
  `m_id` int(30) NOT NULL,
  `n_id` int(30) NOT NULL,
  `t_id` int(30) NOT NULL,
  PRIMARY KEY (`D_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`D_id`, `F_name`, `L_name`, `Gender`, `Specialisation_type`, `Hospital_name`, `m_id`, `n_id`, `t_id`) VALUES
(1, 'norah', 'Gregg', 'female', 'dentist', 'ruhengeri-hospital', 0, 0, 0),
(3, 'muhizi', 'chance', 'male', 'dentist', 'ruhengeri_hospital', 4, 5, 6);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_nurse`
--
CREATE TABLE IF NOT EXISTS `get_nurse` (
`n_id` int(30)
,`nurse_full,name` varchar(30)
,`work_department` varchar(30)
,`hosp_namepatient_from` varchar(30)
,`hosp_namepatient_tranfered` varchar(30)
,`gender` varchar(30)
,`date_sign_transfer` date
,`m_id#` int(30)
,`p_id#` int(30)
,`t_id#` int(30)
,`d_id#` int(30)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `listadmin`
--
CREATE TABLE IF NOT EXISTS `listadmin` (
`Ad_id` int(20)
,`F_name` varchar(30)
,`L_name` varchar(30)
,`phone_number` varchar(30)
,`m_id` int(30)
,`n_id` int(30)
,`t_id` int(30)
);
-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE IF NOT EXISTS `medicine` (
  `m_id` int(30) NOT NULL,
  `med_name` varchar(30) NOT NULL,
  `manufactured_date` date NOT NULL,
  `expired_date` date NOT NULL,
  `med_descript` varchar(30) NOT NULL,
  `d_id#` int(30) NOT NULL,
  `p_id` int(30) NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`m_id`, `med_name`, `manufactured_date`, `expired_date`, `med_descript`, `d_id#`, `p_id`) VALUES
(1, 'prephen', '2022-07-15', '2022-07-27', 'fourth_times', 2, 3),
(5, 'mizero_kenthia', '0000-00-00', '0000-00-00', 'lunette', 6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `nursing`
--

CREATE TABLE IF NOT EXISTS `nursing` (
  `n_id` int(30) NOT NULL,
  `nurse_full,name` varchar(30) NOT NULL,
  `work_department` varchar(30) NOT NULL,
  `hosp_namepatient_from` varchar(30) NOT NULL,
  `hosp_namepatient_tranfered` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `date_sign_transfer` date NOT NULL,
  `m_id#` int(30) NOT NULL,
  `p_id#` int(30) NOT NULL,
  `t_id#` int(30) NOT NULL,
  `d_id#` int(30) NOT NULL,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nursing`
--

INSERT INTO `nursing` (`n_id`, `nurse_full,name`, `work_department`, `hosp_namepatient_from`, `hosp_namepatient_tranfered`, `gender`, `date_sign_transfer`, `m_id#`, `p_id#`, `t_id#`, `d_id#`) VALUES
(1, 'muhirwa_jean', 'mology', '0', 'ruhengeri_hospital', 'male', '2022-07-07', 2, 3, 4, 5),
(2, 'muhirwa_jean', 'pediatry', '0', 'ruhengeri_hospital', 'male', '2022-07-07', 3, 4, 5, 8),
(6, 'ikirezi_olah', 'therapy', 'muhoza_health_center', 'kinyinya_hospital', 'female', '0000-00-00', 7, 8, 9, 2);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `P_id` int(2) NOT NULL AUTO_INCREMENT,
  `F_name` varchar(25) DEFAULT NULL,
  `L_name` varchar(25) DEFAULT NULL,
  `Gender` varchar(25) DEFAULT NULL,
  `Disease_type` varchar(25) DEFAULT NULL,
  `Ad_id#` int(30) NOT NULL,
  `n_id#` int(30) NOT NULL,
  `t_id#` int(30) NOT NULL,
  `m_id#` int(30) NOT NULL,
  `d_id#` int(30) NOT NULL,
  PRIMARY KEY (`P_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`P_id`, `F_name`, `L_name`, `Gender`, `Disease_type`, `Ad_id#`, `n_id#`, `t_id#`, `m_id#`, `d_id#`) VALUES
(1, 'hirwa', 'parfune', 'male', 'eyes', 2, 3, 4, 5, 6),
(7, 'hirwa', 'analyse', 'female', 'skin_rush', 7, 8, 9, 2, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `record_medicine`
--
CREATE TABLE IF NOT EXISTS `record_medicine` (
`m_id` int(30)
,`med_name` varchar(30)
,`manufactured_date` date
,`expired_date` date
,`med_descript` varchar(30)
,`d_id#` int(30)
,`p_id` int(30)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `sign_transfer`
--
CREATE TABLE IF NOT EXISTS `sign_transfer` (
`t_id` int(30)
,`referral-hosp` varchar(30)
,`date` date
,`hosp_from` varchar(30)
,`hosp_to` varchar(30)
,`p_id#` int(30)
,`n_id#` int(30)
,`d_id#` int(30)
,`Ad_id#` int(30)
);
-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE IF NOT EXISTS `transfer` (
  `t_id` int(30) NOT NULL,
  `referral-hosp` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `hosp_from` varchar(30) NOT NULL,
  `hosp_to` varchar(30) NOT NULL,
  `p_id#` int(30) NOT NULL,
  `n_id#` int(30) NOT NULL,
  `d_id#` int(30) NOT NULL,
  `Ad_id#` int(30) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transfer`
--

INSERT INTO `transfer` (`t_id`, `referral-hosp`, `date`, `hosp_from`, `hosp_to`, `p_id#`, `n_id#`, `d_id#`, `Ad_id#`) VALUES
(1, 'hospital_kinyinya', '2022-07-20', 'muhoza_health_center', 'chk', 2, 3, 4, 5);

-- --------------------------------------------------------

--
-- Structure for view `add_patient`
--
DROP TABLE IF EXISTS `add_patient`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `add_patient` AS select `patient`.`P_id` AS `P_id`,`patient`.`F_name` AS `F_name`,`patient`.`L_name` AS `L_name`,`patient`.`Gender` AS `Gender`,`patient`.`Disease_type` AS `Disease_type`,`patient`.`Ad_id#` AS `Ad_id#`,`patient`.`n_id#` AS `n_id#`,`patient`.`t_id#` AS `t_id#`,`patient`.`m_id#` AS `m_id#`,`patient`.`d_id#` AS `d_id#` from `patient`;

-- --------------------------------------------------------

--
-- Structure for view `check_doctor`
--
DROP TABLE IF EXISTS `check_doctor`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `check_doctor` AS select `doctor`.`D_id` AS `D_id`,`doctor`.`F_name` AS `F_name`,`doctor`.`L_name` AS `L_name`,`doctor`.`Gender` AS `Gender`,`doctor`.`Specialisation_type` AS `Specialisation_type`,`doctor`.`Hospital_name` AS `Hospital_name`,`doctor`.`m_id` AS `m_id`,`doctor`.`n_id` AS `n_id`,`doctor`.`t_id` AS `t_id` from `doctor`;

-- --------------------------------------------------------

--
-- Structure for view `get_nurse`
--
DROP TABLE IF EXISTS `get_nurse`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_nurse` AS select `nursing`.`n_id` AS `n_id`,`nursing`.`nurse_full,name` AS `nurse_full,name`,`nursing`.`work_department` AS `work_department`,`nursing`.`hosp_namepatient_from` AS `hosp_namepatient_from`,`nursing`.`hosp_namepatient_tranfered` AS `hosp_namepatient_tranfered`,`nursing`.`gender` AS `gender`,`nursing`.`date_sign_transfer` AS `date_sign_transfer`,`nursing`.`m_id#` AS `m_id#`,`nursing`.`p_id#` AS `p_id#`,`nursing`.`t_id#` AS `t_id#`,`nursing`.`d_id#` AS `d_id#` from `nursing`;

-- --------------------------------------------------------

--
-- Structure for view `listadmin`
--
DROP TABLE IF EXISTS `listadmin`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listadmin` AS select `admin`.`Ad_id` AS `Ad_id`,`admin`.`F_name` AS `F_name`,`admin`.`L_name` AS `L_name`,`admin`.`phone_number` AS `phone_number`,`admin`.`m_id` AS `m_id`,`admin`.`n_id` AS `n_id`,`admin`.`t_id` AS `t_id` from `admin`;

-- --------------------------------------------------------

--
-- Structure for view `record_medicine`
--
DROP TABLE IF EXISTS `record_medicine`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `record_medicine` AS select `medicine`.`m_id` AS `m_id`,`medicine`.`med_name` AS `med_name`,`medicine`.`manufactured_date` AS `manufactured_date`,`medicine`.`expired_date` AS `expired_date`,`medicine`.`med_descript` AS `med_descript`,`medicine`.`d_id#` AS `d_id#`,`medicine`.`p_id` AS `p_id` from `medicine`;

-- --------------------------------------------------------

--
-- Structure for view `sign_transfer`
--
DROP TABLE IF EXISTS `sign_transfer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sign_transfer` AS select `transfer`.`t_id` AS `t_id`,`transfer`.`referral-hosp` AS `referral-hosp`,`transfer`.`date` AS `date`,`transfer`.`hosp_from` AS `hosp_from`,`transfer`.`hosp_to` AS `hosp_to`,`transfer`.`p_id#` AS `p_id#`,`transfer`.`n_id#` AS `n_id#`,`transfer`.`d_id#` AS `d_id#`,`transfer`.`Ad_id#` AS `Ad_id#` from `transfer`;
