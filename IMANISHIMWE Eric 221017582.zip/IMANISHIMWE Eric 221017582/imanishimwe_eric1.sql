-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 11:14 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imanishimwe_eric1`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteCars` (IN `car_idParam` VARCHAR(30))  BEGIN
    delete from cars_tbl where car_idD=car_idParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteemployee` (IN `employee_idParam` INT(30))  BEGIN
    delete from employee where employee_id=employee_idParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCars` ()  BEGIN
    select * from cars_tbl;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcustomers` ()  BEGIN
    select * from customer_register;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getemployee` ()  BEGIN
    select * from employee;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getlogin_account` ()  BEGIN
    select * from login_account;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getoffering` ()  BEGIN
    select * from offering_car;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getpayementt` ()  BEGIN
    select * from paymentt;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getreturning` ()  BEGIN
    select * from returning_car;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertcars` (IN `car_idParam` INT(50), `carnameParam` VARCHAR(50), `car_typeparam` VARCHAR(50), `car_priceparam` INT(50))  BEGIN
    insert into cars_tbl values (car_idParam,carnameParam,car_typeparam,car_priceparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertcustomers` (IN `customer_idParam` INT(50), `firstnameParam` VARCHAR(50), `lastnameparam` VARCHAR(50), `genderparam` VARCHAR(50), `birth_dateparam` DATE, `locationparam` VARCHAR(50))  BEGIN
    insert into customer_register values (customer_idParam,firstnameParam,lastnameparam,genderparam,birth_dateparam,locationparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertemployee` (IN `employee_idParam` INT(50), `firstnameParam` VARCHAR(50), `lastnameparam` VARCHAR(50), `telephoneparam` INT(50), `addressParam` VARCHAR(50), `emailParam` VARCHAR(50), `roleparam` VARCHAR(50))  BEGIN
    insert into employee values (employee_idParam,firstnameParam,lastnameparam,telephoneparam,addressParam,emailParam,roleparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertloginaccount` (IN `login_idParam` INT(50), `usernameParam` VARCHAR(50), `passwordParam` VARCHAR(50))  BEGIN
    insert into login_account values (login_idParam,usernameParam,passwordParam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertlogin_account` (IN `login_idParam` INT(50), `usernameParam` VARCHAR(50), `passwordParam` VARCHAR(50))  BEGIN
    insert into login_account values (login_idParam,usernameParam,passwordParam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertoffering` (IN `offer_idParam` INT(50), `car_idParam` INT(50), `offerered_dateparam` DATE, `return_dateparam` DATE, `customer_idparam` INT(50))  BEGIN
    insert into offering_car values (offer_idParam,car_idParam,offerered_dateparam,return_dateparam,customer_idparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertreturning` (IN `return_idParam` INT(50), `car_idParam` INT(50), `offerered_dateparam` DATE, `return_dateparam` DATE, `customer_idparam` INT(50))  BEGIN
    insert into returning_car values (return_idParam,car_idParam,offerered_dateparam,return_dateparam,customer_idparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserttaxation` (IN `tax_idParam` INT(50), `tax_decaralationParam` TEXT, `amount_payedparam` INT(50), `date_payedparam` DATE)  BEGIN
    insert into taxation values (tax_idParam,tax_decaralationParam,amount_payedparam,date_payedparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCars` (IN `car_idParam` VARCHAR(30))  BEGIN
    update cars_tbl set car_amount=car_amount+1000 where car_id=car_idParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatetaxation` (IN `tax_idParam` VARCHAR(50))  BEGIN
    update taxation set amount_payed=amount_payed-1000 where tax_id=tax_idParam;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cars_tbl`
--

CREATE TABLE `cars_tbl` (
  `car_id` int(50) NOT NULL,
  `car_name` varchar(50) NOT NULL,
  `car_type` varchar(50) NOT NULL,
  `car_amount` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars_tbl`
--

INSERT INTO `cars_tbl` (`car_id`, `car_name`, `car_type`, `car_amount`) VALUES
(1, 'V8', 'TOYOTA', 200000),
(2, 'VOITIRE', 'TOYOTA', 150000),
(3, 'langlover', 'toyota', 100000),
(4, 'Audi', 'Sharp', 200000);

--
-- Triggers `cars_tbl`
--
DELIMITER $$
CREATE TRIGGER `deleteAlert` AFTER DELETE ON `cars_tbl` FOR EACH ROW BEGIN  
DELETE FROM cars_tbl; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer_register`
--

CREATE TABLE `customer_register` (
  `customer_id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `birth_date` date NOT NULL,
  `location` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_register`
--

INSERT INTO `customer_register` (`customer_id`, `firstname`, `lastname`, `gender`, `birth_date`, `location`) VALUES
(1, 'HIRWA', 'Herve', 'M', '1990-07-12', 'GASABO'),
(2, 'KASANDE', 'Betty', 'F', '1998-07-20', 'KAYONZA'),
(3, 'BERWA', 'Eric', 'M', '2000-07-27', 'RUBAVU'),
(4, 'Audi', 'Sharp', 'M', '2002-07-09', 'gakenke');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `telephone` int(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `firstname`, `lastname`, `telephone`, `address`, `email`, `role`) VALUES
(1, 'MUNEZA', 'Richard', 0, 'muneza@gmail.com', '0787994855', 'GISAGARA'),
(2, 'MUKUNZI', 'Mourice', 787994855, 'GISAGARA', 'mourice@gmail.com', 'administrator'),
(3, 'Audi', 'Sharp', 784332503, 'kicukiro', 'audi@gmail.com', 'HR');

-- --------------------------------------------------------

--
-- Table structure for table `enrollement`
--

CREATE TABLE `enrollement` (
  `enroll_id` int(50) NOT NULL,
  `car_id` int(50) NOT NULL,
  `customer_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enrollement`
--

INSERT INTO `enrollement` (`enroll_id`, `car_id`, `customer_id`) VALUES
(3, 1, 1),
(4, 2, 2);

--
-- Triggers `enrollement`
--
DELIMITER $$
CREATE TRIGGER `insertenrollement` AFTER INSERT ON `enrollement` FOR EACH ROW BEGIN  
INSERT INTO enrollement VALUES (NULL, '1', '1');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `listcars`
-- (See below for the actual view)
--
CREATE TABLE `listcars` (
`car_id` int(50)
,`car_name` varchar(50)
,`car_type` varchar(50)
,`car_amount` int(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listcustomers`
-- (See below for the actual view)
--
CREATE TABLE `listcustomers` (
`customer_id` int(50)
,`firstname` varchar(50)
,`lastname` varchar(50)
,`gender` varchar(50)
,`birth_date` date
,`location` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listemployee`
-- (See below for the actual view)
--
CREATE TABLE `listemployee` (
`employee_id` int(50)
,`firstname` varchar(50)
,`lastname` varchar(50)
,`telephone` int(50)
,`address` varchar(50)
,`email` varchar(50)
,`role` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listenrollement`
-- (See below for the actual view)
--
CREATE TABLE `listenrollement` (
`enroll_id` int(50)
,`car_id` int(50)
,`customer_id` int(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listlogin_account`
-- (See below for the actual view)
--
CREATE TABLE `listlogin_account` (
`login_id` int(50)
,`username` varchar(50)
,`password` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listoffered`
-- (See below for the actual view)
--
CREATE TABLE `listoffered` (
`offer_id` int(50)
,`car_id` int(50)
,`offerered_date` date
,`return_date` date
,`customer_id` int(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listreturns`
-- (See below for the actual view)
--
CREATE TABLE `listreturns` (
`return_id` int(50)
,`car_id` int(50)
,`offerered_date` date
,`return_date` date
,`customer_id` int(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listtax`
-- (See below for the actual view)
--
CREATE TABLE `listtax` (
`tax_id` int(50)
,`tax_decaralation` text
,`amount_payed` int(50)
,`date_payed` date
);

-- --------------------------------------------------------

--
-- Table structure for table `login_account`
--

CREATE TABLE `login_account` (
  `login_id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_account`
--

INSERT INTO `login_account` (`login_id`, `username`, `password`) VALUES
(1, 'eric', 'eric12'),
(2, 'MUGISHA', 'Jules');

--
-- Triggers `login_account`
--
DELIMITER $$
CREATE TRIGGER `insertinglogin_account` AFTER INSERT ON `login_account` FOR EACH ROW BEGIN  
INSERT INTO login_account VALUES (NULL, 'eric', 'eric12');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `offering_car`
--

CREATE TABLE `offering_car` (
  `offer_id` int(50) NOT NULL,
  `car_id` int(50) NOT NULL,
  `offerered_date` date NOT NULL,
  `return_date` date NOT NULL,
  `customer_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offering_car`
--

INSERT INTO `offering_car` (`offer_id`, `car_id`, `offerered_date`, `return_date`, `customer_id`) VALUES
(1, 1, '2022-07-30', '2022-08-29', 1),
(2, 3, '2022-07-27', '2022-08-20', 2),
(3, 2, '2022-07-04', '2022-08-04', 1);

--
-- Triggers `offering_car`
--
DELIMITER $$
CREATE TRIGGER `insertupdate` AFTER INSERT ON `offering_car` FOR EACH ROW BEGIN  
update counters set offer_id=offer_id+1; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_id` int(50) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `date_payed` date NOT NULL,
  `amount` int(50) NOT NULL,
  `momo_account` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_id`, `customer_id`, `date_payed`, `amount`, `momo_account`) VALUES
(1, 2, '2022-07-30', 200000, 787994855);

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `insertAlert` AFTER INSERT ON `payment` FOR EACH ROW BEGIN  
update counters set amount=amount+1; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `returning_car`
--

CREATE TABLE `returning_car` (
  `return_id` int(50) NOT NULL,
  `car_id` int(50) NOT NULL,
  `offerered_date` date NOT NULL,
  `return_date` date NOT NULL,
  `customer_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returning_car`
--

INSERT INTO `returning_car` (`return_id`, `car_id`, `offerered_date`, `return_date`, `customer_id`) VALUES
(1, 1, '2022-07-29', '2022-08-28', 2),
(2, 1, '2022-07-27', '2022-08-29', 1),
(3, 2, '2022-07-04', '2022-08-04', 1);

--
-- Triggers `returning_car`
--
DELIMITER $$
CREATE TRIGGER `deleteAlert1` AFTER DELETE ON `returning_car` FOR EACH ROW BEGIN  
DELETE FROM returning_car; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `taxation`
--

CREATE TABLE `taxation` (
  `tax_id` int(50) NOT NULL,
  `tax_decaralation` text NOT NULL,
  `amount_payed` int(50) NOT NULL,
  `date_payed` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxation`
--

INSERT INTO `taxation` (`tax_id`, `tax_decaralation`, `amount_payed`, `date_payed`) VALUES
(1, 'THE TAX Is for the products that sold in year of 2020', 20000, '2022-07-21'),
(2, 'Tax added value is baesd on sold products', 100000, '2022-07-28'),
(3, 'Audi suppose to pay anual tax', 100000, '2022-07-04');

--
-- Triggers `taxation`
--
DELIMITER $$
CREATE TRIGGER `insertmodifiy` AFTER INSERT ON `taxation` FOR EACH ROW BEGIN  
update counters set amount_payed=amount_payed=+1; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `listcars`
--
DROP TABLE IF EXISTS `listcars`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listcars`  AS  select `cars_tbl`.`car_id` AS `car_id`,`cars_tbl`.`car_name` AS `car_name`,`cars_tbl`.`car_type` AS `car_type`,`cars_tbl`.`car_amount` AS `car_amount` from `cars_tbl` ;

-- --------------------------------------------------------

--
-- Structure for view `listcustomers`
--
DROP TABLE IF EXISTS `listcustomers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listcustomers`  AS  select `customer_register`.`customer_id` AS `customer_id`,`customer_register`.`firstname` AS `firstname`,`customer_register`.`lastname` AS `lastname`,`customer_register`.`gender` AS `gender`,`customer_register`.`birth_date` AS `birth_date`,`customer_register`.`location` AS `location` from `customer_register` ;

-- --------------------------------------------------------

--
-- Structure for view `listemployee`
--
DROP TABLE IF EXISTS `listemployee`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listemployee`  AS  select `employee`.`employee_id` AS `employee_id`,`employee`.`firstname` AS `firstname`,`employee`.`lastname` AS `lastname`,`employee`.`telephone` AS `telephone`,`employee`.`address` AS `address`,`employee`.`email` AS `email`,`employee`.`role` AS `role` from `employee` ;

-- --------------------------------------------------------

--
-- Structure for view `listenrollement`
--
DROP TABLE IF EXISTS `listenrollement`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listenrollement`  AS  select `enrollement`.`enroll_id` AS `enroll_id`,`enrollement`.`car_id` AS `car_id`,`enrollement`.`customer_id` AS `customer_id` from `enrollement` ;

-- --------------------------------------------------------

--
-- Structure for view `listlogin_account`
--
DROP TABLE IF EXISTS `listlogin_account`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listlogin_account`  AS  select `login_account`.`login_id` AS `login_id`,`login_account`.`username` AS `username`,`login_account`.`password` AS `password` from `login_account` ;

-- --------------------------------------------------------

--
-- Structure for view `listoffered`
--
DROP TABLE IF EXISTS `listoffered`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listoffered`  AS  select `offering_car`.`offer_id` AS `offer_id`,`offering_car`.`car_id` AS `car_id`,`offering_car`.`offerered_date` AS `offerered_date`,`offering_car`.`return_date` AS `return_date`,`offering_car`.`customer_id` AS `customer_id` from `offering_car` ;

-- --------------------------------------------------------

--
-- Structure for view `listreturns`
--
DROP TABLE IF EXISTS `listreturns`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listreturns`  AS  select `returning_car`.`return_id` AS `return_id`,`returning_car`.`car_id` AS `car_id`,`returning_car`.`offerered_date` AS `offerered_date`,`returning_car`.`return_date` AS `return_date`,`returning_car`.`customer_id` AS `customer_id` from `returning_car` ;

-- --------------------------------------------------------

--
-- Structure for view `listtax`
--
DROP TABLE IF EXISTS `listtax`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listtax`  AS  select `taxation`.`tax_id` AS `tax_id`,`taxation`.`tax_decaralation` AS `tax_decaralation`,`taxation`.`amount_payed` AS `amount_payed`,`taxation`.`date_payed` AS `date_payed` from `taxation` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars_tbl`
--
ALTER TABLE `cars_tbl`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `customer_register`
--
ALTER TABLE `customer_register`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `enrollement`
--
ALTER TABLE `enrollement`
  ADD PRIMARY KEY (`enroll_id`),
  ADD KEY `customer_register_enrollement` (`customer_id`),
  ADD KEY `cars_tbl_enrollement` (`car_id`);

--
-- Indexes for table `login_account`
--
ALTER TABLE `login_account`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `offering_car`
--
ALTER TABLE `offering_car`
  ADD PRIMARY KEY (`offer_id`),
  ADD KEY `cars_tbl_offering_car` (`car_id`),
  ADD KEY `customer_register_offering_car` (`customer_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_id`),
  ADD KEY `customer_register_payment` (`customer_id`);

--
-- Indexes for table `returning_car`
--
ALTER TABLE `returning_car`
  ADD PRIMARY KEY (`return_id`),
  ADD KEY `customer_register_returning_car` (`customer_id`),
  ADD KEY `cars_tbl_returning_car` (`car_id`);

--
-- Indexes for table `taxation`
--
ALTER TABLE `taxation`
  ADD PRIMARY KEY (`tax_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars_tbl`
--
ALTER TABLE `cars_tbl`
  MODIFY `car_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customer_register`
--
ALTER TABLE `customer_register`
  MODIFY `customer_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `enrollement`
--
ALTER TABLE `enrollement`
  MODIFY `enroll_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `login_account`
--
ALTER TABLE `login_account`
  MODIFY `login_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `offering_car`
--
ALTER TABLE `offering_car`
  MODIFY `offer_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `returning_car`
--
ALTER TABLE `returning_car`
  MODIFY `return_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `taxation`
--
ALTER TABLE `taxation`
  MODIFY `tax_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollement`
--
ALTER TABLE `enrollement`
  ADD CONSTRAINT `cars_tbl_enrollement` FOREIGN KEY (`car_id`) REFERENCES `cars_tbl` (`car_id`),
  ADD CONSTRAINT `customer_register_enrollement` FOREIGN KEY (`customer_id`) REFERENCES `customer_register` (`customer_id`);

--
-- Constraints for table `offering_car`
--
ALTER TABLE `offering_car`
  ADD CONSTRAINT `cars_tbl_offering_car` FOREIGN KEY (`car_id`) REFERENCES `cars_tbl` (`car_id`),
  ADD CONSTRAINT `customer_register_offering_car` FOREIGN KEY (`customer_id`) REFERENCES `customer_register` (`customer_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `customer_register_payment` FOREIGN KEY (`customer_id`) REFERENCES `customer_register` (`customer_id`);

--
-- Constraints for table `returning_car`
--
ALTER TABLE `returning_car`
  ADD CONSTRAINT `cars_tbl_returning_car` FOREIGN KEY (`car_id`) REFERENCES `cars_tbl` (`car_id`),
  ADD CONSTRAINT `customer_register_returning_car` FOREIGN KEY (`customer_id`) REFERENCES `customer_register` (`customer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
