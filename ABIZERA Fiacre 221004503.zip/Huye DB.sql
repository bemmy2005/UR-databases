-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2022 at 10:37 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `huye_stadium`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--
-- Creation: Jul 17, 2022 at 08:39 AM
--

CREATE TABLE `bank_account` (
  `Bank_Id` varchar(10) NOT NULL,
  `Client_Id` varchar(10) NOT NULL,
  `Date` date NOT NULL,
  `Manager_Id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`Bank_Id`, `Client_Id`, `Date`, `Manager_Id`) VALUES
('00', '001', '2022-11-15', '0123');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--
-- Creation: Jul 17, 2022 at 07:54 AM
--

CREATE TABLE `clients` (
  `Client_Id` varchar(10) NOT NULL,
  `Client_Names` text NOT NULL,
  `Client_Gender` text NOT NULL,
  `Client_Age` date NOT NULL,
  `Client_Location` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`Client_Id`, `Client_Names`, `Client_Gender`, `Client_Age`, `Client_Location`) VALUES
('001', 'Zidaane Iqbale', 'M', '2022-07-30', 'Ngoma'),
('002', 'Rodrigo  Goes', 'M', '2022-07-13', 'Brazil');

-- --------------------------------------------------------

--
-- Stand-in structure for view `client_view`
-- (See below for the actual view)
--
CREATE TABLE `client_view` (
`Client_Id` varchar(10)
,`Client_Names` text
,`Client_Gender` text
,`Client_Location` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--
-- Creation: Jul 17, 2022 at 08:43 AM
--

CREATE TABLE `manager` (
  `Manager_Id` varchar(10) NOT NULL,
  `Manager_Name` text NOT NULL,
  `Bank_Id` varchar(10) NOT NULL,
  `Client_Id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`Manager_Id`, `Manager_Name`, `Bank_Id`, `Client_Id`) VALUES
('0123', 'Ten Hag', '00', '001');

-- --------------------------------------------------------

--
-- Stand-in structure for view `manager_view`
-- (See below for the actual view)
--
CREATE TABLE `manager_view` (
`Manager_Id` varchar(10)
,`Manager_Name` text
,`Bank_Id` varchar(10)
,`Client_Id` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `payment_view`
-- (See below for the actual view)
--
CREATE TABLE `payment_view` (
`Bank_Id` varchar(10)
,`Client_Id` varchar(10)
,`Date` date
,`Manager_Id` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--
-- Creation: Jul 17, 2022 at 08:02 AM
--

CREATE TABLE `tickets` (
  `Ticket_Id` varchar(10) NOT NULL,
  `Client_Id` varchar(10) NOT NULL,
  `Amount_Paid` int(6) NOT NULL,
  `Created_Date` date NOT NULL,
  `Place_To_Sit` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`Ticket_Id`, `Client_Id`, `Amount_Paid`, `Created_Date`, `Place_To_Sit`) VALUES
('1', '001', 1000, '2022-11-30', '1');

-- --------------------------------------------------------

--
-- Stand-in structure for view `tickets_view`
-- (See below for the actual view)
--
CREATE TABLE `tickets_view` (
`Number` varchar(10)
,`Client_Identity` varchar(10)
,`Money` int(6)
,`Date` date
,`Place` varchar(5)
);

-- --------------------------------------------------------

--
-- Structure for view `client_view`
--
DROP TABLE IF EXISTS `client_view`;

CREATE VIEW `client_view`  AS SELECT `clients`.`Client_Id` AS `Client_Id`, `clients`.`Client_Names` AS `Client_Names`, `clients`.`Client_Gender` AS `Client_Gender`, `clients`.`Client_Location` AS `Client_Location` FROM `clients` WHERE `clients`.`Client_Gender` = 'M''M'  ;

-- --------------------------------------------------------

--
-- Structure for view `manager_view`
--
DROP TABLE IF EXISTS `manager_view`;

CREATE VIEW `manager_view`  AS SELECT `manager`.`Manager_Id` AS `Manager_Id`, `manager`.`Manager_Name` AS `Manager_Name`, `manager`.`Bank_Id` AS `Bank_Id`, `manager`.`Client_Id` AS `Client_Id` FROM `manager``manager`  ;

-- --------------------------------------------------------

--
-- Structure for view `payment_view`
--
DROP TABLE IF EXISTS `payment_view`;

CREATE VIEW `payment_view`  AS SELECT `bank_account`.`Bank_Id` AS `Bank_Id`, `bank_account`.`Client_Id` AS `Client_Id`, `bank_account`.`Date` AS `Date`, `bank_account`.`Manager_Id` AS `Manager_Id` FROM `bank_account``bank_account`  ;

-- --------------------------------------------------------

--
-- Structure for view `tickets_view`
--
DROP TABLE IF EXISTS `tickets_view`;

CREATE VIEW `tickets_view`  AS SELECT `tickets`.`Ticket_Id` AS `Number`, `tickets`.`Client_Id` AS `Client_Identity`, `tickets`.`Amount_Paid` AS `Money`, `tickets`.`Created_Date` AS `Date`, `tickets`.`Place_To_Sit` AS `Place` FROM `tickets``tickets`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_account`
--
ALTER TABLE `bank_account`
  ADD PRIMARY KEY (`Bank_Id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`Client_Id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`Ticket_Id`);
COMMIT;
