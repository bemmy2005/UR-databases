-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 09:48 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_derively`
--
CREATE DATABASE IF NOT EXISTS `food_derively` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `food_derively`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `MenuP`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `MenuP` (IN `meni_id` INT(11), IN `menu_name` VARCHAR(11), IN `price` INT(11), IN `menu_type_id` VARCHAR(11), IN `ingrideint` VARCHAR(11), IN `menu_status` INT(11))  NO SQL
INSERT into tblmenu VALUES (1,'Ifiriti', 12000, 'sald','salts',0001)$$

DROP PROCEDURE IF EXISTS `orderdetaisP`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `orderdetaisP` (IN `orderdetail_id` INT(11), IN `order_id` INT(11), IN `menu_id` INT(11), IN `amount` INT(11), IN `no` INT(11), IN `total_amount` INT(11))  NO SQL
INSERT INTO tblorderdetails VALUES (001,0001,0001,1212,121,1)$$

DROP PROCEDURE IF EXISTS `orderP`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `orderP` (IN `order_id` INT(11), IN `customer_id` INT(11), IN `order_date` INT(11), IN `total_amount` INT(11), IN `order_status` INT(11), IN `processed_by` INT(11))  NO SQL
INSERT INTO tblorder VALUES (111,111,11,12200,1,111212)$$

DROP PROCEDURE IF EXISTS `paymentP`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `paymentP` (IN `payment_id` INT(11), IN `order_id` INT(11), IN `amount` INT(11), IN `paid_by` INT(11), IN `payment_date` INT(11), IN `processed_by` INT(11))  NO SQL
INSERT into tblpayment VALUES (001,0393,00222,03003,0002,1112)$$

DROP PROCEDURE IF EXISTS `ratingP`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ratingP` (IN `rating_id` INT(11), IN `menu_id` INT(11), IN `score` INT(11), IN `remarks` INT(11), IN `customer_id` INT(11))  NO SQL
INSERT INTO tblrating VALUES (001,001,111,111,111)$$

DROP PROCEDURE IF EXISTS `tblcustomerP`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tblcustomerP` (IN `id` INT(11), IN `firstname` VARCHAR(30), IN `lastname` VARCHAR(30), IN `middlename` VARCHAR(30), IN `email` VARCHAR(30), IN `landing` VARCHAR(30), IN `password` VARCHAR(30), IN `status` VARCHAR(30))  BEGIN

  Insert into tblcustomer (customer_id, customer_first_name, customer_last_name, customer_middle_name, customer_email, customer_phone_number, customer_landline, customer_username, customer_password, account_status)
  VALUES (id, firstname, lastname, middlename, email, landing, password, status );
  
END$$

DROP PROCEDURE IF EXISTS `tblcustomerProcedure`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tblcustomerProcedure` (IN `id` INT(11), IN `firstname` VARCHAR(30), IN `lastname` VARCHAR(30), IN `middlename` VARCHAR(30), IN `email` VARCHAR(30), IN `landing` VARCHAR(30), IN `password` VARCHAR(30), IN `status` INT(11))  BEGIN

  Insert into tblcustomer (customer_id, customer_first_name, customer_last_name, customer_middle_name, customer_email, customer_phone_number, customer_landline, customer_username, customer_password, account_status)
  VALUES (id, firstname, lastname, middlename, email, landing, password, status );
  
END$$

DROP PROCEDURE IF EXISTS `usersP`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usersP` (IN `user_id` INT(11), IN `full_name` VARCHAR(11), IN `contact` INT(11), IN `email` VARCHAR(11), IN `username` VARCHAR(11), IN `paswword` VARCHAR(11))  NO SQL
INSERT INTO tbluser VALUES (0001,'Huge',098765432,'b@gmail.com', 'hello', 'ajsjasa')$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menu_id` int(11) DEFAULT NULL,
  `menu_name` varchar(100) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `menu_type_id` int(11) DEFAULT NULL,
  `menu_image` blob DEFAULT NULL,
  `ingredients` varchar(500) DEFAULT NULL,
  `menu_status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
CREATE TABLE `orderdetails` (
  `order_details_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `no_of_serving` int(4) DEFAULT NULL,
  `total_amount` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orderview`
--

DROP TABLE IF EXISTS `orderview`;
CREATE TABLE `orderview` (
  `order_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `order_status` int(1) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `payment_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `paid_by` varchar(50) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
CREATE TABLE `rating` (
  `rating_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `score` int(1) DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `date_recorded` date DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

DROP TABLE IF EXISTS `tblcustomer`;
CREATE TABLE `tblcustomer` (
  `customer_id` int(11) NOT NULL,
  `customer_first_name` varchar(30) NOT NULL,
  `customer_last_name` varchar(30) NOT NULL,
  `customer_middle_name` varchar(30) NOT NULL,
  `customer_email` varchar(50) NOT NULL,
  `customer_phone_number` varchar(15) NOT NULL,
  `customer_landline` varchar(15) NOT NULL,
  `profile_image` blob NOT NULL,
  `customer_username` varchar(30) NOT NULL,
  `customer_password` varchar(30) NOT NULL,
  `account_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomer`
--

INSERT INTO `tblcustomer` (`customer_id`, `customer_first_name`, `customer_last_name`, `customer_middle_name`, `customer_email`, `customer_phone_number`, `customer_landline`, `profile_image`, `customer_username`, `customer_password`, `account_status`) VALUES
(1, 'iradukunda ', 'Benjamin', 'BenIraa', 'beniraa50@gmail.com', '0781019415', 'kicukiro', '', 'BenIraa', '0987654321', 12),
(2, 'muhire', 'yves', 'yves', 'yves@gmail.com', '09876543', 'kicukiro', '', 'yvesmuhiere', '9876543', 22);

--
-- Triggers `tblcustomer`
--
DROP TRIGGER IF EXISTS `customerTrigger`;
DELIMITER $$
CREATE TRIGGER `customerTrigger` AFTER INSERT ON `tblcustomer` FOR EACH ROW BEGIN INSERT INTO tblcustomer VALUES(NEW.customer_id, NEW.customer_first_name, New.customer_last_name, NEW.customer_middle_name, NEW.customer_email, NEW.customer_phone_number, NEW.customer_landline, NEW.profile_image, NEW.customer_username, NEW.customer_password, NEW.account_status ,NOW()); END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `customerUPDATE`;
DELIMITER $$
CREATE TRIGGER `customerUPDATE` AFTER UPDATE ON `tblcustomer` FOR EACH ROW BEGIN
INSERT into staff VALUES (user(), CONCAT('Update customer Record ',
         OLD.customer_id,'customer :',OLD.customer_first_name,' sharma',
         NEW.customer_phone_number));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblmenu`
--

DROP TABLE IF EXISTS `tblmenu`;
CREATE TABLE `tblmenu` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `menu_type_id` int(11) NOT NULL,
  `menu_image` blob NOT NULL,
  `ingredients` varchar(500) NOT NULL,
  `menu_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmenu`
--

INSERT INTO `tblmenu` (`menu_id`, `menu_name`, `price`, `menu_type_id`, `menu_image`, `ingredients`, `menu_status`) VALUES
(1, 'Inkoko', 13000, 11, '', 'royco,salsa, magi, urusenda', 1),
(2, 'Chips', 2000, 122, '', 'Salads, mayomes', 111);

--
-- Triggers `tblmenu`
--
DROP TRIGGER IF EXISTS `menuTrigger`;
DELIMITER $$
CREATE TRIGGER `menuTrigger` AFTER INSERT ON `tblmenu` FOR EACH ROW BEGIN INSERT INTO tblmenu VALUES(NEW.menu_id, NEW.menu_name, New.price, NEW.menu_type_id, NEW.menu_image, NEW.ingredients, NEW.menu_status ,NOW()); END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

DROP TABLE IF EXISTS `tblorder`;
CREATE TABLE `tblorder` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `total_amount` float NOT NULL,
  `order_status` int(1) NOT NULL,
  `processed_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`order_id`, `customer_id`, `order_date`, `total_amount`, `order_status`, `processed_by`) VALUES
(1, 1, '2022-07-26', 13000, 12, 12),
(2, 1, '0000-00-00', 13000, 12, 12),
(3, 1, '2022-07-26', 13000, 121, 111);

--
-- Triggers `tblorder`
--
DROP TRIGGER IF EXISTS `orderTrigger`;
DELIMITER $$
CREATE TRIGGER `orderTrigger` AFTER INSERT ON `tblorder` FOR EACH ROW BEGIN INSERT INTO tblorder VALUES(NEW.order_id, NEW.customer_id, New.order_date, NEW.total_amount, NEW.order_status, NEW.processed_by, NOW()); END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblorderdetails`
--

DROP TABLE IF EXISTS `tblorderdetails`;
CREATE TABLE `tblorderdetails` (
  `order_details_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `no_of_serving` int(4) NOT NULL,
  `total_amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorderdetails`
--

INSERT INTO `tblorderdetails` (`order_details_id`, `order_id`, `menu_id`, `amount`, `no_of_serving`, `total_amount`) VALUES
(1, 1, 1, 13000, 1, 14000),
(11, 1, 1, 13000, 1, 13000);

--
-- Triggers `tblorderdetails`
--
DROP TRIGGER IF EXISTS `orderdetailsTrigger`;
DELIMITER $$
CREATE TRIGGER `orderdetailsTrigger` AFTER INSERT ON `tblorderdetails` FOR EACH ROW BEGIN INSERT INTO tblorderdetails VALUES(NEW.order_details_id, NEW.order_id, New.menu_id, NEW.amount, NEW.no_of_serving, NEW.total_amount, NOW()); END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblpayment`
--

DROP TABLE IF EXISTS `tblpayment`;
CREATE TABLE `tblpayment` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `paid_by` varchar(50) NOT NULL,
  `payment_date` date NOT NULL,
  `processed_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpayment`
--

INSERT INTO `tblpayment` (`payment_id`, `order_id`, `amount`, `paid_by`, `payment_date`, `processed_by`) VALUES
(1, 1, 14000, 'Benjamin iraduknda', '2022-07-26', 12),
(2, 1, 13000, 'Benjamin iraduknda', '2022-07-26', 12);

--
-- Triggers `tblpayment`
--
DROP TRIGGER IF EXISTS `paymentTrigger`;
DELIMITER $$
CREATE TRIGGER `paymentTrigger` AFTER INSERT ON `tblpayment` FOR EACH ROW BEGIN INSERT INTO tblpayment VALUES(NEW.payment_id, NEW.order_id, New.amount, NEW.paid_by, NEW.payment_date, NEW.processed_by, NOW()); END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblrating`
--

DROP TABLE IF EXISTS `tblrating`;
CREATE TABLE `tblrating` (
  `rating_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `score` int(1) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `date_recorded` date NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrating`
--

INSERT INTO `tblrating` (`rating_id`, `menu_id`, `score`, `remarks`, `date_recorded`, `customer_id`) VALUES
(1, 1, 7, 'Haburagamo umunyu mucye', '2022-07-28', 1),
(2, 1, 6, 'low salt and salsa', '2022-07-30', 1);

--
-- Triggers `tblrating`
--
DROP TRIGGER IF EXISTS `ratingDelete`;
DELIMITER $$
CREATE TRIGGER `ratingDelete` AFTER DELETE ON `tblrating` FOR EACH ROW BEGIN
INSERT into tblrating VALUES (user(), CONCAT('Delete rating Record ',
         OLD.rating_id,' id :',OLD.score, '-> Deleted on ', NOW()));
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ratingTrigger`;
DELIMITER $$
CREATE TRIGGER `ratingTrigger` AFTER INSERT ON `tblrating` FOR EACH ROW BEGIN INSERT INTO tblrating VALUES(NEW.rating_id, NEW.menu_id, New.score, NEW.remarks, NEW.date_recorded, NEW.customer_id, NOW()); END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ratingUPDATE`;
DELIMITER $$
CREATE TRIGGER `ratingUPDATE` AFTER UPDATE ON `tblrating` FOR EACH ROW BEGIN
INSERT into tblrating VALUES (user(), CONCAT('Update rating Record ',
         OLD.rating_id,'id :',OLD.menu_id,5 ,
         NEW.score));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblsiteinfo`
--

DROP TABLE IF EXISTS `tblsiteinfo`;
CREATE TABLE `tblsiteinfo` (
  `site_info_id` int(11) NOT NULL,
  `site_name` varchar(30) NOT NULL,
  `description` varchar(100) NOT NULL,
  `contact_info` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `last_update` date NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsiteinfo`
--

INSERT INTO `tblsiteinfo` (`site_info_id`, `site_name`, `description`, `contact_info`, `address`, `last_update`, `user_id`) VALUES
(1, 'kimihurura', 'new branch', '0987654321', 'hepfo yurusengero', '2022-07-26', 1),
(2, 'kacyiru', 'new branch', '1234567', 'new station', '2022-07-26', 1);

--
-- Triggers `tblsiteinfo`
--
DROP TRIGGER IF EXISTS `listinfoTrigger`;
DELIMITER $$
CREATE TRIGGER `listinfoTrigger` AFTER INSERT ON `tblsiteinfo` FOR EACH ROW BEGIN INSERT INTO tblsiteinfo VALUES(NEW.site_info_id, NEW.site_name, New.description, NEW.contact_info, NEW.address, NEW.last_update, NEW.user_id,NOW()); END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE `tbluser` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`user_id`, `full_name`, `contact`, `email_address`, `username`, `password`) VALUES
(1, 'Bonny IHIMBAZWE', '0987654321', 'bonny@gmail.com', 'Bonphile', '0987654321');

--
-- Triggers `tbluser`
--
DROP TRIGGER IF EXISTS `userDelete`;
DELIMITER $$
CREATE TRIGGER `userDelete` AFTER DELETE ON `tbluser` FOR EACH ROW BEGIN
INSERT into tbluser VALUES (user(), CONCAT('Delete rating Record ',
         OLD.user_id,' id :',OLD.full_name, '-> Deleted on ', NOW()));
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `userTrigger`;
DELIMITER $$
CREATE TRIGGER `userTrigger` AFTER INSERT ON `tbluser` FOR EACH ROW BEGIN INSERT INTO tbluser VALUES(NEW.user_id, NEW.full_name, New.contact, NEW.email_address, NEW.username, NEW.password, NOW()); 

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `usersDelete`;
DELIMITER $$
CREATE TRIGGER `usersDelete` AFTER DELETE ON `tbluser` FOR EACH ROW BEGIN
INSERT into tbluser VALUES (user(), CONCAT('Delete rating Record ',
         OLD.user_id,' id :',OLD.full_name, '-> Deleted on ', NOW()));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
