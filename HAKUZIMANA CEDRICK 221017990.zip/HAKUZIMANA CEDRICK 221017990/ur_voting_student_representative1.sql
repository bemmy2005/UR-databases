-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 12:49 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ur_voting_student_representative1`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `delete_college`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_college` (IN `college_id_param` VARCHAR(20))   BEGIN
delete from college 
WHERE college_id=college_id_param;
END$$

DROP PROCEDURE IF EXISTS `delete_school`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_school` (IN `school_id_param` VARCHAR(20))   BEGIN
delete from school 
WHERE school_id=school_id_param;
END$$

DROP PROCEDURE IF EXISTS `getcollegeDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getcollegeDetails` ()   BEGIN
	select * from college;
END$$

DROP PROCEDURE IF EXISTS `getCondidateDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCondidateDetails` ()   BEGIN
	select * from condidate;
END$$

DROP PROCEDURE IF EXISTS `getdepartmentDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getdepartmentDetails` ()   BEGIN
	select * from department;
END$$

DROP PROCEDURE IF EXISTS `getPositionDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPositionDetails` ()   BEGIN
	select * from position;
END$$

DROP PROCEDURE IF EXISTS `getSchoolDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getSchoolDetails` ()   BEGIN
	select * from school;
END$$

DROP PROCEDURE IF EXISTS `getstudentDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getstudentDetails` ()   BEGIN
	select * from student;
END$$

DROP PROCEDURE IF EXISTS `getStudentDetails_sub_query`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getStudentDetails_sub_query` ()   BEGIN
	select * from student where age=(select max(age) from student);
END$$

DROP PROCEDURE IF EXISTS `getusersDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getusersDetails` ()   BEGIN
	select * from users;
END$$

DROP PROCEDURE IF EXISTS `getVotesDetails`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getVotesDetails` ()   BEGIN
	select * from votes;
END$$

DROP PROCEDURE IF EXISTS `insert_college`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_college` (IN `IDparam` INT, `college_idParam` VARCHAR(20), `college_nameParam` VARCHAR(20))   BEGIN
INSERT INTO college VALUES(IDparam,college_idParam,college_nameParam);
END$$

DROP PROCEDURE IF EXISTS `insert_condidate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_condidate` (IN `IDparam` INT, `condidate_reg_numberParam` VARCHAR(20), `positionIDParam` VARCHAR(20), `cond_statusParam` VARCHAR(20))   BEGIN
INSERT INTO votes VALUES(
IDparam,
condidate_reg_numberParam,
positionIDParam,
cond_statusParam);
END$$

DROP PROCEDURE IF EXISTS `insert_department`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_department` (IN `IDparam` INT, `department_idParam` VARCHAR(20), `departmentNameParam` VARCHAR(20), `collegeIDparam` VARCHAR(20), `schoolIDparam` VARCHAR(20))   BEGIN
INSERT INTO department VALUES(IDparam,department_idParam ,departmentNameParam,collegeIDparam,schoolIDparam);
END$$

DROP PROCEDURE IF EXISTS `insert_position`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_position` (IN `IDparam` INT, `positionIdParam` VARCHAR(20), `positionTitleParam` VARCHAR(20))   BEGIN
INSERT INTO condidate VALUES(
IDparam,
positionIdParam,
positionTitleParam);
END$$

DROP PROCEDURE IF EXISTS `insert_school`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_school` (IN `IDparam` INT, `school_idParam` VARCHAR(20), `schoolNameParam` VARCHAR(20), `collegeIdParam` VARCHAR(20))   BEGIN
INSERT INTO school VALUES(IDparam,school_idParam ,schoolNameParam,collegeIdParam);
END$$

DROP PROCEDURE IF EXISTS `insert_student`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_student` (IN `IDparam` INT, `reg_numberParam` VARCHAR(20), `st_fnameParam` VARCHAR(30), `st_lnameParam` VARCHAR(20), `ageParam` VARCHAR(10), `collegeIdParam` VARCHAR(20), `schoolIdParam` VARCHAR(20), `departmentIdParam` VARCHAR(20))   BEGIN
INSERT INTO student VALUES(
IDparam,
reg_numberParam,
st_fnameParam,
st_lnameParam,
ageParam,
collegeIdParam,
schoolIdParam,
departmentIdParam);
END$$

DROP PROCEDURE IF EXISTS `insert_votes`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_votes` (IN `IDparam` INT, `condidate_reg_numberParam` VARCHAR(20), `positionIDParam` VARCHAR(20), `cond_statusParam` VARCHAR(20))   BEGIN
INSERT INTO votes VALUES(
IDparam,
condidate_reg_numberParam,
positionIDParam,
cond_statusParam);
END$$

DROP PROCEDURE IF EXISTS `update_college`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_college` (IN `college_id_param` VARCHAR(20))   BEGIN
UPDATE college SET school_name='CBE02' WHERE college_id=college_id_param;
END$$

DROP PROCEDURE IF EXISTS `update_school`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_school` (IN `school_id_param` VARCHAR(20))   BEGIN
UPDATE school SET school_name='Economics' WHERE school_id=school_id_param;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

DROP TABLE IF EXISTS `college`;
CREATE TABLE `college` (
  `ID` int(11) NOT NULL,
  `college_id` varchar(20) NOT NULL,
  `college_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`ID`, `college_id`, `college_name`) VALUES
(2, 'CASS01', 'college of Art and s'),
(1, 'CBE01', 'college of bussiness');

-- --------------------------------------------------------

--
-- Stand-in structure for view `college_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `college_data`;
CREATE TABLE `college_data` (
`ID` int(11)
,`college_id` varchar(20)
,`college_name` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `condidate`
--

DROP TABLE IF EXISTS `condidate`;
CREATE TABLE `condidate` (
  `ID` int(11) NOT NULL,
  `condidate_reg_number` varchar(20) NOT NULL,
  `position_id` varchar(20) DEFAULT NULL,
  `candidate_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `condidate`
--

INSERT INTO `condidate` (`ID`, `condidate_reg_number`, `position_id`, `candidate_status`) VALUES
(0, '221017990', 'p1', 'pending');

-- --------------------------------------------------------

--
-- Stand-in structure for view `condidate_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `condidate_data`;
CREATE TABLE `condidate_data` (
`ID` int(11)
,`condidate_reg_number` varchar(20)
,`position_id` varchar(20)
,`candidate_status` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `ID` int(11) NOT NULL,
  `department_id` varchar(20) NOT NULL,
  `department_name` varchar(50) DEFAULT NULL,
  `college_id` varchar(20) NOT NULL,
  `school_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`ID`, `department_id`, `department_name`, `college_id`, `school_id`) VALUES
(1, 'BIT01', 'bussiness information technology', 'CBE01', 'SB01'),
(2, 'soc19', 'social welfarenes', 'SB01', 'SECO01'),
(3, 'STAT01', 'social welfarenes', 'CMHS', 'SECO01');

-- --------------------------------------------------------

--
-- Stand-in structure for view `department_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `department_data`;
CREATE TABLE `department_data` (
`ID` int(11)
,`department_id` varchar(20)
,`department_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

DROP TABLE IF EXISTS `position`;
CREATE TABLE `position` (
  `ID` int(11) NOT NULL,
  `position_id` varchar(20) NOT NULL,
  `position_title` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`ID`, `position_id`, `position_title`) VALUES
(1, 'p1', 'speaker'),
(2, 'p2', 'secretary');

--
-- Triggers `position`
--
DROP TRIGGER IF EXISTS `delete_trigger`;
DELIMITER $$
CREATE TRIGGER `delete_trigger` AFTER DELETE ON `position` FOR EACH ROW DELETE FROM position WHERE `position`.`position_id` = 'guild01'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `position_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `position_data`;
CREATE TABLE `position_data` (
`ID` int(11)
,`position_id` varchar(20)
,`position_title` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

DROP TABLE IF EXISTS `school`;
CREATE TABLE `school` (
  `ID` int(11) NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `school_name` varchar(20) DEFAULT NULL,
  `college_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`ID`, `school_id`, `school_name`, `college_id`) VALUES
(1, 'SB01', 'school of bussiness', 'CBE01'),
(2, 'SECO01', 'school of economics', 'CBE01');

--
-- Triggers `school`
--
DROP TRIGGER IF EXISTS `add_new_school`;
DELIMITER $$
CREATE TRIGGER `add_new_school` AFTER INSERT ON `school` FOR EACH ROW INSERT INTO `school` (`ID`, `school_id`, `school_name`) VALUES ('1', 'SB01', 'school of bussiness')
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `update_trigger`;
DELIMITER $$
CREATE TRIGGER `update_trigger` AFTER UPDATE ON `school` FOR EACH ROW UPDATE `student` SET `student_fname` = 'cedro' WHERE `student`.`student_reg_number` = '221017990'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `school_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `school_data`;
CREATE TABLE `school_data` (
`ID` int(11)
,`school_id` varchar(20)
,`school_name` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `student_reg_number` varchar(20) NOT NULL,
  `student_fname` varchar(20) DEFAULT NULL,
  `student_lname` varchar(20) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `college_id` varchar(20) DEFAULT NULL,
  `school_id` varchar(20) DEFAULT NULL,
  `department_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `student_reg_number`, `student_fname`, `student_lname`, `age`, `college_id`, `school_id`, `department_id`) VALUES
(1, '221017990', 'cedro', 'hakuzimana', '23', 'CBE01', 'SB01', 'BIT01'),
(2, '221017991', 'peter', 'mwamba', '23', 'CBE01', 'SB01', 'BIT01');

--
-- Triggers `student`
--
DROP TRIGGER IF EXISTS `delete_triger2`;
DELIMITER $$
CREATE TRIGGER `delete_triger2` AFTER DELETE ON `student` FOR EACH ROW DELETE FROM student WHERE `student`.`student_reg_number` = '221017990'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `student_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `student_data`;
CREATE TABLE `student_data` (
`ID` int(11)
,`student_reg_number` varchar(20)
,`student_fname` varchar(20)
,`student_lname` varchar(20)
,`age` varchar(10)
,`college_id` varchar(20)
,`school_id` varchar(20)
,`department_id` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sub_query_based_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `sub_query_based_view`;
CREATE TABLE `sub_query_based_view` (
`ID` int(11)
,`student_reg_number` varchar(20)
,`student_fname` varchar(20)
,`student_lname` varchar(20)
,`age` varchar(10)
,`college_id` varchar(20)
,`school_id` varchar(20)
,`department_id` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `user_fname` varchar(20) DEFAULT NULL,
  `user_lname` varchar(20) DEFAULT NULL,
  `user_pasword` varchar(20) DEFAULT NULL,
  `user_email` varchar(20) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `user_id`, `user_fname`, `user_lname`, `user_pasword`, `user_email`, `role`, `phone`) VALUES
(1, 'ad1', 'cedrick', NULL, '23/12', 'cedro@gmail.com', 'admin', '0784366616');

-- --------------------------------------------------------

--
-- Stand-in structure for view `users_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `users_data`;
CREATE TABLE `users_data` (
`ID` int(11)
,`user_id` varchar(20)
,`user_fname` varchar(20)
,`user_lname` varchar(20)
,`user_pasword` varchar(20)
,`user_email` varchar(20)
,`role` varchar(20)
,`phone` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

DROP TABLE IF EXISTS `votes`;
CREATE TABLE `votes` (
  `ID` int(11) NOT NULL,
  `student_reg_number` varchar(20) NOT NULL,
  `condidate_reg_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`ID`, `student_reg_number`, `condidate_reg_number`) VALUES
(1, '221017991', '221017990');

-- --------------------------------------------------------

--
-- Stand-in structure for view `votes_data`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `votes_data`;
CREATE TABLE `votes_data` (
`ID` int(11)
,`student_reg_number` varchar(20)
,`condidate_reg_number` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure for view `college_data`
--
DROP TABLE IF EXISTS `college_data`;

DROP VIEW IF EXISTS `college_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `college_data`  AS SELECT `college`.`ID` AS `ID`, `college`.`college_id` AS `college_id`, `college`.`college_name` AS `college_name` FROM `college``college`  ;

-- --------------------------------------------------------

--
-- Structure for view `condidate_data`
--
DROP TABLE IF EXISTS `condidate_data`;

DROP VIEW IF EXISTS `condidate_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `condidate_data`  AS SELECT `condidate`.`ID` AS `ID`, `condidate`.`condidate_reg_number` AS `condidate_reg_number`, `condidate`.`position_id` AS `position_id`, `condidate`.`candidate_status` AS `candidate_status` FROM `condidate``condidate`  ;

-- --------------------------------------------------------

--
-- Structure for view `department_data`
--
DROP TABLE IF EXISTS `department_data`;

DROP VIEW IF EXISTS `department_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `department_data`  AS SELECT `department`.`ID` AS `ID`, `department`.`department_id` AS `department_id`, `department`.`department_name` AS `department_name` FROM `department``department`  ;

-- --------------------------------------------------------

--
-- Structure for view `position_data`
--
DROP TABLE IF EXISTS `position_data`;

DROP VIEW IF EXISTS `position_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `position_data`  AS SELECT `position`.`ID` AS `ID`, `position`.`position_id` AS `position_id`, `position`.`position_title` AS `position_title` FROM `position``position`  ;

-- --------------------------------------------------------

--
-- Structure for view `school_data`
--
DROP TABLE IF EXISTS `school_data`;

DROP VIEW IF EXISTS `school_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `school_data`  AS SELECT `school`.`ID` AS `ID`, `school`.`school_id` AS `school_id`, `school`.`school_name` AS `school_name` FROM `school``school`  ;

-- --------------------------------------------------------

--
-- Structure for view `student_data`
--
DROP TABLE IF EXISTS `student_data`;

DROP VIEW IF EXISTS `student_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `student_data`  AS SELECT `student`.`ID` AS `ID`, `student`.`student_reg_number` AS `student_reg_number`, `student`.`student_fname` AS `student_fname`, `student`.`student_lname` AS `student_lname`, `student`.`age` AS `age`, `student`.`college_id` AS `college_id`, `student`.`school_id` AS `school_id`, `student`.`department_id` AS `department_id` FROM `student``student`  ;

-- --------------------------------------------------------

--
-- Structure for view `sub_query_based_view`
--
DROP TABLE IF EXISTS `sub_query_based_view`;

DROP VIEW IF EXISTS `sub_query_based_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sub_query_based_view`  AS SELECT `student`.`ID` AS `ID`, `student`.`student_reg_number` AS `student_reg_number`, `student`.`student_fname` AS `student_fname`, `student`.`student_lname` AS `student_lname`, `student`.`age` AS `age`, `student`.`college_id` AS `college_id`, `student`.`school_id` AS `school_id`, `student`.`department_id` AS `department_id` FROM `student` WHERE `student`.`age` > (select avg(`student`.`age`) from `student`)  ;

-- --------------------------------------------------------

--
-- Structure for view `users_data`
--
DROP TABLE IF EXISTS `users_data`;

DROP VIEW IF EXISTS `users_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_data`  AS SELECT `users`.`ID` AS `ID`, `users`.`user_id` AS `user_id`, `users`.`user_fname` AS `user_fname`, `users`.`user_lname` AS `user_lname`, `users`.`user_pasword` AS `user_pasword`, `users`.`user_email` AS `user_email`, `users`.`role` AS `role`, `users`.`phone` AS `phone` FROM `users``users`  ;

-- --------------------------------------------------------

--
-- Structure for view `votes_data`
--
DROP TABLE IF EXISTS `votes_data`;

DROP VIEW IF EXISTS `votes_data`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `votes_data`  AS SELECT `votes`.`ID` AS `ID`, `votes`.`student_reg_number` AS `student_reg_number`, `votes`.`condidate_reg_number` AS `condidate_reg_number` FROM `votes``votes`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`college_id`);

--
-- Indexes for table `condidate`
--
ALTER TABLE `condidate`
  ADD PRIMARY KEY (`condidate_reg_number`),
  ADD KEY `cond` (`position_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`position_id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_reg_number`),
  ADD KEY `college_id` (`college_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `condidate_reg_number` (`condidate_reg_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `condidate`
--
ALTER TABLE `condidate`
  ADD CONSTRAINT `cond` FOREIGN KEY (`position_id`) REFERENCES `position` (`position_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `college` (`college_id`),
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`),
  ADD CONSTRAINT `student_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`);

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`condidate_reg_number`) REFERENCES `condidate` (`condidate_reg_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
