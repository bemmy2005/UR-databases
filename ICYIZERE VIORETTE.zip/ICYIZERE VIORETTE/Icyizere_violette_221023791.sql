-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 08:54 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `icyizere_violette_221023791`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletelecture` (IN `lecture_Id` INT(6))  BEGIN 
DELETE FROM lecture where lecture.lecture_Id='ID';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deletemarks` (IN `mark_Id` INT(6))  BEGIN
DELETE FROM marks where marks.mark_Id='ID'; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertlecture` (IN `lecture_Id` INT(5), `Firstname` VARCHAR(20), `Lastname` VARCHAR(15), `department` VARCHAR(20), `phone_number` INT(12), `Email` VARCHAR(40))  BEGIN
insert into lecture values(lecture_Id ,Firstname ,Lastname ,department ,phone_number ,Email); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertmarks` (IN `mark_Id` INT(10), `std_Id` INT(5), `course_Id` INT(15), `Cat` FLOAT(10), `Assignment` FLOAT(10), `Exam` FLOAT(12))  BEGIN 
insert into marks values(mark_Id ,std_Id ,course_Id ,Cat ,Assignment ,Exam ); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertmodule` (IN `module_Id` INT(10), `module_name` VARCHAR(30), `phone_number` INT(12), `department` VARCHAR(15))  BEGIN 
insert into module values(module_Id, module_name,phone_number ,department);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertstudents` (IN `std_Id` INT(4), `Fname` VARCHAR(30), `Lname` VARCHAR(15), `Gender` VARCHAR(6), `department` VARCHAR(20))  BEGIN
 insert into students values(std_Id ,Fname ,Lname ,Gender ,department );
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectlecture` ()  BEGIN 
select*from lecture;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectmarks` ()  BEGIN select*from marks; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectmodule` ()  BEGIN select*from module;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectstudents` ()  BEGIN 
select * from students; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatemodule` (IN `module_Id` INT(6), `department` VARCHAR(20))  BEGIN
UPDATE module set module.department='department' WHERE module.module_Id='Id';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatestudents` (IN `ID` INT(6), `FIRSTNAME` VARCHAR(20))  BEGIN 
UPDATE students set students.Fname='FIRSTNAME' WHERE students.Gender='Male';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `lecture`
--

CREATE TABLE `lecture` (
  `lecture_Id` int(5) NOT NULL,
  `Firstname` varchar(20) DEFAULT NULL,
  `Lastname` varchar(15) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  `phone_number` int(12) NOT NULL,
  `Email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecture`
--

INSERT INTO `lecture` (`lecture_Id`, `Firstname`, `Lastname`, `department`, `phone_number`, `Email`) VALUES
(1, 'Dr SESONGA', 'Jean Batiste', 'ACC', 788888866, 'sesonga@gmail.com'),
(2, 'DR SHEMA', 'Emmy', 'AGRIBUSINESS', 78822866, 'shema123@gmail.com'),
(3, 'MUHORACYEYE', 'Jeanette', 'BIT', 799888866, 'jeanette@gmail.com'),
(5, 'MUKAMA', 'Joel', 'COMPUTER', 788000066, 'mukama@gmail.com'),
(22, 'DR SESONGA', 'jean', 'ACC', 791523176, 'sesonga@gmail.com'),
(123, 'KARIMUNDA', 'Junier', 'COMPUER', 7900033, 'karimunda@gmail.com'),
(1234, 'KAMANA', 'Jean', 'CS', 7922233, 'kamana@gmail.com'),
(12340, 'KAMANA', 'Jean', 'CS', 7922233, 'kamana@gmail.com'),
(12345, 'KANANI', 'Jean', 'BIT', 792, 'kanani@gmail.com'),
(123456, 'MUKASA', 'Jean', 'IT', 79222093, 'jean@gmail.com');

-- --------------------------------------------------------

--
-- Stand-in structure for view `lecture_view`
-- (See below for the actual view)
--
CREATE TABLE `lecture_view` (
`lecture_Id` int(5)
,`Firstname` varchar(20)
,`Lastname` varchar(15)
,`department` varchar(20)
,`phone_number` int(12)
,`Email` varchar(40)
);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `mark_Id` int(10) NOT NULL,
  `std_Id` int(5) DEFAULT NULL,
  `course_Id` int(15) DEFAULT NULL,
  `Cat` float DEFAULT NULL,
  `Assignment` float DEFAULT NULL,
  `Exam` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`mark_Id`, `std_Id`, `course_Id`, `Cat`, `Assignment`, `Exam`) VALUES
(1, 1, 23, 33.4, 12.88, 43),
(2, 2, 3003, 29, 12.88, 33),
(3, 3, 4023, 33.12, 19.6, 20.3),
(4, 4, 2023, 33.46, 12.88, 19.88),
(5, 5, 5903, 33.4, 17, 29),
(11, 6, 20, 33.45, 12.8, 43.4),
(110, 2, 2201, 33.44, 12.81, 23.4),
(111, 3, 2202, 33.44, 12.81, 23.4),
(112, 4, 2203, 33.41, 12.81, 23.4),
(113, 5, 2204, 33.44, 12.81, 23.4),
(114, 2, 23, 21.5, 19, 39);

--
-- Triggers `marks`
--
DELIMITER $$
CREATE TRIGGER `deletemarks` AFTER DELETE ON `marks` FOR EACH ROW BEGIN
update counters SET marks='33.41' WHERE mark_Id='112'; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updatemarks` AFTER UPDATE ON `marks` FOR EACH ROW BEGIN
update count SET marks=(marks+3); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `marks_view`
-- (See below for the actual view)
--
CREATE TABLE `marks_view` (
`mark_Id` int(10)
,`std_Id` int(5)
,`course_Id` int(15)
,`Cat` float
,`Assignment` float
,`Exam` float
);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `module_Id` int(10) NOT NULL,
  `module_name` varchar(30) DEFAULT NULL,
  `phone_number` int(12) DEFAULT NULL,
  `department` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`module_Id`, `module_name`, `phone_number`, `department`) VALUES
(1, 'BUSINESS FUNCTION', 7900033, 'IT'),
(2, 'BUSINESS FUNCTION', 79004586, 'BIT'),
(4, 'INTERMEDIATE ACCOUNTING', 78008866, 'COMPUTER'),
(5, 'SYSTEM ENGINEERING', 786050245, 'CS'),
(2037, 'BUSINESS MANAGEMENT', 788888866, 'ICT'),
(2200, 'ENGLISH FOR SPECIAL PURPOSE', 79004539, 'CS'),
(2211, 'BUSINESS FUNCTION', 7900039, 'CS'),
(2220, 'INTRODUCTION TO ACCOUNTING', 7900033, 'IT'),
(2233, 'BUSINESS MANAGEMENT', 7888889, 'BIT'),
(2244, 'SOCIAL AND ECONOMIC ENVIRONMEN', 79760039, 'COMPUTER');

--
-- Triggers `module`
--
DELIMITER $$
CREATE TRIGGER `insertsmodule` AFTER INSERT ON `module` FOR EACH ROW BEGIN 
update COUNT SET module=(module+department);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updatemodule` AFTER UPDATE ON `module` FOR EACH ROW BEGIN
update count SET module_Id=(module_Id+2); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `module_view`
-- (See below for the actual view)
--
CREATE TABLE `module_view` (
`module_Id` int(10)
,`module_name` varchar(30)
,`phone_number` int(12)
,`department` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_Id` int(4) NOT NULL,
  `Fname` varchar(30) DEFAULT NULL,
  `Lname` varchar(15) DEFAULT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_Id`, `Fname`, `Lname`, `Gender`, `department`) VALUES
(1, 'FIRSTNAME', 'Issa', 'Male', 'BIT'),
(2, 'UMUHOZA', 'Afisa', 'Female', 'IT'),
(3, 'FIRSTNAME', 'Alex', 'Male', 'CS'),
(4, 'UWERA', 'Gloriose', 'Female', 'ACC'),
(5, 'FIRSTNAME', 'Adolphe', 'Male', 'COMPUTER ENGINEERING'),
(6, 'HAKUZIMANA', 'Anitha', 'Female', 'COMPUTER '),
(10, 'MUKAMANA', 'Anuarita', 'Female', 'COMPUER'),
(11, 'UMUHOZA', 'Aline', 'Female', 'IT'),
(12, 'UMURWANEZA', 'Amina', 'Female', 'BIT'),
(13, 'FIRSTNAME', 'Andre', 'Male', 'ACC'),
(14, 'MUKAMANA', 'dorcas', 'Female', 'ABRIBUSINESS'),
(1122, 'UWERA', 'Anitha', 'Female', 'BIT');

--
-- Triggers `students`
--
DELIMITER $$
CREATE TRIGGER `deletestudents` AFTER DELETE ON `students` FOR EACH ROW BEGIN
update counters SET Fname='UWERA' WHERE std_Id='5';
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertstudents` AFTER INSERT ON `students` FOR EACH ROW BEGIN 
update COUNT SET Fname=(Fname+deny);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `students_view`
-- (See below for the actual view)
--
CREATE TABLE `students_view` (
`std_Id` int(4)
,`Fname` varchar(30)
,`Lname` varchar(15)
,`Gender` varchar(6)
,`department` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure for view `lecture_view`
--
DROP TABLE IF EXISTS `lecture_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lecture_view`  AS SELECT `lecture`.`lecture_Id` AS `lecture_Id`, `lecture`.`Firstname` AS `Firstname`, `lecture`.`Lastname` AS `Lastname`, `lecture`.`department` AS `department`, `lecture`.`phone_number` AS `phone_number`, `lecture`.`Email` AS `Email` FROM `lecture` ;

-- --------------------------------------------------------

--
-- Structure for view `marks_view`
--
DROP TABLE IF EXISTS `marks_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `marks_view`  AS SELECT `marks`.`mark_Id` AS `mark_Id`, `marks`.`std_Id` AS `std_Id`, `marks`.`course_Id` AS `course_Id`, `marks`.`Cat` AS `Cat`, `marks`.`Assignment` AS `Assignment`, `marks`.`Exam` AS `Exam` FROM `marks` ;

-- --------------------------------------------------------

--
-- Structure for view `module_view`
--
DROP TABLE IF EXISTS `module_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `module_view`  AS SELECT `module`.`module_Id` AS `module_Id`, `module`.`module_name` AS `module_name`, `module`.`phone_number` AS `phone_number`, `module`.`department` AS `department` FROM `module` ;

-- --------------------------------------------------------

--
-- Structure for view `students_view`
--
DROP TABLE IF EXISTS `students_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `students_view`  AS SELECT `students`.`std_Id` AS `std_Id`, `students`.`Fname` AS `Fname`, `students`.`Lname` AS `Lname`, `students`.`Gender` AS `Gender`, `students`.`department` AS `department` FROM `students` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lecture`
--
ALTER TABLE `lecture`
  ADD PRIMARY KEY (`lecture_Id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`mark_Id`),
  ADD KEY `students` (`std_Id`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`module_Id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`std_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lecture`
--
ALTER TABLE `lecture`
  MODIFY `lecture_Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123457;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `mark_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `module_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2245;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `std_Id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1123;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `students` FOREIGN KEY (`std_Id`) REFERENCES `students` (`std_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
