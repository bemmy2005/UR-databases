-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 05:15 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mucyo`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deltBus_class` ()   BEGIN DELETE FROM bus_class WHERE bus_id="1"; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deltcustomer` ()   BEGIN DELETE FROM customer_class WHERE customer_id="1"; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getBus_class` ()   BEGIN Select * from bus_class;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcustomer_class` ()   BEGIN Select * from customer_class; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getdriver_class` ()   BEGIN Select * from driver_class; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getpermision` ()   BEGIN Select * from permissionion; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getticket_class` ()   BEGIN UPDATE customer_class
SET customer_mobile="0785161508"
WHERE customer_id="1";
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBus_class` ()   BEGIN 
INSERT INTO bus_class VALUES('1','lemozine','Rae81d','29');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTcustomer_class` ()   BEGIN INSERT INTO customer_class VALUES ('1','shama','0785710648','sharma@gmail.com','nyagatare');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTdriver_class` ()   BEGIN INSERT INTO driver_class VALUES ('1','sham','kigali','0788449384','sham5678@gmail.com'); END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTpermision` ()   BEGIN INSERT INTO permission VALUES ('shama','123@1'); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTticket` ()   BEGIN INSERT INTO ticket_class VALUES ('1','','','','kirehe','bugaragar','26-07-2022'); END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `subQuery` ()   BEGIN select driver_view.driver_name,bus_view.bus_name,customer_class.customer_name from driver_view,bus_view,customer_class; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateBus_class` ()   BEGIN UPDATE bus_class 
 SET bus_name="benzi" 
WHERE bus_id="01";
 END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `bus_class`
--

CREATE TABLE `bus_class` (
  `bus_id` int(11) NOT NULL,
  `bus_name` text NOT NULL,
  `bus_plate_number` varchar(100) NOT NULL,
  `bus_seat_number` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus_class`
--

INSERT INTO `bus_class` (`bus_id`, `bus_name`, `bus_plate_number`, `bus_seat_number`) VALUES
(1, 'toyota', 'RAE816H', 29),
(2, 'toyota', 'RAE816H', 29);

--
-- Triggers `bus_class`
--
DELIMITER $$
CREATE TRIGGER `bus_trigerUpdate` AFTER UPDATE ON `bus_class` FOR EACH ROW UPDATE bus_class SET bus_plate_number='1111111',bus_seat_number='4' WHERE bus_id=2
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `bustriger` AFTER INSERT ON `bus_class` FOR EACH ROW INSERT INTO bus_class (bus_id,bus_name,bus_plate_number,bus_seat_number) VALUES(1,'horizon','6ggg','2')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `bus_view`
-- (See below for the actual view)
--
CREATE TABLE `bus_view` (
`bus_id` int(11)
,`bus_name` text
,`bus_plate_number` varchar(100)
,`bus_seat_number` int(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer_class`
--

CREATE TABLE `customer_class` (
  `customer_id` int(50) NOT NULL,
  `customer_name` text NOT NULL,
  `customer_mobile` int(12) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_address` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_class`
--

INSERT INTO `customer_class` (`customer_id`, `customer_name`, `customer_mobile`, `customer_email`, `customer_address`) VALUES
(1, 'mucyo', 788449384, 'mucyoemmanuel567@gmail.com', 'nyagatare'),
(2, 'mucyo', 788449384, 'mucyoemmanuel567@gmail.com', 'nyagatare');

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_view`
-- (See below for the actual view)
--
CREATE TABLE `customer_view` (
`customer_id` int(50)
,`customer_name` text
,`customer_mobile` int(12)
,`customer_email` varchar(100)
,`customer_address` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `defaultview`
-- (See below for the actual view)
--
CREATE TABLE `defaultview` (
`driver_name` text
,`bus_name` text
,`customer_name` text
);

-- --------------------------------------------------------

--
-- Table structure for table `driver_class`
--

CREATE TABLE `driver_class` (
  `driver_id` int(50) NOT NULL,
  `driver_name` text NOT NULL,
  `driver_address` varchar(50) NOT NULL,
  `driver_mobile` int(50) NOT NULL,
  `driver_email` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver_class`
--

INSERT INTO `driver_class` (`driver_id`, `driver_name`, `driver_address`, `driver_mobile`, `driver_email`) VALUES
(1, 'emmy', 'kigali', 788449384, 'emmy5678@yahoo.com'),
(2, 'emmy', 'kigali', 788449384, 'emmy5678@yahoo.com');

--
-- Triggers `driver_class`
--
DELIMITER $$
CREATE TRIGGER `driverTrigger` AFTER DELETE ON `driver_class` FOR EACH ROW DELETE FROM driver_class WHERE driver_id=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `driver_view`
-- (See below for the actual view)
--
CREATE TABLE `driver_view` (
`driver_id` int(50)
,`driver_name` text
,`driver_address` varchar(50)
,`driver_mobile` int(50)
,`driver_email` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `Username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`Username`, `password`) VALUES
('kagaba', '123');

--
-- Triggers `permission`
--
DELIMITER $$
CREATE TRIGGER `passengertrigerUpdate` AFTER UPDATE ON `permission` FOR EACH ROW UPDATE permission SET Username='shama' WHERE password=123
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `permisionTriger` AFTER INSERT ON `permission` FOR EACH ROW INSERT INTO `permission` (`Username`, `password`) VALUES
('shama', '123')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `permisson_view`
-- (See below for the actual view)
--
CREATE TABLE `permisson_view` (
`username` varchar(100)
,`password` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_class`
--

CREATE TABLE `ticket_class` (
  `ticket_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `ticket_from` varchar(100) NOT NULL,
  `ticket_to` text NOT NULL,
  `ticket_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_class`
--

INSERT INTO `ticket_class` (`ticket_id`, `customer_id`, `bus_id`, `driver_id`, `ticket_from`, `ticket_to`, `ticket_date`) VALUES
(1, 0, 0, 0, 'nyagatare', 'kigali', '0000-00-00'),
(2, 0, 0, 0, 'nyagatare', 'kigali', '0000-00-00');

--
-- Triggers `ticket_class`
--
DELIMITER $$
CREATE TRIGGER `ticketTrigger` AFTER DELETE ON `ticket_class` FOR EACH ROW DELETE FROM ticket_class WHERE ticket_id=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `ticket_view`
-- (See below for the actual view)
--
CREATE TABLE `ticket_view` (
`ticket_id` int(11)
,`customer_id` int(11)
,`bus_id` int(11)
,`driver_id` int(11)
,`ticket_from` varchar(100)
,`ticket_to` text
,`ticket_date` date
);

-- --------------------------------------------------------

--
-- Structure for view `bus_view`
--
DROP TABLE IF EXISTS `bus_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bus_view`  AS SELECT `bus_class`.`bus_id` AS `bus_id`, `bus_class`.`bus_name` AS `bus_name`, `bus_class`.`bus_plate_number` AS `bus_plate_number`, `bus_class`.`bus_seat_number` AS `bus_seat_number` FROM `bus_class` WHERE `bus_class`.`bus_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `customer_view`
--
DROP TABLE IF EXISTS `customer_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_view`  AS SELECT `customer_class`.`customer_id` AS `customer_id`, `customer_class`.`customer_name` AS `customer_name`, `customer_class`.`customer_mobile` AS `customer_mobile`, `customer_class`.`customer_email` AS `customer_email`, `customer_class`.`customer_address` AS `customer_address` FROM `customer_class` WHERE `customer_class`.`customer_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `defaultview`
--
DROP TABLE IF EXISTS `defaultview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `defaultview`  AS SELECT `driver_view`.`driver_name` AS `driver_name`, `bus_view`.`bus_name` AS `bus_name`, `customer_class`.`customer_name` AS `customer_name` FROM ((`driver_view` join `bus_view`) join `customer_class`)  ;

-- --------------------------------------------------------

--
-- Structure for view `driver_view`
--
DROP TABLE IF EXISTS `driver_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `driver_view`  AS SELECT `driver_class`.`driver_id` AS `driver_id`, `driver_class`.`driver_name` AS `driver_name`, `driver_class`.`driver_address` AS `driver_address`, `driver_class`.`driver_mobile` AS `driver_mobile`, `driver_class`.`driver_email` AS `driver_email` FROM `driver_class` WHERE `driver_class`.`driver_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `permisson_view`
--
DROP TABLE IF EXISTS `permisson_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `permisson_view`  AS SELECT `permission`.`Username` AS `username`, `permission`.`password` AS `password` FROM `permission` GROUP BY `permission`.`password`= 123123  ;

-- --------------------------------------------------------

--
-- Structure for view `ticket_view`
--
DROP TABLE IF EXISTS `ticket_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ticket_view`  AS SELECT `ticket_class`.`ticket_id` AS `ticket_id`, `ticket_class`.`customer_id` AS `customer_id`, `ticket_class`.`bus_id` AS `bus_id`, `ticket_class`.`driver_id` AS `driver_id`, `ticket_class`.`ticket_from` AS `ticket_from`, `ticket_class`.`ticket_to` AS `ticket_to`, `ticket_class`.`ticket_date` AS `ticket_date` FROM `ticket_class` WHERE `ticket_class`.`ticket_id` = 11  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bus_class`
--
ALTER TABLE `bus_class`
  ADD PRIMARY KEY (`bus_id`);

--
-- Indexes for table `customer_class`
--
ALTER TABLE `customer_class`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `driver_class`
--
ALTER TABLE `driver_class`
  ADD PRIMARY KEY (`driver_id`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `ticket_class`
--
ALTER TABLE `ticket_class`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `driver_ticket` (`driver_id`),
  ADD KEY `customer_ticket` (`customer_id`),
  ADD KEY `bus_ticket` (`bus_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
