-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 11:59 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seeker-provider`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dep_id` varchar(30) NOT NULL,
  `dep_name` varchar(30) NOT NULL,
  `contact` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_id`, `dep_name`, `contact`) VALUES
('233', 'finance', 7876333),
('234', 'finance', 788891),
('A274', 'Marketing', 788888888),
('A277', 'Maintenance', 789374556);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `job_id` varchar(30) NOT NULL,
  `job_time` varchar(30) NOT NULL,
  `job_name` varchar(30) NOT NULL,
  `Contacts` int(15) NOT NULL,
  `salary` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`job_id`, `job_time`, `job_name`, `Contacts`, `salary`) VALUES
('132', '06h-12h', 'manager', 7899998, '25000'),
('A23', '06h-20h', 'Finnance', 788440746, '250.000 Rwf'),
('A250', '06h-20h', 'Accounting', 788440756, '150.000 Rwf');

-- --------------------------------------------------------

--
-- Table structure for table `provider`
--

CREATE TABLE `provider` (
  `provider_id` varchar(30) NOT NULL,
  `Fname` varchar(30) NOT NULL,
  `Lname` varchar(30) NOT NULL,
  `Contacts` int(15) NOT NULL,
  `Address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `provider`
--

INSERT INTO `provider` (`provider_id`, `Fname`, `Lname`, `Contacts`, `Address`) VALUES
('123', 'sallam', 'kucyaro', 786987, 'KIGALI'),
('222', 'GABALE', 'EVEE', 7897654, 'KIGALI'),
('SK440', 'Uwayo', 'mistaek', 79224828, 'KIGALI'),
('SK788', 'Hanyurwimfura', 'Joseph', 788440749, 'KIGALI');

--
-- Triggers `provider`
--
DELIMITER $$
CREATE TRIGGER `DELETEproviderAlert` AFTER INSERT ON `provider` FOR EACH ROW BEGIN  
DELETE FROM `provider` WHERE `provider`.`provider_id` = 123; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateproviderAlert` AFTER INSERT ON `provider` FOR EACH ROW BEGIN  
UPDATE `provider` SET `provider_id` = 'A56', `Fname` = 'joseph',`Contacts` = '078864536',`Address` = 'gasabo' WHERE `provider`.`provider_id` = 123;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertproviderAlert` AFTER INSERT ON `provider` FOR EACH ROW BEGIN  
INSERT INTO `dos` (`provider_id`, `Fname`, `Lname`, `Contacts`,`Address`) VALUES ('97', 'shema', 'gashegu','07364321', 'Kigali'); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `seeker`
--

CREATE TABLE `seeker` (
  `seeker_id` varchar(30) NOT NULL,
  `Fname` varchar(30) NOT NULL,
  `Lname` varchar(30) NOT NULL,
  `address` varchar(15) NOT NULL,
  `contacts` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seeker`
--

INSERT INTO `seeker` (`seeker_id`, `Fname`, `Lname`, `address`, `contacts`) VALUES
('234', 'rugwiro', 'vilaje', 'KIGALI', 786554),
('SK222', 'Gasana', 'Vincent', 'KIGALI', 788277823),
('SK333', 'Hart', 'Kevin', 'KIGALI', 78886789),
('SK749', 'Bushali', 'Mukwaha', 'KIGALI', 788346611);

--
-- Triggers `seeker`
--
DELIMITER $$
CREATE TRIGGER `DELETEseekerAlert` AFTER INSERT ON `seeker` FOR EACH ROW BEGIN  
DELETE FROM `seeker` WHERE `seeker`.`seeker_id` = 234; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateseekerAlert` AFTER INSERT ON `seeker` FOR EACH ROW BEGIN  
UPDATE `seeker` SET `seeker_id` = '56', `Fname` = 'joel',`Lname` = 'joel',`contacts` = '07868756',`address` = 'nyamagabe' WHERE `student`.`st_id` = 2;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`provider_id`);

--
-- Indexes for table `seeker`
--
ALTER TABLE `seeker`
  ADD PRIMARY KEY (`seeker_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
