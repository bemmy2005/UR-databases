-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 12:00 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sarah_ishimwe`
--
CREATE DATABASE IF NOT EXISTS `sarah_ishimwe` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `sarah_ishimwe`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `getCATEGORY`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCATEGORY` ()  BEGIN  SELECT * FROM CATEGORY ;END$$

DROP PROCEDURE IF EXISTS `getCUSTOMER`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCUSTOMER` ()  BEGIN  SELECT * FROM CUSTOMER; END$$

DROP PROCEDURE IF EXISTS `getDELIVERY`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getDELIVERY` ()  BEGIN  SELECT * FROM DELIVERY;END$$

DROP PROCEDURE IF EXISTS `getMANAGER`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getMANAGER` ()  BEGIN  SELECT * FROM MANAGER;END$$

DROP PROCEDURE IF EXISTS `getORDER`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getORDER` ()  BEGIN  SELECT * FROM orders ;END$$

DROP PROCEDURE IF EXISTS `getPAYMENT`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPAYMENT` ()  BEGIN  SELECT * FROM PAYMENT ;END$$

DROP PROCEDURE IF EXISTS `getPRODUCT`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPRODUCT` ()  BEGIN  SELECT * FROM PRODUCT ;END$$

DROP PROCEDURE IF EXISTS `getRESTAURANT`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getRESTAURANT` ()  BEGIN  SELECT * FROM RESTAURANT ;END$$

DROP PROCEDURE IF EXISTS `getREVIEW`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getREVIEW` ()  BEGIN  SELECT * FROM REVIEW ;END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int(10) NOT NULL,
  `category_name` char(30) NOT NULL,
  `categoty_type` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `categories`:
--

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `categoty_type`) VALUES
(1, 'meet', 'chicken'),
(2, 'juice', 'mango'),
(3, 'meet', 'chicken'),
(4, 'juice', 'mango');

--
-- Triggers `categories`
--
DROP TRIGGER IF EXISTS `categoriestrigger`;
DELIMITER $$
CREATE TRIGGER `categoriestrigger` AFTER UPDATE ON `categories` FOR EACH ROW UPDATE categories SET category_name=’inyama’ WHERE category_id=’1’
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customer_id` int(10) NOT NULL,
  `fname` char(20) DEFAULT NULL,
  `lname` char(20) DEFAULT NULL,
  `email` tinytext DEFAULT NULL,
  `address` char(30) DEFAULT NULL,
  `password` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `customer`:
--

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `fname`, `lname`, `email`, `address`, `password`) VALUES
(1, 'Sarah', 'ISHIMWE', 'ishimwesarah09@gmail.com', 'Tumba', '1234'),
(2, 'Dorcas', 'UWERA', 'kayitesidorcas@gmail.com', 'Ngoma', 'doro@123'),
(3, 'Sarah', 'ISHIMWE', 'ishimwesarah09@gmail.com', 'Tumba', '1234');

--
-- Triggers `customer`
--
DROP TRIGGER IF EXISTS `customertrigger`;
DELIMITER $$
CREATE TRIGGER `customertrigger` AFTER INSERT ON `customer` FOR EACH ROW INSERT INTO customer VALUES(NEW. customer_id)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
CREATE TABLE `delivery` (
  `delivery_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `quantity` int(10) DEFAULT NULL,
  `payment_id` int(10) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `delivery`:
--   `customer_id`
--       `customer` -> `customer_id`
--   `product_id`
--       `product` -> `product_id`
--   `payment_id`
--       `payment` -> `payment_id`
--

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`delivery_id`, `customer_id`, `product_id`, `quantity`, `payment_id`, `date`) VALUES
(1, 2, 2, 3, 1, '2022-06-25'),
(2, 2, 2, 4, 2, '2022-06-25'),
(3, 2, 2, 3, 1, '2022-06-25'),
(4, 2, 2, 4, 2, '2022-06-25');

-- --------------------------------------------------------

--
-- Stand-in structure for view `listcategories`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listcategories`;
CREATE TABLE `listcategories` (
`category_id` int(10)
,`category_name` char(30)
,`categoty_type` char(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listcustomer`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listcustomer`;
CREATE TABLE `listcustomer` (
`customer_id` int(10)
,`fname` char(20)
,`lname` char(20)
,`email` tinytext
,`address` char(30)
,`password` tinytext
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listdelivery`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listdelivery`;
CREATE TABLE `listdelivery` (
`delivery_id` int(10)
,`customer_id` int(10)
,`product_id` int(10)
,`quantity` int(10)
,`payment_id` int(10)
,`date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listmanager`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listmanager`;
CREATE TABLE `listmanager` (
`manager_id` int(10)
,`fname` char(20)
,`lname` char(20)
,`phone` int(10)
,`password` text
,`restaurant_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listorder`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listorder`;
CREATE TABLE `listorder` (
`order_id` int(10)
,`customer_id` int(10)
,`product_id` int(10)
,`quantity` int(10)
,`delivery_id` int(10)
,`date` date
,`totalAmount` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listpayment`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listpayment`;
CREATE TABLE `listpayment` (
`payment_id` int(10)
,`customer_id` int(10)
,`Date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listproduct`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listproduct`;
CREATE TABLE `listproduct` (
`product_id` int(10)
,`name` char(20)
,`description` char(30)
,`price` decimal(10,0)
,`image` text
,`category_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listrestaurant`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listrestaurant`;
CREATE TABLE `listrestaurant` (
`restaurant_id` int(10)
,`name` char(20)
,`phone` int(10)
,`location` text
,`delivery_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listreview`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listreview`;
CREATE TABLE `listreview` (
`customer_id` int(10)
,`grade` int(1)
,`commment` text
,`restaurant_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `manager_id` int(10) NOT NULL,
  `fname` char(20) DEFAULT NULL,
  `lname` char(20) DEFAULT NULL,
  `phone` int(10) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `restaurant_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `manager`:
--   `restaurant_id`
--       `restaurant` -> `restaurant_id`
--

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`manager_id`, `fname`, `lname`, `phone`, `password`, `restaurant_id`) VALUES
(1, 'Sarah', 'ISHIMWE', 784711354, 'sarah@123', 1),
(2, 'Sarah', 'ISHIMWE', 784711354, 'sarah@123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `quantity` int(10) DEFAULT NULL,
  `delivery_id` int(10) NOT NULL,
  `date` date DEFAULT NULL,
  `totalAmount` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `orders`:
--   `customer_id`
--       `customer` -> `customer_id`
--   `product_id`
--       `product` -> `product_id`
--   `delivery_id`
--       `delivery` -> `delivery_id`
--

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `product_id`, `quantity`, `delivery_id`, `date`, `totalAmount`) VALUES
(1, 2, 1, 4, 1, '2022-06-27', 12000),
(2, 2, 1, 3, 1, '2022-05-18', 9000),
(3, 2, 1, 4, 1, '2022-06-27', 12000),
(4, 2, 1, 3, 1, '2022-05-18', 9000);

--
-- Triggers `orders`
--
DROP TRIGGER IF EXISTS `orderstrigger`;
DELIMITER $$
CREATE TRIGGER `orderstrigger` AFTER UPDATE ON `orders` FOR EACH ROW UPDATE orders SET totalAmaount='totalAmaount-1000' WHERE order_id='1'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `payment_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `payment`:
--   `customer_id`
--       `customer` -> `customer_id`
--

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `customer_id`, `Date`) VALUES
(1, 2, '2022-06-26'),
(2, 2, '0000-00-00'),
(3, 2, '2022-06-26');

--
-- Triggers `payment`
--
DROP TRIGGER IF EXISTS `paymenttrigger`;
DELIMITER $$
CREATE TRIGGER `paymenttrigger` AFTER INSERT ON `payment` FOR EACH ROW INSERT INTO payment VALUES(new. payment_id)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_id` int(10) NOT NULL,
  `name` char(20) DEFAULT NULL,
  `description` char(30) DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `category_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `product`:
--   `category_id`
--       `categories` -> `category_id`
--

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `name`, `description`, `price`, `image`, `category_id`) VALUES
(1, 'meet', 'chicken meet', '2000', '', 2),
(2, 'juice', 'mango juice', '700', '', 1),
(3, 'meet', 'chicken meet', '2000', '', 2),
(4, 'juice', 'mango juice', '700', '', 1);

--
-- Triggers `product`
--
DROP TRIGGER IF EXISTS `producttrigger`;
DELIMITER $$
CREATE TRIGGER `producttrigger` AFTER DELETE ON `product` FOR EACH ROW DELETE FROM product WHERE product_id=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
CREATE TABLE `restaurant` (
  `restaurant_id` int(10) NOT NULL,
  `name` char(20) DEFAULT NULL,
  `phone` int(10) DEFAULT NULL,
  `location` text DEFAULT NULL,
  `delivery_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `restaurant`:
--   `delivery_id`
--       `delivery` -> `delivery_id`
--

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`restaurant_id`, `name`, `phone`, `location`, `delivery_id`) VALUES
(1, 'Happiness', 788689898, 'UR Huye campus', 1),
(2, 'Happiness', 788678695, 'Amoris', 1),
(3, 'Happiness', 788689898, 'UR Huye campus', 1),
(4, 'Happiness', 788678695, 'Amoris', 1);

--
-- Triggers `restaurant`
--
DROP TRIGGER IF EXISTS `restauranttrigger`;
DELIMITER $$
CREATE TRIGGER `restauranttrigger` AFTER DELETE ON `restaurant` FOR EACH ROW DELETE FROM restaurant where restaurant_id =1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
CREATE TABLE `review` (
  `customer_id` int(10) NOT NULL,
  `grade` int(1) DEFAULT NULL,
  `commment` text DEFAULT NULL,
  `restaurant_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `review`:
--   `customer_id`
--       `customer` -> `customer_id`
--   `restaurant_id`
--       `restaurant` -> `restaurant_id`
--

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`customer_id`, `grade`, `commment`, `restaurant_id`) VALUES
(2, 3, 'This restaurant is best', 2),
(3, 3, 'This restaurant is best', 2);

-- --------------------------------------------------------

--
-- Structure for view `listcategories` exported as a table
--
DROP TABLE IF EXISTS `listcategories`;
CREATE TABLE`listcategories`(
    `category_id` int(10) NOT NULL,
    `category_name` char(30) COLLATE utf8mb4_general_ci NOT NULL,
    `categoty_type` char(20) COLLATE utf8mb4_general_ci NOT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listcustomer` exported as a table
--
DROP TABLE IF EXISTS `listcustomer`;
CREATE TABLE`listcustomer`(
    `customer_id` int(10) NOT NULL,
    `fname` char(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `lname` char(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `email` tinytext COLLATE utf8mb4_general_ci DEFAULT NULL,
    `address` char(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `password` tinytext COLLATE utf8mb4_general_ci DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listdelivery` exported as a table
--
DROP TABLE IF EXISTS `listdelivery`;
CREATE TABLE`listdelivery`(
    `delivery_id` int(10) NOT NULL,
    `customer_id` int(10) NOT NULL,
    `product_id` int(10) NOT NULL,
    `quantity` int(10) DEFAULT NULL,
    `payment_id` int(10) NOT NULL,
    `date` date DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listmanager` exported as a table
--
DROP TABLE IF EXISTS `listmanager`;
CREATE TABLE`listmanager`(
    `manager_id` int(10) NOT NULL,
    `fname` char(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `lname` char(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `phone` int(10) DEFAULT NULL,
    `password` text COLLATE utf8mb4_general_ci DEFAULT NULL,
    `restaurant_id` int(10) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listorder` exported as a table
--
DROP TABLE IF EXISTS `listorder`;
CREATE TABLE`listorder`(
    `order_id` int(10) NOT NULL,
    `customer_id` int(10) NOT NULL,
    `product_id` int(10) NOT NULL,
    `quantity` int(10) DEFAULT NULL,
    `delivery_id` int(10) NOT NULL,
    `date` date DEFAULT NULL,
    `totalAmount` int(10) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listpayment` exported as a table
--
DROP TABLE IF EXISTS `listpayment`;
CREATE TABLE`listpayment`(
    `payment_id` int(10) NOT NULL,
    `customer_id` int(10) NOT NULL,
    `Date` date DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listproduct` exported as a table
--
DROP TABLE IF EXISTS `listproduct`;
CREATE TABLE`listproduct`(
    `product_id` int(10) NOT NULL,
    `name` char(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `description` char(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `price` decimal(10,0) DEFAULT NULL,
    `image` text COLLATE utf8mb4_general_ci DEFAULT NULL,
    `category_id` int(10) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listrestaurant` exported as a table
--
DROP TABLE IF EXISTS `listrestaurant`;
CREATE TABLE`listrestaurant`(
    `restaurant_id` int(10) NOT NULL,
    `name` char(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `phone` int(10) DEFAULT NULL,
    `location` text COLLATE utf8mb4_general_ci DEFAULT NULL,
    `delivery_id` int(10) NOT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listreview` exported as a table
--
DROP TABLE IF EXISTS `listreview`;
CREATE TABLE`listreview`(
    `customer_id` int(10) NOT NULL,
    `grade` int(1) DEFAULT NULL,
    `commment` text COLLATE utf8mb4_general_ci DEFAULT NULL,
    `restaurant_id` int(10) NOT NULL
);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`delivery_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `payment_id` (`payment_id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`manager_id`),
  ADD KEY `restaurant_id` (`restaurant_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `delivery_id` (`delivery_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`restaurant_id`),
  ADD KEY `delivery_id` (`delivery_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `restaurant_id` (`restaurant_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `delivery`
--
ALTER TABLE `delivery`
  ADD CONSTRAINT `delivery_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `delivery_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `delivery_ibfk_3` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`);

--
-- Constraints for table `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`restaurant_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`delivery_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD CONSTRAINT `restaurant_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`delivery_id`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`restaurant_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
