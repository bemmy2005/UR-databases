-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 11:27 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `bookp` (IN `bID` VARCHAR(30))   BEGIN
    delete from book where bookname=humanresources;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lecturep` (IN `lectID` VARCHAR(30))   BEGIN
    update lecture set fname= fname+ DR where lectID=10;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `studentp` (IN `stid` INT(10))   BEGIN
    update student set fname=mike;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `username` varchar(7) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `PASSWORD`) VALUES
(1, 'coordin', 'urcampis@123'),
(2, 'registe', 'campusur@123');

-- --------------------------------------------------------

--
-- Stand-in structure for view `adminv`
-- (See below for the actual view)
--
CREATE TABLE `adminv` (
`id` int(10)
,`username` varchar(7)
,`PASSWORD` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bid` int(10) NOT NULL,
  `bookname` varchar(30) DEFAULT NULL,
  `barcode` varchar(30) DEFAULT NULL,
  `edition` varchar(20) DEFAULT NULL,
  `lectid` int(10) DEFAULT NULL,
  `stid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bid`, `bookname`, `barcode`, `edition`, `lectid`, `stid`) VALUES
(1, 'human resources', '#123345#6', '3th edition', 10, 1),
(12, 'economics', '1234#$', 'fifth edition', 10, 1);

--
-- Triggers `book`
--
DELIMITER $$
CREATE TRIGGER `bookT` AFTER INSERT ON `book` FOR EACH ROW BEGIN  
update book set bookname=bookname+1; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `bookTm` AFTER UPDATE ON `book` FOR EACH ROW BEGIN  
update book set bookname=bookname+ 4thedition; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `bookm` AFTER DELETE ON `book` FOR EACH ROW BEGIN  
update book set bookname=bookname+ 4thedition; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `bookv`
-- (See below for the actual view)
--
CREATE TABLE `bookv` (
`bid` int(10)
,`bookname` varchar(30)
,`barcode` varchar(30)
,`edition` varchar(20)
,`lectid` int(10)
,`stid` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `lecture`
--

CREATE TABLE `lecture` (
  `lectid` int(10) NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Phone_number` int(10) NOT NULL,
  `email` varchar(8) NOT NULL,
  `BID` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecture`
--

INSERT INTO `lecture` (`lectid`, `Fname`, `Lname`, `Gender`, `Phone_number`, `email`, `BID`) VALUES
(1, 'SHEMA', 'Jean Cloude', 'F', 785678987, '', NULL),
(2, 'gashugi', 'dismas', 'M', 789098765, 'gashugi@', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `lecturev`
-- (See below for the actual view)
--
CREATE TABLE `lecturev` (
`lectid` int(10)
,`Fname` varchar(50)
,`Lname` varchar(50)
,`Gender` varchar(6)
,`Phone_number` int(10)
,`email` varchar(8)
,`BID` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stid` int(10) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `school` varchar(20) NOT NULL,
  `department` varchar(20) NOT NULL,
  `phonenumber` varchar(13) NOT NULL,
  `email` varchar(20) NOT NULL,
  `regnumber` int(10) NOT NULL,
  `bid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stid`, `fname`, `lname`, `gender`, `school`, `department`, `phonenumber`, `email`, `regnumber`, `bid`) VALUES
(1, 'MUHOZA', 'Judith', 'F', 'business', 'bbit', '0786898765', 'muhoza@gmail.com', 221003008, NULL);

--
-- Triggers `student`
--
DELIMITER $$
CREATE TRIGGER `studentT` AFTER INSERT ON `student` FOR EACH ROW BEGIN  
update student set fname=fname+ mr; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `studentTm` AFTER UPDATE ON `student` FOR EACH ROW BEGIN  
update student set fname=fname+ ms; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `studentm` AFTER DELETE ON `student` FOR EACH ROW BEGIN  
update student set fname=mike+ dr; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `studentv`
-- (See below for the actual view)
--
CREATE TABLE `studentv` (
`stid` int(10)
,`fname` varchar(20)
,`lname` varchar(20)
,`gender` varchar(5)
,`school` varchar(20)
,`department` varchar(20)
,`phonenumber` varchar(13)
,`email` varchar(20)
,`regnumber` int(10)
,`bid` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `subquery`
-- (See below for the actual view)
--
CREATE TABLE `subquery` (
`lectid` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `system`
-- (See below for the actual view)
--
CREATE TABLE `system` (
`bid` int(10)
,`bookname` varchar(30)
,`barcode` varchar(30)
,`edition` varchar(20)
,`lectid` int(10)
,`stid` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `systema`
-- (See below for the actual view)
--
CREATE TABLE `systema` (
`lectid` int(10)
,`Fname` varchar(50)
,`Lname` varchar(50)
,`Gender` varchar(6)
,`Phone_number` int(10)
,`email` varchar(8)
,`BID` int(10)
);

-- --------------------------------------------------------

--
-- Structure for view `adminv`
--
DROP TABLE IF EXISTS `adminv`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `adminv`  AS SELECT `admin`.`id` AS `id`, `admin`.`username` AS `username`, `admin`.`PASSWORD` AS `PASSWORD` FROM `admin``admin`  ;

-- --------------------------------------------------------

--
-- Structure for view `bookv`
--
DROP TABLE IF EXISTS `bookv`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bookv`  AS SELECT `book`.`bid` AS `bid`, `book`.`bookname` AS `bookname`, `book`.`barcode` AS `barcode`, `book`.`edition` AS `edition`, `book`.`lectid` AS `lectid`, `book`.`stid` AS `stid` FROM `book``book`  ;

-- --------------------------------------------------------

--
-- Structure for view `lecturev`
--
DROP TABLE IF EXISTS `lecturev`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lecturev`  AS SELECT `lecture`.`lectid` AS `lectid`, `lecture`.`Fname` AS `Fname`, `lecture`.`Lname` AS `Lname`, `lecture`.`Gender` AS `Gender`, `lecture`.`Phone_number` AS `Phone_number`, `lecture`.`email` AS `email`, `lecture`.`BID` AS `BID` FROM `lecture``lecture`  ;

-- --------------------------------------------------------

--
-- Structure for view `studentv`
--
DROP TABLE IF EXISTS `studentv`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `studentv`  AS SELECT `student`.`stid` AS `stid`, `student`.`fname` AS `fname`, `student`.`lname` AS `lname`, `student`.`gender` AS `gender`, `student`.`school` AS `school`, `student`.`department` AS `department`, `student`.`phonenumber` AS `phonenumber`, `student`.`email` AS `email`, `student`.`regnumber` AS `regnumber`, `student`.`bid` AS `bid` FROM `student``student`  ;

-- --------------------------------------------------------

--
-- Structure for view `subquery`
--
DROP TABLE IF EXISTS `subquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subquery`  AS SELECT `lecture`.`stid` AS `lectid` FROM `student` AS `lecture` WHERE `lecture`.`stid` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `system`
--
DROP TABLE IF EXISTS `system`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `system`  AS SELECT `student`.`bid` AS `bid`, `student`.`bookname` AS `bookname`, `student`.`barcode` AS `barcode`, `student`.`edition` AS `edition`, `student`.`lectid` AS `lectid`, `student`.`stid` AS `stid` FROM `book` AS `student``student`  ;

-- --------------------------------------------------------

--
-- Structure for view `systema`
--
DROP TABLE IF EXISTS `systema`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `systema`  AS SELECT `admin`.`lectid` AS `lectid`, `admin`.`Fname` AS `Fname`, `admin`.`Lname` AS `Lname`, `admin`.`Gender` AS `Gender`, `admin`.`Phone_number` AS `Phone_number`, `admin`.`email` AS `email`, `admin`.`BID` AS `BID` FROM `lecture` AS `admin``admin`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `stid` (`stid`);

--
-- Indexes for table `lecture`
--
ALTER TABLE `lecture`
  ADD PRIMARY KEY (`lectid`),
  ADD KEY `BID` (`BID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stid`),
  ADD KEY `bid` (`bid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `bid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lecture`
--
ALTER TABLE `lecture`
  MODIFY `lectid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`stid`) REFERENCES `student` (`stid`),
  ADD CONSTRAINT `book_ibfk_2` FOREIGN KEY (`stid`) REFERENCES `student` (`stid`);

--
-- Constraints for table `lecture`
--
ALTER TABLE `lecture`
  ADD CONSTRAINT `lecture_ibfk_1` FOREIGN KEY (`BID`) REFERENCES `book` (`bid`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `book` (`bid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
