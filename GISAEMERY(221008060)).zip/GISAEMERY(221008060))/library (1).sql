-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 27, 2022 at 04:19 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bid` int(255) NOT NULL,
  `bookname` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bid`, `bookname`, `category`, `author`) VALUES
(2, 'c++', 'religion', 'james'),
(3, 'visual', 'ict', 'bwerere');

--
-- Triggers `book`
--
DELIMITER $$
CREATE TRIGGER `book_delete` AFTER DELETE ON `book` FOR EACH ROW DELETE FROM book WHERE bid='3'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `book_triger` AFTER INSERT ON `book` FOR EACH ROW INSERT into book VALUES('4','building','religion','Jesus')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `book_udate` AFTER UPDATE ON `book` FOR EACH ROW UPDATE book SET bookname='kwiga' WHERE bid='3'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `booking`
-- (See below for the actual view)
--
CREATE TABLE `booking` (
`firstname` varchar(255)
,`lastname` varchar(255)
,`bookname` varchar(255)
,`category` varchar(255)
,`borrowdate` date
,`returndate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `book_view`
-- (See below for the actual view)
--
CREATE TABLE `book_view` (
`bid` int(255)
,`bookname` varchar(255)
,`category` varchar(255)
,`author` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `borrowing`
--

CREATE TABLE `borrowing` (
  `borrowingid` int(255) NOT NULL,
  `bid` int(255) NOT NULL,
  `stid` int(255) NOT NULL,
  `borrowdate` date NOT NULL,
  `returndate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrowing`
--

INSERT INTO `borrowing` (`borrowingid`, `bid`, `stid`, `borrowdate`, `returndate`) VALUES
(100, 2, 1, '2022-07-11', '2022-07-18'),
(101, 2, 1, '2022-07-03', '2022-07-13'),
(300, 2, 1, '2022-08-04', '2023-01-03');

-- --------------------------------------------------------

--
-- Stand-in structure for view `final`
-- (See below for the actual view)
--
CREATE TABLE `final` (
`firstname` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listbook`
-- (See below for the actual view)
--
CREATE TABLE `listbook` (
`bid` int(255)
,`bookname` varchar(255)
,`category` varchar(255)
,`author` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listborrowing`
-- (See below for the actual view)
--
CREATE TABLE `listborrowing` (
`borrowingid` int(255)
,`bid` int(255)
,`stid` int(255)
,`borrowdate` date
,`returndate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `liststudent`
-- (See below for the actual view)
--
CREATE TABLE `liststudent` (
`stid` int(255)
,`firstname` varchar(255)
,`stdepartment` varchar(255)
,`lastname` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `my_booking`
-- (See below for the actual view)
--
CREATE TABLE `my_booking` (
`firstname` varchar(255)
,`lastname` varchar(255)
,`bookname` varchar(255)
,`category` varchar(255)
,`borrowdate` date
,`returndate` date
);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stid` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `stdepartment` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stid`, `firstname`, `stdepartment`, `lastname`) VALUES
(1, 'gisa', 'bit', 'emery'),
(2, 'ndizihiwe', 'statistics', 'benny'),
(3, 'Hugo', 'drawing', 'lloris'),
(4, 'gof', 'statistics', 'bwiza');

-- --------------------------------------------------------

--
-- Structure for view `booking`
--
DROP TABLE IF EXISTS `booking`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `booking`  AS SELECT `student`.`firstname` AS `firstname`, `student`.`lastname` AS `lastname`, `book`.`bookname` AS `bookname`, `book`.`category` AS `category`, `borrowing`.`borrowdate` AS `borrowdate`, `borrowing`.`returndate` AS `returndate` FROM ((`book` join `student`) join `borrowing`) WHERE `borrowing`.`bid` = `book`.`bid` AND `borrowing`.`stid` = `student`.`stid``stid`  ;

-- --------------------------------------------------------

--
-- Structure for view `book_view`
--
DROP TABLE IF EXISTS `book_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `book_view`  AS SELECT `book`.`bid` AS `bid`, `book`.`bookname` AS `bookname`, `book`.`category` AS `category`, `book`.`author` AS `author` FROM `book``book`  ;

-- --------------------------------------------------------

--
-- Structure for view `final`
--
DROP TABLE IF EXISTS `final`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `final`  AS SELECT `student`.`firstname` AS `firstname` FROM `student` WHERE !(`student`.`firstname` in (select `borrowing`.`stid` from `borrowing`))  ;

-- --------------------------------------------------------

--
-- Structure for view `listbook`
--
DROP TABLE IF EXISTS `listbook`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listbook`  AS SELECT `book`.`bid` AS `bid`, `book`.`bookname` AS `bookname`, `book`.`category` AS `category`, `book`.`author` AS `author` FROM `book``book`  ;

-- --------------------------------------------------------

--
-- Structure for view `listborrowing`
--
DROP TABLE IF EXISTS `listborrowing`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listborrowing`  AS SELECT `borrowing`.`borrowingid` AS `borrowingid`, `borrowing`.`bid` AS `bid`, `borrowing`.`stid` AS `stid`, `borrowing`.`borrowdate` AS `borrowdate`, `borrowing`.`returndate` AS `returndate` FROM `borrowing``borrowing`  ;

-- --------------------------------------------------------

--
-- Structure for view `liststudent`
--
DROP TABLE IF EXISTS `liststudent`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `liststudent`  AS SELECT `student`.`stid` AS `stid`, `student`.`firstname` AS `firstname`, `student`.`stdepartment` AS `stdepartment`, `student`.`lastname` AS `lastname` FROM `student``student`  ;

-- --------------------------------------------------------

--
-- Structure for view `my_booking`
--
DROP TABLE IF EXISTS `my_booking`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `my_booking`  AS SELECT `student`.`firstname` AS `firstname`, `student`.`lastname` AS `lastname`, `book`.`bookname` AS `bookname`, `book`.`category` AS `category`, `borrowing`.`borrowdate` AS `borrowdate`, `borrowing`.`returndate` AS `returndate` FROM ((`book` join `student`) join `borrowing`) WHERE `borrowing`.`bid` = `book`.`bid` AND `borrowing`.`stid` = `student`.`stid``stid`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD PRIMARY KEY (`borrowingid`),
  ADD KEY `student_borrowing` (`stid`),
  ADD KEY `book_borrowing` (`bid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `bid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `borrowing`
--
ALTER TABLE `borrowing`
  MODIFY `borrowingid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=301;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD CONSTRAINT `book_borrowing` FOREIGN KEY (`bid`) REFERENCES `book` (`bid`),
  ADD CONSTRAINT `student_borrowing` FOREIGN KEY (`stid`) REFERENCES `student` (`stid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
