-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20220719.04fabfdc7e
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2022 at 06:57 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cyuzuzo_patience_22100331952`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteappinfo` ()   BEGIN
    DELETE FROM `applicationinfo` WHERE `applicationinfo`.`Appid` = 3;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deletsellerinfo` ()   BEGIN
    DELETE FROM `sellerinfo` WHERE `sellerinfo`.`sid` = 2;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `gepaymentDetails` ()   BEGIN
    select * from payment;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getApplicationDetails` ()   BEGIN
    select * from application;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getapprovalDetails` ()   BEGIN
    select * from approval;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getbuyerInformation` ()   BEGIN
    select * from buyer;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getHouseDetails` ()   BEGIN
    select * from house;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getSellerInfromation` ()   BEGIN
    select * from seller;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InserInbuyer` ()   BEGIN
    insert into Buyer (Bid,Bfname,Blname,Bgender,Bprovince,Bdistrict,Bsector,Bcell,Bvillage,Bstreetnumber,Bphonenumber) values('2','patienceeee','Cyuuuuzuzo','F','western','nyaamasheke','shuangi','buurimba','ngobtoka','270','0788751324');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertInApproval` ()   BEGIN
    insert into Approval (Apprid,Apprdate) values('1','7/18/2022');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertInHouse` ()   BEGIN
    insert into House (Hid,Htype,Hsize,Hprice,Hprovince,Hdistrict,Hsector,Hcell,Hvillage,Hstreetnumber) values('2','shatto','long','40M','eastern','rutsiro','nyabitekeri','mariba','bugomba','252');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertInPayment` ()   BEGIN
   insert into Payment (Payid,Paydate) values('001','7/18/2022');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertInSeller` ()   BEGIN
    insert into Seller (Sid,Sfname,Slname,Sgender,Sprovince,Sdistrict,Ssector,Scell,Svillage,Sstreetnumber,Sphonenumber) values('2','nicolaqs','shdema','M','western','rubavu','gisenyi','nyamyumba','gasharu','251','0788751325');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoapplication` ()   BEGIN
    insert into Application (Appid,Appdate,Numberofhouse) values('01','7/18/2022','5');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatebuyerDetails` ()   BEGIN
  UPDATE `Buyer` SET `Bprovince` = 'sourthern' WHERE `Buyer`.`Bid` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatesellerDetails` ()   BEGIN
    UPDATE `Seller` SET `Sprovince` = 'northern' WHERE `Seller`.`Sid` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `viewappDetails` ()   BEGIN
    CREATE VIEW applicationinfo1 AS SELECT* FROM application WHERE Numberofhouse>(SELECT AVG(Numberofhouse));
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `Appid` int(5) NOT NULL,
  `Appdate` date NOT NULL,
  `Numberofhouse` int(3) NOT NULL,
  `Bid` int(5) DEFAULT NULL,
  `Hid` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`Appid`, `Appdate`, `Numberofhouse`, `Bid`, `Hid`) VALUES
(1, '0000-00-00', 5, NULL, NULL),
(6, '0000-00-00', 3, 1, 1);

--
-- Triggers `application`
--
DELIMITER $$
CREATE TRIGGER `updatealert` AFTER UPDATE ON `application` FOR EACH ROW UPDATE payment SET payment.Payid= Payid+1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `applicationinfo`
-- (See below for the actual view)
--
CREATE TABLE `applicationinfo` (
`Appid` int(5)
,`Appdate` date
,`Numberofhouse` int(3)
,`Bid` int(5)
,`Hid` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `applicationinfo1`
-- (See below for the actual view)
--
CREATE TABLE `applicationinfo1` (
`Appid` int(5)
,`Appdate` date
,`Numberofhouse` int(3)
,`Bid` int(5)
,`Hid` int(5)
);

-- --------------------------------------------------------

--
-- Table structure for table `approval`
--

CREATE TABLE `approval` (
  `Apprid` int(5) NOT NULL,
  `Apprdate` date NOT NULL,
  `Payid` int(5) DEFAULT NULL,
  `Sid` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approval`
--

INSERT INTO `approval` (`Apprid`, `Apprdate`, `Payid`, `Sid`) VALUES
(1, '0000-00-00', NULL, NULL),
(2, '2022-07-19', 1, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `approvalinfo`
-- (See below for the actual view)
--
CREATE TABLE `approvalinfo` (
`Apprid` int(5)
,`Apprdate` date
,`Payid` int(5)
,`Sid` int(5)
);

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE `buyer` (
  `Bid` int(5) NOT NULL,
  `Bfname` varchar(15) NOT NULL,
  `Blname` varchar(15) NOT NULL,
  `Bgender` varchar(2) NOT NULL,
  `Bprovince` varchar(15) NOT NULL,
  `Bdistrict` varchar(15) NOT NULL,
  `Bsector` varchar(15) NOT NULL,
  `Bcell` varchar(15) NOT NULL,
  `Bvillage` varchar(15) NOT NULL,
  `Bstreetnumber` int(5) NOT NULL,
  `Bphonenumber` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buyer`
--

INSERT INTO `buyer` (`Bid`, `Bfname`, `Blname`, `Bgender`, `Bprovince`, `Bdistrict`, `Bsector`, `Bcell`, `Bvillage`, `Bstreetnumber`, `Bphonenumber`) VALUES
(1, 'paccy', 'Cyuzuzo', 'F', 'western', 'nyamasheke', 'shangi', 'burimba', 'ngoboka', 250, 788751324),
(2, 'patienceeee', 'Cyuuuuzuzo', 'F', 'western', 'nyaamasheke', 'shuangi', 'buurimba', 'ngobtoka', 270, 788751324),
(3, 'gideon', 'mutabazi', 'M', 'kigaliCity', 'gasabo', 'remera', 'rukiri', 'ruturusu', 255, 788127535);

--
-- Triggers `buyer`
--
DELIMITER $$
CREATE TRIGGER `InsertAlert` AFTER INSERT ON `buyer` FOR EACH ROW INSERT INTO application VALUES (6,7/20/2022,3,1,1)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `deletealert2` AFTER DELETE ON `buyer` FOR EACH ROW DELETE FROM application WHERE application.Bid= buyer.Bid
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `buyerinfo`
-- (See below for the actual view)
--
CREATE TABLE `buyerinfo` (
`Bid` int(5)
,`Bfname` varchar(15)
,`Blname` varchar(15)
,`Bgender` varchar(2)
,`Bprovince` varchar(15)
,`Bdistrict` varchar(15)
,`Bsector` varchar(15)
,`Bcell` varchar(15)
,`Bvillage` varchar(15)
,`Bstreetnumber` int(5)
,`Bphonenumber` int(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `house`
--

CREATE TABLE `house` (
  `Hid` int(5) NOT NULL,
  `Htype` varchar(10) NOT NULL,
  `Hsize` varchar(5) NOT NULL,
  `Hprice` int(10) NOT NULL,
  `Hprovince` varchar(15) NOT NULL,
  `Hdistrict` varchar(15) NOT NULL,
  `Hsector` varchar(15) NOT NULL,
  `Hcell` varchar(15) NOT NULL,
  `Hvillage` varchar(15) NOT NULL,
  `Hstreetnumber` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `house`
--

INSERT INTO `house` (`Hid`, `Htype`, `Hsize`, `Hprice`, `Hprovince`, `Hdistrict`, `Hsector`, `Hcell`, `Hvillage`, `Hstreetnumber`) VALUES
(1, 'shatto', 'long', 40, 'eastern', 'rutsiro', 'nyabitekeri', 'mariba', 'bugomba', 252),
(2, 'ghetto', '3-5', 300000, 'western', 'rubavu', 'gisenyi', 'kinyamakara', 'gasharu', 444);

--
-- Triggers `house`
--
DELIMITER $$
CREATE TRIGGER `updatealert2` AFTER UPDATE ON `house` FOR EACH ROW UPDATE application SET application.Numberofhouse=Numberofhouse +1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `houseinfo`
-- (See below for the actual view)
--
CREATE TABLE `houseinfo` (
`Hid` int(5)
,`Htype` varchar(10)
,`Hsize` varchar(5)
,`Hprice` int(10)
,`Hprovince` varchar(15)
,`Hdistrict` varchar(15)
,`Hsector` varchar(15)
,`Hcell` varchar(15)
,`Hvillage` varchar(15)
,`Hstreetnumber` int(5)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payid` int(5) NOT NULL,
  `Paydate` date NOT NULL,
  `Appid` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payid`, `Paydate`, `Appid`) VALUES
(1, '0000-00-00', NULL),
(2, '2022-07-19', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `paymentinfo`
-- (See below for the actual view)
--
CREATE TABLE `paymentinfo` (
`Payid` int(5)
,`Paydate` date
,`Appid` int(5)
);

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `Sid` int(5) NOT NULL,
  `Sfname` varchar(15) NOT NULL,
  `Slname` varchar(15) NOT NULL,
  `Sgender` varchar(2) NOT NULL,
  `Sprovince` varchar(15) NOT NULL,
  `Sdistrict` varchar(15) NOT NULL,
  `Ssector` varchar(15) NOT NULL,
  `Scell` varchar(15) NOT NULL,
  `Svillage` varchar(15) NOT NULL,
  `Sstreetnumber` int(5) NOT NULL,
  `Sphonenumber` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`Sid`, `Sfname`, `Slname`, `Sgender`, `Sprovince`, `Sdistrict`, `Ssector`, `Scell`, `Svillage`, `Sstreetnumber`, `Sphonenumber`) VALUES
(1, 'nicolas', 'shema', 'M', 'western', 'rubavu', 'gisenyi', 'nyamyumba', 'gasharu', 251, 788751325);

--
-- Triggers `seller`
--
DELIMITER $$
CREATE TRIGGER `InsertAlert2` AFTER INSERT ON `seller` FOR EACH ROW INSERT INTO approval VALUES (7,7/20/2022,3)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `deletealert` AFTER DELETE ON `seller` FOR EACH ROW DELETE FROM approval WHERE approval.Sid= seller.Sid
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `sellerinfo`
-- (See below for the actual view)
--
CREATE TABLE `sellerinfo` (
`Sid` int(5)
,`Sfname` varchar(15)
,`Slname` varchar(15)
,`Sgender` varchar(2)
,`Sprovince` varchar(15)
,`Sdistrict` varchar(15)
,`Ssector` varchar(15)
,`Scell` varchar(15)
,`Svillage` varchar(15)
,`Sstreetnumber` int(5)
,`Sphonenumber` int(15)
);

-- --------------------------------------------------------

--
-- Structure for view `applicationinfo`
--
DROP TABLE IF EXISTS `applicationinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `applicationinfo`  AS SELECT `application`.`Appid` AS `Appid`, `application`.`Appdate` AS `Appdate`, `application`.`Numberofhouse` AS `Numberofhouse`, `application`.`Bid` AS `Bid`, `application`.`Hid` AS `Hid` FROM `application``application`  ;

-- --------------------------------------------------------

--
-- Structure for view `applicationinfo1`
--
DROP TABLE IF EXISTS `applicationinfo1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `applicationinfo1`  AS SELECT `application`.`Appid` AS `Appid`, `application`.`Appdate` AS `Appdate`, `application`.`Numberofhouse` AS `Numberofhouse`, `application`.`Bid` AS `Bid`, `application`.`Hid` AS `Hid` FROM `application` WHERE `application`.`Numberofhouse` > (select avg(`application`.`Numberofhouse`))  ;

-- --------------------------------------------------------

--
-- Structure for view `approvalinfo`
--
DROP TABLE IF EXISTS `approvalinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `approvalinfo`  AS SELECT `approval`.`Apprid` AS `Apprid`, `approval`.`Apprdate` AS `Apprdate`, `approval`.`Payid` AS `Payid`, `approval`.`Sid` AS `Sid` FROM `approval``approval`  ;

-- --------------------------------------------------------

--
-- Structure for view `buyerinfo`
--
DROP TABLE IF EXISTS `buyerinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `buyerinfo`  AS SELECT `buyer`.`Bid` AS `Bid`, `buyer`.`Bfname` AS `Bfname`, `buyer`.`Blname` AS `Blname`, `buyer`.`Bgender` AS `Bgender`, `buyer`.`Bprovince` AS `Bprovince`, `buyer`.`Bdistrict` AS `Bdistrict`, `buyer`.`Bsector` AS `Bsector`, `buyer`.`Bcell` AS `Bcell`, `buyer`.`Bvillage` AS `Bvillage`, `buyer`.`Bstreetnumber` AS `Bstreetnumber`, `buyer`.`Bphonenumber` AS `Bphonenumber` FROM `buyer``buyer`  ;

-- --------------------------------------------------------

--
-- Structure for view `houseinfo`
--
DROP TABLE IF EXISTS `houseinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `houseinfo`  AS SELECT `house`.`Hid` AS `Hid`, `house`.`Htype` AS `Htype`, `house`.`Hsize` AS `Hsize`, `house`.`Hprice` AS `Hprice`, `house`.`Hprovince` AS `Hprovince`, `house`.`Hdistrict` AS `Hdistrict`, `house`.`Hsector` AS `Hsector`, `house`.`Hcell` AS `Hcell`, `house`.`Hvillage` AS `Hvillage`, `house`.`Hstreetnumber` AS `Hstreetnumber` FROM `house``house`  ;

-- --------------------------------------------------------

--
-- Structure for view `paymentinfo`
--
DROP TABLE IF EXISTS `paymentinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `paymentinfo`  AS SELECT `payment`.`Payid` AS `Payid`, `payment`.`Paydate` AS `Paydate`, `payment`.`Appid` AS `Appid` FROM `payment``payment`  ;

-- --------------------------------------------------------

--
-- Structure for view `sellerinfo`
--
DROP TABLE IF EXISTS `sellerinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sellerinfo`  AS SELECT `seller`.`Sid` AS `Sid`, `seller`.`Sfname` AS `Sfname`, `seller`.`Slname` AS `Slname`, `seller`.`Sgender` AS `Sgender`, `seller`.`Sprovince` AS `Sprovince`, `seller`.`Sdistrict` AS `Sdistrict`, `seller`.`Ssector` AS `Ssector`, `seller`.`Scell` AS `Scell`, `seller`.`Svillage` AS `Svillage`, `seller`.`Sstreetnumber` AS `Sstreetnumber`, `seller`.`Sphonenumber` AS `Sphonenumber` FROM `seller``seller`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`Appid`),
  ADD KEY `House_Application` (`Hid`),
  ADD KEY `Buyer_Application` (`Bid`);

--
-- Indexes for table `approval`
--
ALTER TABLE `approval`
  ADD PRIMARY KEY (`Apprid`),
  ADD KEY `Payment_Approval` (`Payid`),
  ADD KEY `Seller_Approval` (`Sid`);

--
-- Indexes for table `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`Bid`);

--
-- Indexes for table `house`
--
ALTER TABLE `house`
  ADD PRIMARY KEY (`Hid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payid`),
  ADD KEY `Application_Payment` (`Appid`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`Sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `Sid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `Buyer_Application` FOREIGN KEY (`Bid`) REFERENCES `buyer` (`Bid`),
  ADD CONSTRAINT `House_Application` FOREIGN KEY (`Hid`) REFERENCES `house` (`Hid`);

--
-- Constraints for table `approval`
--
ALTER TABLE `approval`
  ADD CONSTRAINT `Payment_Approval` FOREIGN KEY (`Payid`) REFERENCES `payment` (`Payid`),
  ADD CONSTRAINT `Seller_Approval` FOREIGN KEY (`Sid`) REFERENCES `seller` (`Sid`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `Application_Payment` FOREIGN KEY (`Appid`) REFERENCES `application` (`Appid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
