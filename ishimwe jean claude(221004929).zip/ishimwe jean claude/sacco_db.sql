-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 09:16 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sacco_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `cust_pro` ()  BEGIN

   CREATE TABLE cust_procedure(cust_id INT, firstname VARCHAR(10),address varchar(50),contact varchar(50),username varchar(60),password varchar(70));

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_Acc` (IN `acc_id` INT(10), IN `cust_id` INT(10), IN `acc_name` VARCHAR(20))  begin
   insert into accounts values('10','07','umurenge sacco');
   end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_emp` (IN `emp_id` INT(40), IN `firstname` VARCHAR(30), IN `lastname` VARCHAR(20), IN `address` VARCHAR(49), IN `username` VARCHAR(50), IN `password` VARCHAR(50))  begin 
   insert into employees values('07','kalisa','koko','save','kali','passoke');
   END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_logG` (IN `log_id` INT(10), IN `trans_id` INT(10), IN `login_date` DATE, IN `login_time` DATE)  begin
   insert into login values('15','07','2/5/2022','7:9:7');
   end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_REPOR` (IN `rep_id` INT(10), IN `acc_id` INT(10), IN `login_id` INT(60), IN `trans_id` INT(60), IN `rep_name` VARCHAR(20), `rep_date` DATE)  begin
   insert into reports values('094','1','06','09','ishimwe jean claude','7/8/2022');
   end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_trans` (IN `trans_id` INT(10), IN `emp_id` INT(10), IN `cust_id` INT(60), IN `name` VARCHAR(20))  begin
   insert into login values('120','1','05','ishimwe jean claude');
   end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `acc_id` int(30) NOT NULL,
  `cust_id` int(100) NOT NULL,
  `acc_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`acc_id`, `cust_id`, `acc_name`) VALUES
(1, 12, 'UMUTUZO_SACCO'),
(2, 17, 'umurenge_SACCO');

--
-- Triggers `accounts`
--
DELIMITER $$
CREATE TRIGGER `accounts_trigger` AFTER INSERT ON `accounts` FOR EACH ROW BEGIN

INSERT INTO  accounts VALUES('08','28','intwari');

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `cust`
-- (See below for the actual view)
--
CREATE TABLE `cust` (
`cust_id` int(100)
,`firstname` varchar(100)
,`address` varchar(100)
,`contact` varchar(100)
,`username` varchar(50)
,`password` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `firstname`, `address`, `contact`, `username`, `password`) VALUES
(12, 'jean kaka', 'GISAGARA', '07876544', 'jeanclaude', 'jeanclaude1'),
(17, 'musonera', 'huye', '0786565654', 'jeanclaude26', 'jeanclaude15.');

-- --------------------------------------------------------

--
-- Stand-in structure for view `emp`
-- (See below for the actual view)
--
CREATE TABLE `emp` (
`emp_id` int(40)
,`firstname` varchar(100)
,`lastname` varchar(100)
,`address` varchar(100)
,`username` varchar(50)
,`password` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(40) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `firstname`, `lastname`, `address`, `username`, `password`) VALUES
(2, 'ishimwe', 'jean', 'nyamagae', 'jeanclaude26', 'jean5'),
(11, 'gapira', 'emmanueline', 'huye', 'jeanclaude99', 'jeanclaude1577777');

-- --------------------------------------------------------

--
-- Stand-in structure for view `log`
-- (See below for the actual view)
--
CREATE TABLE `log` (
`login_id` int(50)
,`trans_id` int(100)
,`login_date` date
,`login_time` time
);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(50) NOT NULL,
  `trans_id` int(100) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `trans_id`, `login_date`, `login_time`) VALUES
(1, 912, '2021-05-29', '05:16:10');

-- --------------------------------------------------------

--
-- Stand-in structure for view `money_avgprice`
-- (See below for the actual view)
--
CREATE TABLE `money_avgprice` (
`trans_id` int(100)
,`emp_id` int(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `proce`
-- (See below for the actual view)
--
CREATE TABLE `proce` (
`acc_id` int(30)
,`cust_id` int(100)
,`acc_name` varchar(60)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `rep`
-- (See below for the actual view)
--
CREATE TABLE `rep` (
`rep_id` int(100)
,`acc_id` int(100)
,`login_id` int(60)
,`trans_id` int(70)
,`rep_name` varchar(50)
,`rep_date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `rep_id` int(100) NOT NULL,
  `acc_id` int(100) NOT NULL,
  `login_id` int(60) NOT NULL,
  `trans_id` int(70) NOT NULL,
  `rep_name` varchar(50) NOT NULL,
  `rep_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`rep_id`, `acc_id`, `login_id`, `trans_id`, `rep_name`, `rep_date`) VALUES
(988888777, 1, 1, 912, 'saving', '2022-07-20');

-- --------------------------------------------------------

--
-- Stand-in structure for view `see`
-- (See below for the actual view)
--
CREATE TABLE `see` (
`acc_id` int(30)
,`cust_id` int(100)
,`acc_name` varchar(60)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `trans`
-- (See below for the actual view)
--
CREATE TABLE `trans` (
`trans_id` int(100)
,`emp_id` int(100)
,`cust_id` int(60)
,`name` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `trans_id` int(100) NOT NULL,
  `emp_id` int(100) NOT NULL,
  `cust_id` int(60) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`trans_id`, `emp_id`, `cust_id`, `name`) VALUES
(912, 11, 12, 'money deposit_ saving on sacco account...0012');

-- --------------------------------------------------------

--
-- Structure for view `cust`
--
DROP TABLE IF EXISTS `cust`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cust`  AS  select `customer`.`cust_id` AS `cust_id`,`customer`.`firstname` AS `firstname`,`customer`.`address` AS `address`,`customer`.`contact` AS `contact`,`customer`.`username` AS `username`,`customer`.`password` AS `password` from `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `emp`
--
DROP TABLE IF EXISTS `emp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `emp`  AS  select `employees`.`emp_id` AS `emp_id`,`employees`.`firstname` AS `firstname`,`employees`.`lastname` AS `lastname`,`employees`.`address` AS `address`,`employees`.`username` AS `username`,`employees`.`password` AS `password` from `employees` ;

-- --------------------------------------------------------

--
-- Structure for view `log`
--
DROP TABLE IF EXISTS `log`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `log`  AS  select `login`.`login_id` AS `login_id`,`login`.`trans_id` AS `trans_id`,`login`.`login_date` AS `login_date`,`login`.`login_time` AS `login_time` from `login` ;

-- --------------------------------------------------------

--
-- Structure for view `money_avgprice`
--
DROP TABLE IF EXISTS `money_avgprice`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `money_avgprice`  AS  select `transactions`.`trans_id` AS `trans_id`,`transactions`.`emp_id` AS `emp_id` from `transactions` where (`transactions`.`cust_id` > (select `transactions`.`trans_id` from `transactions`)) ;

-- --------------------------------------------------------

--
-- Structure for view `proce`
--
DROP TABLE IF EXISTS `proce`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `proce`  AS  select `accounts`.`acc_id` AS `acc_id`,`accounts`.`cust_id` AS `cust_id`,`accounts`.`acc_name` AS `acc_name` from `accounts` where (`accounts`.`cust_id` > (select `accounts`.`acc_id` from `accounts`)) ;

-- --------------------------------------------------------

--
-- Structure for view `rep`
--
DROP TABLE IF EXISTS `rep`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rep`  AS  select `reports`.`rep_id` AS `rep_id`,`reports`.`acc_id` AS `acc_id`,`reports`.`login_id` AS `login_id`,`reports`.`trans_id` AS `trans_id`,`reports`.`rep_name` AS `rep_name`,`reports`.`rep_date` AS `rep_date` from `reports` ;

-- --------------------------------------------------------

--
-- Structure for view `see`
--
DROP TABLE IF EXISTS `see`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `see`  AS  select `accounts`.`acc_id` AS `acc_id`,`accounts`.`cust_id` AS `cust_id`,`accounts`.`acc_name` AS `acc_name` from `accounts` ;

-- --------------------------------------------------------

--
-- Structure for view `trans`
--
DROP TABLE IF EXISTS `trans`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trans`  AS  select `transactions`.`trans_id` AS `trans_id`,`transactions`.`emp_id` AS `emp_id`,`transactions`.`cust_id` AS `cust_id`,`transactions`.`name` AS `name` from `transactions` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`acc_id`),
  ADD UNIQUE KEY `cust_id` (`cust_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`),
  ADD UNIQUE KEY `trans_id` (`trans_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`rep_id`),
  ADD UNIQUE KEY `acc_id` (`acc_id`),
  ADD KEY `login_id` (`login_id`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`trans_id`),
  ADD UNIQUE KEY `emp_id` (`emp_id`),
  ADD UNIQUE KEY `cust_id` (`cust_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`cust_id`);

--
-- Constraints for table `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`trans_id`) REFERENCES `transactions` (`trans_id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`acc_id`) REFERENCES `accounts` (`acc_id`),
  ADD CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`login_id`) REFERENCES `login` (`login_id`),
  ADD CONSTRAINT `reports_ibfk_3` FOREIGN KEY (`trans_id`) REFERENCES `transactions` (`trans_id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`),
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`cust_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
