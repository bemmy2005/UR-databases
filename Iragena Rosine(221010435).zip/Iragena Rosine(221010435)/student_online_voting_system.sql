-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2022 at 10:40 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_online_voting_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `candidatep` (IN `Allowedid` INT(10))   BEGIN
    update candidate set Allowedid=allowedid+2;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `candidates` (IN `candid` INT(10))   BEGIN
    delete from candidates where faculty=BBIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `candidatesp` (IN `CaIDParam` VARCHAR(30), `firstnameParam` VARCHAR(50), `lastnameParam` VARCHAR(70), `genderparam` VARCHAR(12))   BEGIN
    insert into candidatesp values (1122, mugisha, joseph, m);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `electionp` (IN `election_date` DATE)   BEGIN
    update election set election_date=election_date+ time;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leadersp` (IN `position1` VARCHAR(40))   BEGIN
    delete from leaders where position1=president;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `positionp` (IN `PIDParam` VARCHAR(30))   BEGIN
    update positionp set PIDParam=PIDParam where PIDParam<527;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `registeredp` (IN `RIDParam` VARCHAR(30), `fnameParam` VARCHAR(50), `lname` VARCHAR(30), `faculty` VARCHAR(12))   BEGIN
    insert into registeredp values (527, mucyo, ange, midwifely);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `voterp` (IN `VIDParam` VARCHAR(30), `fnameParam` VARCHAR(50), `lnameParam` VARCHAR(70), `classParam` INT(12))   BEGIN
    insert into voterp values (528, Mike, kayihura, 2);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Adname` varchar(11) DEFAULT NULL,
  `Adpass` varchar(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Adname`, `Adpass`) VALUES
('1234', 'rol');

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `Allowedid` int(10) NOT NULL,
  `F_name` varchar(20) DEFAULT NULL,
  `L_name` varchar(20) DEFAULT NULL,
  `faculty` varchar(20) DEFAULT NULL,
  `Class` int(3) DEFAULT NULL,
  `Position` varchar(40) DEFAULT NULL,
  `Achievement` varchar(60) DEFAULT NULL,
  `Pic` varchar(10000) DEFAULT NULL,
  `Votersid` int(11) DEFAULT NULL,
  `Candid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`Allowedid`, `F_name`, `L_name`, `faculty`, `Class`, `Position`, `Achievement`, `Pic`, `Votersid`, `Candid`) VALUES
(2345, 'Iradukunda', 'Jmv', 'BBIT', 2, 'President', 'ALL', 'ASD', 256, 3456),
(2346, 'bngfmkd,', 'hfgjdkj', 'jakjfvaj', 4, 'sec', 'dfsghajksh', 'together we can', 256, 3456);

--
-- Triggers `candidate`
--
DELIMITER $$
CREATE TRIGGER `insertcandidates` AFTER INSERT ON `candidate` FOR EACH ROW BEGIN  
update Class set numberCars=numberCars+1; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `candid` int(10) NOT NULL,
  `Firstname` varchar(20) DEFAULT NULL,
  `Lastname` varchar(20) DEFAULT NULL,
  `faculty` varchar(25) DEFAULT NULL,
  `Class` int(10) DEFAULT NULL,
  `Positions` varchar(40) DEFAULT NULL,
  `Achievement` varchar(100) DEFAULT NULL,
  `Pictures` varchar(10000) DEFAULT NULL,
  `Gender` varchar(1) DEFAULT NULL,
  `Votersid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`candid`, `Firstname`, `Lastname`, `faculty`, `Class`, `Positions`, `Achievement`, `Pictures`, `Gender`, `Votersid`) VALUES
(3456, 'Lili', 'dudu', 'BBIT', 5, 'secretary', 'TOGETHER WE CANFGHJKLK', 'DFGHJKLKJHBVCVBNM,', 'F', 256),
(3458, 'UWAJE', 'ange', 'BBIT', 6, 'head girl', 'as women we can achieve more and reach far from here. we the best', 'm ', 'F', 257);

--
-- Triggers `candidates`
--
DELIMITER $$
CREATE TRIGGER `candidatesT` AFTER UPDATE ON `candidates` FOR EACH ROW BEGIN  
update Faculty set faculty=BIT+b; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `candidatesview`
-- (See below for the actual view)
--
CREATE TABLE `candidatesview` (
`candid` int(10)
,`Firstname` varchar(20)
,`Lastname` varchar(20)
,`faculty` varchar(25)
,`Class` int(10)
,`Positions` varchar(40)
,`Achievement` varchar(100)
,`Pictures` varchar(10000)
,`Gender` varchar(1)
,`Votersid` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `candidateview`
-- (See below for the actual view)
--
CREATE TABLE `candidateview` (
`Allowedid` int(10)
,`F_name` varchar(20)
,`L_name` varchar(20)
,`faculty` varchar(20)
,`Class` int(3)
,`Position` varchar(40)
,`Achievement` varchar(60)
,`Pic` varchar(10000)
,`Votersid` int(11)
,`Candid` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE `election` (
  `Electionid` int(5) NOT NULL,
  `Election_date` date DEFAULT NULL,
  `Election_type` varchar(15) DEFAULT NULL,
  `ResultDate` date DEFAULT NULL,
  `Details` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `election`
--

INSERT INTO `election` (`Electionid`, `Election_date`, `Election_type`, `ResultDate`, `Details`) VALUES
(2345, '2022-07-14', 'president', '2022-07-26', 'election for president position.'),
(2346, '2022-07-21', 'sec', '2022-07-22', 'elected on head boy'),
(2347, '2022-07-20', 'social', '2022-07-22', 'vote for social');

--
-- Triggers `election`
--
DELIMITER $$
CREATE TRIGGER `electiont` AFTER DELETE ON `election` FOR EACH ROW BEGIN  
update Electionid set Electionid= Electionid+E; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `electionview`
-- (See below for the actual view)
--
CREATE TABLE `electionview` (
`Electionid` int(5)
,`Election_date` date
,`Election_type` varchar(15)
,`ResultDate` date
,`Details` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `leaders`
--

CREATE TABLE `leaders` (
  `candsid` int(20) NOT NULL,
  `Cand_name` varchar(64) DEFAULT NULL,
  `Position1` varchar(40) DEFAULT NULL,
  `Position2` varchar(25) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Votersid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leaders`
--

INSERT INTO `leaders` (`candsid`, `Cand_name`, `Position1`, `Position2`, `Date`, `Votersid`) VALUES
(1470, 'Ineza', 'president', 'SEC', '2022-07-20', 256),
(1471, 'muganga', 'HEADBOY', 'Manager', '2022-07-18', 256);

--
-- Triggers `leaders`
--
DELIMITER $$
CREATE TRIGGER `leaderst` AFTER DELETE ON `leaders` FOR EACH ROW BEGIN  
update date set date= date+time; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `leadersview`
-- (See below for the actual view)
--
CREATE TABLE `leadersview` (
`candsid` int(20)
,`Cand_name` varchar(64)
,`Position1` varchar(40)
,`Position2` varchar(25)
,`Date` date
,`Votersid` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `Newsid` int(33) DEFAULT NULL,
  `Newss` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`Newsid`, `Newss`) VALUES
(2345, 'rolenzo voted for vice-president position');

-- --------------------------------------------------------

--
-- Table structure for table `position1`
--

CREATE TABLE `position1` (
  `Voters` int(20) NOT NULL,
  `F_name` varchar(19) DEFAULT NULL,
  `L_name` varchar(19) DEFAULT NULL,
  `Position1` varchar(16) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Allowedid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `position1`
--

INSERT INTO `position1` (`Voters`, `F_name`, `L_name`, `Position1`, `Date`, `Allowedid`) VALUES
(258, 'MBABAZI', 'Asia', 'secretary', '2022-07-22', 2345);

--
-- Triggers `position1`
--
DELIMITER $$
CREATE TRIGGER `insertposition1` AFTER INSERT ON `position1` FOR EACH ROW BEGIN  
update position1 set position1=president+m; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `position2`
--

CREATE TABLE `position2` (
  `Voters` int(20) NOT NULL,
  `F_name` varchar(18) DEFAULT NULL,
  `L_name` varchar(18) DEFAULT NULL,
  `Position2` varchar(16) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Allowedid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `position2`
--

INSERT INTO `position2` (`Voters`, `F_name`, `L_name`, `Position2`, `Date`, `Allowedid`) VALUES
(369, 'uwera', 'Aime', 'SEC', '2022-07-22', 2345);

-- --------------------------------------------------------

--
-- Table structure for table `registered`
--

CREATE TABLE `registered` (
  `Votersid` int(11) NOT NULL,
  `firstname` varchar(14) DEFAULT NULL,
  `lastname` varchar(18) DEFAULT NULL,
  `faculty` varchar(18) DEFAULT NULL,
  `class` int(3) DEFAULT NULL,
  `gender` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registered`
--

INSERT INTO `registered` (`Votersid`, `firstname`, `lastname`, `faculty`, `class`, `gender`) VALUES
(256, 'LILI', 'DUDU', 'BBIT', 2, 'F'),
(257, 'LILI', 'DUDU', 'BBIT', 2, 'F');

--
-- Triggers `registered`
--
DELIMITER $$
CREATE TRIGGER `registered` AFTER UPDATE ON `registered` FOR EACH ROW BEGIN  
update Faculty set faculty=BBIT+b; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `registeredview`
-- (See below for the actual view)
--
CREATE TABLE `registeredview` (
`Votersid` int(11)
,`firstname` varchar(14)
,`lastname` varchar(18)
,`faculty` varchar(18)
,`class` int(3)
,`gender` varchar(2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `subqueries`
-- (See below for the actual view)
--
CREATE TABLE `subqueries` (
`Electionid` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `systemtable`
-- (See below for the actual view)
--
CREATE TABLE `systemtable` (
`Adname` varchar(11)
,`Adpass` varchar(18)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `systemtable1`
-- (See below for the actual view)
--
CREATE TABLE `systemtable1` (
`Electionid` int(5)
,`Election_date` date
,`Election_type` varchar(15)
,`ResultDate` date
,`Details` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `systemtable2`
-- (See below for the actual view)
--
CREATE TABLE `systemtable2` (
`Votersid` int(11)
,`firstname` varchar(14)
,`lastname` varchar(18)
,`faculty` varchar(18)
,`class` int(3)
,`gender` varchar(2)
);

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `Voteid` int(10) NOT NULL,
  `Electionid` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`Voteid`, `Electionid`) VALUES
(6542, 2345);

-- --------------------------------------------------------

--
-- Structure for view `candidatesview`
--
DROP TABLE IF EXISTS `candidatesview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `candidatesview`  AS SELECT `candidates`.`candid` AS `candid`, `candidates`.`Firstname` AS `Firstname`, `candidates`.`Lastname` AS `Lastname`, `candidates`.`faculty` AS `faculty`, `candidates`.`Class` AS `Class`, `candidates`.`Positions` AS `Positions`, `candidates`.`Achievement` AS `Achievement`, `candidates`.`Pictures` AS `Pictures`, `candidates`.`Gender` AS `Gender`, `candidates`.`Votersid` AS `Votersid` FROM `candidates``candidates`  ;

-- --------------------------------------------------------

--
-- Structure for view `candidateview`
--
DROP TABLE IF EXISTS `candidateview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `candidateview`  AS SELECT `candidate`.`Allowedid` AS `Allowedid`, `candidate`.`F_name` AS `F_name`, `candidate`.`L_name` AS `L_name`, `candidate`.`faculty` AS `faculty`, `candidate`.`Class` AS `Class`, `candidate`.`Position` AS `Position`, `candidate`.`Achievement` AS `Achievement`, `candidate`.`Pic` AS `Pic`, `candidate`.`Votersid` AS `Votersid`, `candidate`.`Candid` AS `Candid` FROM `candidate``candidate`  ;

-- --------------------------------------------------------

--
-- Structure for view `electionview`
--
DROP TABLE IF EXISTS `electionview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `electionview`  AS SELECT `election`.`Electionid` AS `Electionid`, `election`.`Election_date` AS `Election_date`, `election`.`Election_type` AS `Election_type`, `election`.`ResultDate` AS `ResultDate`, `election`.`Details` AS `Details` FROM `election``election`  ;

-- --------------------------------------------------------

--
-- Structure for view `leadersview`
--
DROP TABLE IF EXISTS `leadersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `leadersview`  AS SELECT `leaders`.`candsid` AS `candsid`, `leaders`.`Cand_name` AS `Cand_name`, `leaders`.`Position1` AS `Position1`, `leaders`.`Position2` AS `Position2`, `leaders`.`Date` AS `Date`, `leaders`.`Votersid` AS `Votersid` FROM `leaders``leaders`  ;

-- --------------------------------------------------------

--
-- Structure for view `registeredview`
--
DROP TABLE IF EXISTS `registeredview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `registeredview`  AS SELECT `registered`.`Votersid` AS `Votersid`, `registered`.`firstname` AS `firstname`, `registered`.`lastname` AS `lastname`, `registered`.`faculty` AS `faculty`, `registered`.`class` AS `class`, `registered`.`gender` AS `gender` FROM `registered``registered`  ;

-- --------------------------------------------------------

--
-- Structure for view `subqueries`
--
DROP TABLE IF EXISTS `subqueries`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subqueries`  AS SELECT `election`.`Allowedid` AS `Electionid` FROM `candidate` AS `election` WHERE `election`.`Allowedid` = '1568''1568'  ;

-- --------------------------------------------------------

--
-- Structure for view `systemtable`
--
DROP TABLE IF EXISTS `systemtable`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `systemtable`  AS SELECT `candidates`.`Adname` AS `Adname`, `candidates`.`Adpass` AS `Adpass` FROM `admin` AS `candidates``candidates`  ;

-- --------------------------------------------------------

--
-- Structure for view `systemtable1`
--
DROP TABLE IF EXISTS `systemtable1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `systemtable1`  AS SELECT `candidate`.`Electionid` AS `Electionid`, `candidate`.`Election_date` AS `Election_date`, `candidate`.`Election_type` AS `Election_type`, `candidate`.`ResultDate` AS `ResultDate`, `candidate`.`Details` AS `Details` FROM `election` AS `candidate``candidate`  ;

-- --------------------------------------------------------

--
-- Structure for view `systemtable2`
--
DROP TABLE IF EXISTS `systemtable2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `systemtable2`  AS SELECT `leaders`.`Votersid` AS `Votersid`, `leaders`.`firstname` AS `firstname`, `leaders`.`lastname` AS `lastname`, `leaders`.`faculty` AS `faculty`, `leaders`.`class` AS `class`, `leaders`.`gender` AS `gender` FROM `registered` AS `leaders``leaders`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`Allowedid`),
  ADD KEY `registered` (`Votersid`),
  ADD KEY `candidates` (`Candid`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`candid`),
  ADD KEY `candidate` (`Votersid`);

--
-- Indexes for table `election`
--
ALTER TABLE `election`
  ADD PRIMARY KEY (`Electionid`);

--
-- Indexes for table `leaders`
--
ALTER TABLE `leaders`
  ADD PRIMARY KEY (`candsid`),
  ADD KEY `leaders` (`Votersid`);

--
-- Indexes for table `position1`
--
ALTER TABLE `position1`
  ADD PRIMARY KEY (`Voters`),
  ADD KEY `position1` (`Allowedid`);

--
-- Indexes for table `position2`
--
ALTER TABLE `position2`
  ADD PRIMARY KEY (`Voters`),
  ADD KEY `position2` (`Allowedid`);

--
-- Indexes for table `registered`
--
ALTER TABLE `registered`
  ADD PRIMARY KEY (`Votersid`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`Voteid`),
  ADD KEY `vote` (`Electionid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `Allowedid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112234;

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `candid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3459;

--
-- AUTO_INCREMENT for table `election`
--
ALTER TABLE `election`
  MODIFY `Electionid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2348;

--
-- AUTO_INCREMENT for table `leaders`
--
ALTER TABLE `leaders`
  MODIFY `candsid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1472;

--
-- AUTO_INCREMENT for table `position1`
--
ALTER TABLE `position1`
  MODIFY `Voters` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;

--
-- AUTO_INCREMENT for table `position2`
--
ALTER TABLE `position2`
  MODIFY `Voters` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=370;

--
-- AUTO_INCREMENT for table `registered`
--
ALTER TABLE `registered`
  MODIFY `Votersid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=258;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `Voteid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6543;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `candidate`
--
ALTER TABLE `candidate`
  ADD CONSTRAINT `candidates` FOREIGN KEY (`Candid`) REFERENCES `candidates` (`candid`),
  ADD CONSTRAINT `registered` FOREIGN KEY (`Votersid`) REFERENCES `registered` (`Votersid`);

--
-- Constraints for table `candidates`
--
ALTER TABLE `candidates`
  ADD CONSTRAINT `candidate` FOREIGN KEY (`Votersid`) REFERENCES `registered` (`Votersid`);

--
-- Constraints for table `leaders`
--
ALTER TABLE `leaders`
  ADD CONSTRAINT `leaders` FOREIGN KEY (`Votersid`) REFERENCES `registered` (`Votersid`);

--
-- Constraints for table `position1`
--
ALTER TABLE `position1`
  ADD CONSTRAINT `position1` FOREIGN KEY (`Allowedid`) REFERENCES `candidate` (`Allowedid`);

--
-- Constraints for table `position2`
--
ALTER TABLE `position2`
  ADD CONSTRAINT `position2` FOREIGN KEY (`Allowedid`) REFERENCES `candidate` (`Allowedid`);

--
-- Constraints for table `vote`
--
ALTER TABLE `vote`
  ADD CONSTRAINT `Election` FOREIGN KEY (`Electionid`) REFERENCES `election` (`Electionid`),
  ADD CONSTRAINT `vote` FOREIGN KEY (`Electionid`) REFERENCES `election` (`Electionid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
