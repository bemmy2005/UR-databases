-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2022 at 07:48 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteinborrow` (IN `Borrowss_ID` INT(4))  BEGIN 
DELETE FROM borrow where Borrow_ID=Borrowss_ID; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteinlostbooks` (IN `Lostss_ID` INT(4))  BEGIN
DELETE FROM lost_books WHERE Lost_ID=Lostss_ID; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getbooksinfo` ()  BEGIN
SELECT* FROM books;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getborrowinfo` ()  BEGIN
SELECT * FROM borrow;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getissuedbooksinfo` ()  BEGIN
SELECT* FROM issued_books;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getlearnersinfo` ()  BEGIN
SELECT*FROM learners;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getlibrariansinfo` ()  BEGIN
SELECT*FROM librarians;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getlostbooksinfo` ()  BEGIN
SELECT*FROM lost_books;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getreturnedbooksinf` ()  BEGIN
SELECT*FROM returned_books;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getusersinfo` ()  BEGIN
select*FROM users;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintobook` (IN `Book_ID` VARCHAR(10), `Book_title` VARCHAR(100), `Book_author` VARCHAR(40), `Book_shalfnumber` INT(4))  BEGIN
insert into books values(Book_ID, Book_title,Book_author,Book_shalfnumber);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintoborrow` (`Borrow_ID` INT(4), `Learner_ID` INT(10), `Book_ID` VARCHAR(10), `Comments` VARCHAR(100))  BEGIN
insert into borrow VALUES(Borrow_ID,Learner_ID,Book_ID,Comments);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintoissuedbooks` (`Issue_ID` INT(4), `Learner_ID` INT(10), `Book_ID` VARCHAR(10), `Librarian_ID` INT(10), `Issued_date` DATE, `Return_date` DATE)  BEGIN
insert into issued_books VALUES(Issue_ID,Learner_ID,Book_ID,Librarian_ID,Issued_date,Return_date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintolearners` (`Learner_ID` INT(10), `F_name` VARCHAR(20), `L_name` VARCHAR(20), `Gender` VARCHAR(6), `Email` VARCHAR(40), `College` VARCHAR(50), `Department` VARCHAR(40))  BEGIN
insert into learners VALUES(Learner_ID, F_name, L_name,Gender,Email,College,Department);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintolibrarians` (`Librarian_ID` INT(10), `F_name` VARCHAR(20), `L_name` VARCHAR(15), `Gender` VARCHAR(6), `Email` VARCHAR(40))  BEGIN
insert into librarians VALUES(Librarian_ID,F_name,L_name,Gender,Email);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintolostbooks` (`Lost_ID` INT(4), `Learner_ID` INT(10), `Book_ID` VARCHAR(10), `Lost_date` DATE)  BEGIN
insert into lost_books VALUES(Lost_ID,Learner_ID,Book_ID,Lost_date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintoreturnedbooks` (`Return_ID` INT(4), `Learner_ID` INT(10), `Book_ID` VARCHAR(10), `Librarian_ID` INT(10), `Returned_date` DATE)  BEGIN
insert into returned_books values(Return_ID,Learner_ID,Book_ID,Librarian_ID,Returned_date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintoreturned_books` (`Return_ID` INT(4), `Learner_ID` INT(10), `Book_ID` VARCHAR(10), `Librarian_ID` INT(10), `Returned_date` DATE)  BEGIN
insert into returned_books values(Return_ID,Learner_ID,Book_ID,Librarian_ID,Returned_date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintousers` (`User_ID` INT(4), `Learner_ID` INT(10), `Librarian_ID` INT(10), `Usernsme` VARCHAR(50), `Passphrase` VARCHAR(10))  BEGIN
insert into users VALUES(User_ID,Learner_ID,Librarian_ID,Usernsme,Passphrase);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `procedureview` (`Return_ID` INT(4), `Learner_ID` INT(10), `Book_ID` VARCHAR(10), `Librarian_ID` INT(10), `Returned_date` DATE)  BEGIN
SELECT* from returned_books where Learner_ID<(SELECT(Learner_ID) from learners);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatelibrarians` (IN `Librarianss_ID` INT(10))  BEGIN 
UPDATE librarians set L_name=null,F_name='HAKIM' where Librarian_ID=Librarianss_ID; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateusers` (IN `Userss_ID` INT(4))  BEGIN 
UPDATE users SET Usernsme='Rutambi' WHERE User_ID=Userss_ID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `Book_ID` varchar(10) NOT NULL,
  `Book_title` varchar(100) NOT NULL,
  `Book_author` varchar(40) NOT NULL,
  `Book_shalfnumber` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`Book_ID`, `Book_title`, `Book_author`, `Book_shalfnumber`) VALUES
('00HISTO20', 'History of Rwanda', 'Dr Emmanualla', 27),
('00NET001', 'Introduction to Business Management', 'Dr Joseline', 17),
('00NET01', 'Introduction to Networking', 'Jo\' Moline', 20),
('00NET34', 'Fundamental Mathematics', 'Dr Mallio', 120),
('00OCP034', 'Occupation and Learning Process', 'Dr Willy', 34),
('00PYT40', 'Concepts of Python Programming', 'Dr Augene Malitinez', 100),
('00STAT200', 'Fundamentals of Statistics', 'Dr Omar', 910),
('100ENG23', 'English Grammers', 'Dr Mustsff', 1000);

--
-- Triggers `books`
--
DELIMITER $$
CREATE TRIGGER `after_insert_books` AFTER INSERT ON `books` FOR EACH ROW BEGIN
DECLARE BookID int(5);
SELECT learners.Learner_ID INTO bookID FROM learners WHERE learners.Learner_ID=2;
INSERT INTO books(Book_ID,Book_title,Book_author,Book_shalfnumber) VALUES('00GEO20','Introductions to C Programming','Mr. Kebrown','14');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `Borrow_ID` int(4) NOT NULL,
  `Learner_ID` int(10) DEFAULT NULL,
  `Book_ID` varchar(10) DEFAULT NULL,
  `Comments` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`Borrow_ID`, `Learner_ID`, `Book_ID`, `Comments`) VALUES
(11, 2, '00NET34', 'The book you\\\'re borrowing is available.\\r\\nlocation: book shelf number 17.'),
(12, 2240, '00NET01', 'This book is available, you can borrow it'),
(13, 1020, '00PYT40', 'This books is lost.'),
(43, 2002, '00PYT40', 'This books is lost.');

--
-- Triggers `borrow`
--
DELIMITER $$
CREATE TRIGGER `after_insert_borrow` AFTER INSERT ON `borrow` FOR EACH ROW BEGIN
DECLARE librarian int(5);
SELECT librarians.Librarian_ID INTO librarian FROM librarians WHERE Librarian_ID=102;
if (NEW.Comments='This book is available, you can borrow it') THEN
INSERT INTO issued_books(Issue_ID,Learner_ID,Book_ID,Librarian_ID,Issued_date,Return_date) VALUES('',NEW.Learner_ID,NEW.Book_ID,librarian,NOW(),DATE_ADD(Issued_date,INTERVAL 7 DAY));
 END IF;                                                                                                 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_book`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_book` (
`Book_ID` varchar(10)
,`Book_title` varchar(100)
,`Book_author` varchar(40)
,`Book_shalfnumber` int(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_borrow`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_borrow` (
`Borrow_ID` int(4)
,`Learner_ID` int(10)
,`Book_ID` varchar(10)
,`Comments` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_issued_books`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_issued_books` (
`Issue_ID` int(4)
,`Learner_ID` int(10)
,`Book_ID` varchar(10)
,`Librarian_ID` int(10)
,`Issued_date` date
,`Return_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_learners`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_learners` (
`Learner_ID` int(10)
,`F_name` varchar(20)
,`L_name` varchar(20)
,`Gender` varchar(6)
,`Email` varchar(40)
,`College` varchar(50)
,`Department` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_librarians`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_librarians` (
`Librarian_ID` int(10)
,`F_name` varchar(20)
,`L_name` varchar(15)
,`Gender` varchar(6)
,`Email` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_lost_books`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_lost_books` (
`Lost_ID` int(4)
,`Learner_ID` int(10)
,`Book_ID` varchar(10)
,`Lost_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_returned_books`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_returned_books` (
`Return_ID` int(4)
,`Learner_ID` int(10)
,`Book_ID` varchar(10)
,`Librarian_ID` int(10)
,`Returned_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_users`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_users` (
`User_ID` int(4)
,`Learner_ID` int(10)
,`Librarian_ID` int(10)
,`Usernsme` varchar(50)
,`Passphrase` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `issued_books`
--

CREATE TABLE `issued_books` (
  `Issue_ID` int(4) NOT NULL,
  `Learner_ID` int(10) DEFAULT NULL,
  `Book_ID` varchar(10) DEFAULT NULL,
  `Librarian_ID` int(10) DEFAULT NULL,
  `Issued_date` date NOT NULL,
  `Return_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issued_books`
--

INSERT INTO `issued_books` (`Issue_ID`, `Learner_ID`, `Book_ID`, `Librarian_ID`, `Issued_date`, `Return_date`) VALUES
(2, 1020, '00PYT40', 102, '2022-07-16', '2022-07-28'),
(3, 2000, '00NET34', 23, '2022-07-07', '2022-07-13');

--
-- Triggers `issued_books`
--
DELIMITER $$
CREATE TRIGGER `after_delete_issued_books` AFTER DELETE ON `issued_books` FOR EACH ROW BEGIN
INSERT into lost_books(lost_books.Lost_ID,lost_books.Learner_ID,lost_books.Book_ID,lost_books.Lost_date)VALUES('',OLD.Learner_ID,OLD.Book_ID, DATE_SUB(NOW(),INTERVAL 3 DAY));
UPDATE borrow set Comments='This books is lost.' WHERE borrow.Book_ID=OLD.Book_ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `learners`
--

CREATE TABLE `learners` (
  `Learner_ID` int(10) NOT NULL,
  `F_name` varchar(20) NOT NULL,
  `L_name` varchar(20) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `College` varchar(50) NOT NULL,
  `Department` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `learners`
--

INSERT INTO `learners` (`Learner_ID`, `F_name`, `L_name`, `Gender`, `Email`, `College`, `Department`) VALUES
(2, 'AKIMANA', 'Joseline', 'Female', 'akinjose45@gmail.com', 'CBE', 'BIT'),
(1020, 'KAYANGE', 'Josiane', 'Female', 'becky_belly0@gmail.com', 'CST', 'IS'),
(2000, 'KAMALI', 'Yve', 'Male', 'kaman@gmail.com', 'CBE', 'BIT'),
(2002, 'KANKIRIHO', 'Jordan', 'Male', 'kanki123@gmail.com', 'CASS', 'Translation'),
(2210, 'Sylivia', 'KANYANA', 'Female', 'kanyana123@gmail.com', 'CAVM', 'Forestry'),
(2240, 'AMIZERO', 'Christian', 'Male', 'amich123@gmail.com', 'CBE', 'BIT');

--
-- Triggers `learners`
--
DELIMITER $$
CREATE TRIGGER `after_delete_learners` AFTER DELETE ON `learners` FOR EACH ROW BEGIN
DELETE from users where users.Learner_ID=OLD.Learner_ID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_learners` AFTER UPDATE ON `learners` FOR EACH ROW BEGIN
UPDATE users set users.Passphrase=CONCAT(NEW.F_name,'@',NEW.L_name )WHERE users.Learner_ID=NEW.Learner_ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `librarians`
--

CREATE TABLE `librarians` (
  `Librarian_ID` int(10) NOT NULL,
  `F_name` varchar(20) NOT NULL,
  `L_name` varchar(15) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarians`
--

INSERT INTO `librarians` (`Librarian_ID`, `F_name`, `L_name`, `Gender`, `Email`) VALUES
(1, 'KAMWE', 'Huston', 'Male', 'rwomushsna12@gmail.com'),
(23, 'KANYANA', 'Fulah', 'Female', 'kanyana@gmail.com'),
(24, 'MUTONI', 'Jolly', 'Female', 'mutoniwase@gmail.com'),
(102, 'KALIM', 'Huston', 'Male', 'hustons@gmail.com'),
(254, 'KAMANAYO', 'Vuningoma', 'Male', 'vuningoma@gmail.com'),
(432, 'IGIHOZO', 'Belyse', 'Female', 'igihozobe@gmail.com'),
(2100, 'MUKAMUKESHA', 'Providance', 'Female', 'provimukamukesha@gmail.com');

--
-- Triggers `librarians`
--
DELIMITER $$
CREATE TRIGGER `after_update_librarians` AFTER UPDATE ON `librarians` FOR EACH ROW BEGIN
UPDATE users set users.Passphrase=CONCAT(NEW.F_name,'@',NEW.L_name )WHERE users.Librarian_ID=NEW.Librarian_ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `lost_books`
--

CREATE TABLE `lost_books` (
  `Lost_ID` int(4) NOT NULL,
  `Learner_ID` int(10) DEFAULT NULL,
  `Book_ID` varchar(10) DEFAULT NULL,
  `Lost_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lost_books`
--

INSERT INTO `lost_books` (`Lost_ID`, `Learner_ID`, `Book_ID`, `Lost_date`) VALUES
(1, 1020, '00PYT40', '2022-07-19'),
(5, 2210, '00OCP034', '2010-07-28'),
(8, 2002, '00PYT40', '2022-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `returned_books`
--

CREATE TABLE `returned_books` (
  `Return_ID` int(4) NOT NULL,
  `Learner_ID` int(10) DEFAULT NULL,
  `Book_ID` varchar(10) DEFAULT NULL,
  `Librarian_ID` int(10) DEFAULT NULL,
  `Returned_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `returned_books`
--

INSERT INTO `returned_books` (`Return_ID`, `Learner_ID`, `Book_ID`, `Librarian_ID`, `Returned_date`) VALUES
(0, 2240, '00NET01', 432, '2015-07-15'),
(3, 2000, '00NET34', 23, '2022-07-12');

--
-- Triggers `returned_books`
--
DELIMITER $$
CREATE TRIGGER `after_insert_returned_books` AFTER INSERT ON `returned_books` FOR EACH ROW BEGIN
UPDATE borrow set borrow.Comments='This book is available, you can borrow it' WHERE borrow.Book_ID=NEW.Book_ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `to_concider_subquery`
-- (See below for the actual view)
--
CREATE TABLE `to_concider_subquery` (
`Learner_ID` int(10)
,`F_name` varchar(20)
,`L_name` varchar(20)
,`Gender` varchar(6)
,`Email` varchar(40)
,`College` varchar(50)
,`Department` varchar(40)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` int(4) NOT NULL,
  `Learner_ID` int(10) DEFAULT NULL,
  `Librarian_ID` int(10) DEFAULT NULL,
  `Usernsme` varchar(50) NOT NULL,
  `Passphrase` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `Learner_ID`, `Librarian_ID`, `Usernsme`, `Passphrase`) VALUES
(1, NULL, 2100, 'mukesha providance12', 'mukamukesh'),
(2, 2240, NULL, 'christian123', 'hernameis'),
(3, 1020, NULL, 'belyse53', 'KAYANGE@Jo'),
(5, 2210, NULL, 'Sylivia12', '12@#haj'),
(6, NULL, 102, 'kalim huston', 'huston1234'),
(7, NULL, 1, 'Rutambi', 'KAMWE@Hust'),
(8, NULL, 24, 'sesonga jeanbatiste', 'sesonga123'),
(10, 2, NULL, 'akimjose', 'akim123');

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_book`
--
DROP TABLE IF EXISTS `insert_data_into_book`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_book`  AS SELECT `books`.`Book_ID` AS `Book_ID`, `books`.`Book_title` AS `Book_title`, `books`.`Book_author` AS `Book_author`, `books`.`Book_shalfnumber` AS `Book_shalfnumber` FROM `books` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_borrow`
--
DROP TABLE IF EXISTS `insert_data_into_borrow`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_borrow`  AS SELECT `borrow`.`Borrow_ID` AS `Borrow_ID`, `borrow`.`Learner_ID` AS `Learner_ID`, `borrow`.`Book_ID` AS `Book_ID`, `borrow`.`Comments` AS `Comments` FROM `borrow` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_issued_books`
--
DROP TABLE IF EXISTS `insert_data_into_issued_books`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_issued_books`  AS SELECT `issued_books`.`Issue_ID` AS `Issue_ID`, `issued_books`.`Learner_ID` AS `Learner_ID`, `issued_books`.`Book_ID` AS `Book_ID`, `issued_books`.`Librarian_ID` AS `Librarian_ID`, `issued_books`.`Issued_date` AS `Issued_date`, `issued_books`.`Return_date` AS `Return_date` FROM `issued_books` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_learners`
--
DROP TABLE IF EXISTS `insert_data_into_learners`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_learners`  AS SELECT `learners`.`Learner_ID` AS `Learner_ID`, `learners`.`F_name` AS `F_name`, `learners`.`L_name` AS `L_name`, `learners`.`Gender` AS `Gender`, `learners`.`Email` AS `Email`, `learners`.`College` AS `College`, `learners`.`Department` AS `Department` FROM `learners` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_librarians`
--
DROP TABLE IF EXISTS `insert_data_into_librarians`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_librarians`  AS SELECT `librarians`.`Librarian_ID` AS `Librarian_ID`, `librarians`.`F_name` AS `F_name`, `librarians`.`L_name` AS `L_name`, `librarians`.`Gender` AS `Gender`, `librarians`.`Email` AS `Email` FROM `librarians` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_lost_books`
--
DROP TABLE IF EXISTS `insert_data_into_lost_books`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_lost_books`  AS SELECT `lost_books`.`Lost_ID` AS `Lost_ID`, `lost_books`.`Learner_ID` AS `Learner_ID`, `lost_books`.`Book_ID` AS `Book_ID`, `lost_books`.`Lost_date` AS `Lost_date` FROM `lost_books` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_returned_books`
--
DROP TABLE IF EXISTS `insert_data_into_returned_books`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_returned_books`  AS SELECT `returned_books`.`Return_ID` AS `Return_ID`, `returned_books`.`Learner_ID` AS `Learner_ID`, `returned_books`.`Book_ID` AS `Book_ID`, `returned_books`.`Librarian_ID` AS `Librarian_ID`, `returned_books`.`Returned_date` AS `Returned_date` FROM `returned_books` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_users`
--
DROP TABLE IF EXISTS `insert_data_into_users`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_users`  AS SELECT `users`.`User_ID` AS `User_ID`, `users`.`Learner_ID` AS `Learner_ID`, `users`.`Librarian_ID` AS `Librarian_ID`, `users`.`Usernsme` AS `Usernsme`, `users`.`Passphrase` AS `Passphrase` FROM `users` ;

-- --------------------------------------------------------

--
-- Structure for view `to_concider_subquery`
--
DROP TABLE IF EXISTS `to_concider_subquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `to_concider_subquery`  AS SELECT `learners`.`Learner_ID` AS `Learner_ID`, `learners`.`F_name` AS `F_name`, `learners`.`L_name` AS `L_name`, `learners`.`Gender` AS `Gender`, `learners`.`Email` AS `Email`, `learners`.`College` AS `College`, `learners`.`Department` AS `Department` FROM `learners` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`Book_ID`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`Borrow_ID`),
  ADD KEY `Learner_ID` (`Learner_ID`,`Book_ID`),
  ADD KEY `Book_ID` (`Book_ID`);

--
-- Indexes for table `issued_books`
--
ALTER TABLE `issued_books`
  ADD PRIMARY KEY (`Issue_ID`),
  ADD KEY `Learner_ID` (`Learner_ID`,`Book_ID`,`Librarian_ID`),
  ADD KEY `Book_ID` (`Book_ID`),
  ADD KEY `Librarian_ID` (`Librarian_ID`);

--
-- Indexes for table `learners`
--
ALTER TABLE `learners`
  ADD PRIMARY KEY (`Learner_ID`);

--
-- Indexes for table `librarians`
--
ALTER TABLE `librarians`
  ADD PRIMARY KEY (`Librarian_ID`);

--
-- Indexes for table `lost_books`
--
ALTER TABLE `lost_books`
  ADD PRIMARY KEY (`Lost_ID`),
  ADD KEY `Learner_ID` (`Learner_ID`,`Book_ID`),
  ADD KEY `Book_ID` (`Book_ID`);

--
-- Indexes for table `returned_books`
--
ALTER TABLE `returned_books`
  ADD PRIMARY KEY (`Return_ID`),
  ADD KEY `Learner_ID` (`Learner_ID`,`Book_ID`,`Librarian_ID`),
  ADD KEY `Book_ID` (`Book_ID`),
  ADD KEY `Librarian_ID` (`Librarian_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_ID`),
  ADD KEY `Learner_ID` (`Learner_ID`,`Librarian_ID`),
  ADD KEY `Librarian_ID` (`Librarian_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
  MODIFY `Borrow_ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `issued_books`
--
ALTER TABLE `issued_books`
  MODIFY `Issue_ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lost_books`
--
ALTER TABLE `lost_books`
  MODIFY `Lost_ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrow`
--
ALTER TABLE `borrow`
  ADD CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`Book_ID`) REFERENCES `books` (`Book_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `borrow_ibfk_2` FOREIGN KEY (`Learner_ID`) REFERENCES `learners` (`Learner_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `issued_books`
--
ALTER TABLE `issued_books`
  ADD CONSTRAINT `issued_books_ibfk_1` FOREIGN KEY (`Book_ID`) REFERENCES `books` (`Book_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `issued_books_ibfk_2` FOREIGN KEY (`Librarian_ID`) REFERENCES `librarians` (`Librarian_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `issued_books_ibfk_3` FOREIGN KEY (`Learner_ID`) REFERENCES `learners` (`Learner_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lost_books`
--
ALTER TABLE `lost_books`
  ADD CONSTRAINT `lost_books_ibfk_1` FOREIGN KEY (`Book_ID`) REFERENCES `books` (`Book_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lost_books_ibfk_2` FOREIGN KEY (`Learner_ID`) REFERENCES `learners` (`Learner_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `returned_books`
--
ALTER TABLE `returned_books`
  ADD CONSTRAINT `returned_books_ibfk_1` FOREIGN KEY (`Book_ID`) REFERENCES `books` (`Book_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `returned_books_ibfk_2` FOREIGN KEY (`Librarian_ID`) REFERENCES `librarians` (`Librarian_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `returned_books_ibfk_3` FOREIGN KEY (`Learner_ID`) REFERENCES `learners` (`Learner_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`Librarian_ID`) REFERENCES `librarians` (`Librarian_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`Learner_ID`) REFERENCES `learners` (`Learner_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
