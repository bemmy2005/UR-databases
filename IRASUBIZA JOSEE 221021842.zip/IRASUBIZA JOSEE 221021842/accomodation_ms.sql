-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 01:23 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accomodation_ms`
--
CREATE DATABASE IF NOT EXISTS `accomodation_ms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `accomodation_ms`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `admininsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `admininsert` (IN `adminlid` INT(255) UNSIGNED, IN `username` VARCHAR(255), IN `password` VARCHAR(255))  INSERT INTO room VALUES(1,josee,jojo)$$

DROP PROCEDURE IF EXISTS `deleteadmin`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteadmin` (IN `adminid` INT(255), IN `username` VARCHAR(255), IN `password` VARCHAR(255))  DELETE FROM admin WHERE adminid=1$$

DROP PROCEDURE IF EXISTS `deletehostel`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletehostel` (IN `hostelid` INT(255), IN `hostelname` VARCHAR(255), IN `adminid` VARCHAR(255))  DELETE FROM hostel WHERE hostelid=1$$

DROP PROCEDURE IF EXISTS `deleteProcedure`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteProcedure` (IN `customer_id` INT(11), IN `customer_name` VARCHAR(30))  delete from customer where id=1$$

DROP PROCEDURE IF EXISTS `DisplayProcedure`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayProcedure` (IN `customer_id` INT(11), IN `customer_name` VARCHAR(30), IN `customer_gender` VARCHAR(30))  select* from customer$$

DROP PROCEDURE IF EXISTS `hostelinsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `hostelinsert` (IN `hostelid` INT(255) UNSIGNED, IN `hostelname` INT(255), IN `st_id` INT(255))  INSERT INTO room VALUES(1,benghazi,20)$$

DROP PROCEDURE IF EXISTS `paymentinsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `paymentinsert` (IN `p_id` INT(255) UNSIGNED, IN `amount` INT(255), IN `date` DATE, IN `st_id` INT(255))  INSERT INTO payment VALUES(10,80000,6/8,45)$$

DROP PROCEDURE IF EXISTS `procedureTOinsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `procedureTOinsert` (IN `customer_id` INT(11), IN `customer_name` VARCHAR(20), IN `customer_gender` VARCHAR(30), IN `customer_contacts` INT(10), IN `customer_address` VARCHAR(10))  INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_gender`, `customer_address`, `customer_contacts`) VALUES ('5', 'mugabo', 'male', 'huye', '078389364')$$

DROP PROCEDURE IF EXISTS `roominsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `roominsert` (IN `roomid` INT(255) UNSIGNED, IN `roomnumber` INT(255), IN `st_id` INT(255))  INSERT INTO room VALUES(1,16,20)$$

DROP PROCEDURE IF EXISTS `selectadmin`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectadmin` (IN `adminid` INT(255), IN `username` VARCHAR(255), IN `password` VARCHAR(255))  SELECT * FROM admin$$

DROP PROCEDURE IF EXISTS `selecthostel`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selecthostel` (IN `hostelid` INT(255), IN `hostelname` VARCHAR(255), IN `adminid` VARCHAR(255))  SELECT * FROM hostel$$

DROP PROCEDURE IF EXISTS `selectpame`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectpame` (IN `p_id` INT(255), IN `date` DATE, IN `amount` INT(255))  SELECT*FROM payment WHERE amount<(SELECT min(amount)FROM payment)$$

DROP PROCEDURE IF EXISTS `selectpamen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectpamen` (IN `p_id` INT(255), IN `date` DATE, IN `amount` INT(255))  SELECT * FROM payment$$

DROP PROCEDURE IF EXISTS `selectroom`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectroom` (IN `roomid` INT(255), IN `roomnumber` VARCHAR(255), IN `st_id` INT(255))  SELECT * FROM room$$

DROP PROCEDURE IF EXISTS `selectsudent`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `selectsudent` (IN `st_id` INT(255), IN `fname` VARCHAR(255), IN `lname` VARCHAR(255), IN `gender` VARCHAR(255))  SELECT * FROM student$$

DROP PROCEDURE IF EXISTS `studentinsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `studentinsert` (IN `st_id` INT(255) UNSIGNED, IN `fname` VARCHAR(255), IN `lname` VARCHAR(255), IN `gender` VARCHAR(255))  INSERT INTO clients VALUES(14,'gakuru','benard','male')$$

DROP PROCEDURE IF EXISTS `updateadmin`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateadmin` (IN `adminid` INT(255), IN `username` VARCHAR(255), IN `password` VARCHAR(255))  UPDATE admin SET username='kalisa james' WHERE adminid=2$$

DROP PROCEDURE IF EXISTS `updateProcedure`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateProcedure` (IN `customer_id` INT(11), IN `customer_name` VARCHAR(20), IN `customer_gender` VARCHAR(30), IN `customer_contacts` INT(11), IN `customer_address` VARCHAR(10))  UPDATE customer SET customer_name='peter' where customer_id=1$$

DROP PROCEDURE IF EXISTS `updateroom`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateroom` (IN `roomid` INT(255), IN `roomnumber` VARCHAR(255), IN `st_id` INT(255))  UPDATE admin SET roomnumber='408' WHERE roomid=1$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Creation: Jul 25, 2022 at 08:29 PM
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `adminid` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `admin`:
--

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `username`, `password`) VALUES
(1, 'aline', 'mukunziwabo'),
(2, 'kirezi', 'kevin'),
(21, 'ange', '12345'),
(23, 'uwase', '11111');

--
-- Triggers `admin`
--
DROP TRIGGER IF EXISTS `InsertIntoadmin`;
DELIMITER $$
CREATE TRIGGER `InsertIntoadmin` AFTER INSERT ON `admin` FOR EACH ROW INSERT INTO admin VALUES(5,'danilla','RAE305')
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updateadminTriggers`;
DELIMITER $$
CREATE TRIGGER `updateadminTriggers` AFTER UPDATE ON `admin` FOR EACH ROW UPDATE admin SET username='calima' where adminid=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `hostel`
--
-- Creation: Jul 25, 2022 at 08:39 PM
--

DROP TABLE IF EXISTS `hostel`;
CREATE TABLE IF NOT EXISTS `hostel` (
  `hostelid` int(255) NOT NULL,
  `hostname` varchar(255) NOT NULL,
  `adminid` int(255) NOT NULL,
  PRIMARY KEY (`hostelid`),
  KEY `admin_hostel` (`adminid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `hostel`:
--   `adminid`
--       `admin` -> `adminid`
--

--
-- Dumping data for table `hostel`
--

INSERT INTO `hostel` (`hostelid`, `hostname`, `adminid`) VALUES
(3, 'miseu_reole', 21),
(4, 'mamba', 23),
(23, 'benghazi', 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listadmins`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listadmins`;
CREATE TABLE IF NOT EXISTS `listadmins` (
`adminid` int(255)
,`username` varchar(255)
,`password` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listhostel`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listhostel`;
CREATE TABLE IF NOT EXISTS `listhostel` (
`hostelid` int(255)
,`hostname` varchar(255)
,`adminid` int(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listpayment`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listpayment`;
CREATE TABLE IF NOT EXISTS `listpayment` (
`p_id` int(255)
,`date` datetime
,`amount` int(255)
,`st_id` int(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listroom`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `listroom`;
CREATE TABLE IF NOT EXISTS `listroom` (
`roomid` int(255)
,`roomnumber` varchar(255)
,`st_id` int(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `liststudent`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `liststudent`;
CREATE TABLE IF NOT EXISTS `liststudent` (
`st_id` int(255)
,`fname` varchar(255)
,`lname` varchar(255)
,`gender` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--
-- Creation: Jul 25, 2022 at 08:36 PM
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `p_id` int(255) NOT NULL,
  `date` datetime NOT NULL,
  `amount` int(255) NOT NULL,
  `st_id` int(255) NOT NULL,
  PRIMARY KEY (`p_id`),
  KEY `student_payment` (`st_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `payment`:
--   `st_id`
--       `student` -> `st_id`
--

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`p_id`, `date`, `amount`, `st_id`) VALUES
(2, '2022-07-06 00:00:00', 500000, 8),
(4, '2022-07-22 00:00:00', 200000, 23),
(100, '2022-07-05 00:00:00', 40000, 23),
(209, '2022-07-19 00:00:00', 30000, 8);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--
-- Creation: Jul 25, 2022 at 08:33 PM
--

DROP TABLE IF EXISTS `room`;
CREATE TABLE IF NOT EXISTS `room` (
  `roomid` int(255) NOT NULL,
  `roomnumber` varchar(255) NOT NULL,
  `st_id` int(255) NOT NULL,
  PRIMARY KEY (`roomid`),
  KEY `student_room` (`st_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `room`:
--   `st_id`
--       `student` -> `st_id`
--

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomid`, `roomnumber`, `st_id`) VALUES
(1, '15', 8),
(2, '67', 23),
(3, '15', 23),
(5, '687', 8);

--
-- Triggers `room`
--
DROP TRIGGER IF EXISTS `InsertIntoroom`;
DELIMITER $$
CREATE TRIGGER `InsertIntoroom` AFTER INSERT ON `room` FOR EACH ROW INSERT INTO room VALUES(8,'340',1)
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `deleteroomTriggers`;
DELIMITER $$
CREATE TRIGGER `deleteroomTriggers` AFTER DELETE ON `room` FOR EACH ROW DELETE FROM room WHERE roomid=2
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--
-- Creation: Jul 25, 2022 at 08:26 PM
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `st_id` int(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  PRIMARY KEY (`st_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `student`:
--

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`st_id`, `fname`, `lname`, `gender`) VALUES
(2, 'nkurunziza', 'gadi', 'male'),
(3, 'wian', 'ishimwe', 'male'),
(5, 'chris', 'mbabazi', 'male'),
(8, 'mukunzi', 'josee', 'female'),
(23, 'ganza abelson', 'kelvin', 'male');

--
-- Triggers `student`
--
DROP TRIGGER IF EXISTS `updatestudentTriggers`;
DELIMITER $$
CREATE TRIGGER `updatestudentTriggers` AFTER UPDATE ON `student` FOR EACH ROW UPDATE student SET fname='naomi' WHERE st_id=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewpayment`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `viewpayment`;
CREATE TABLE IF NOT EXISTS `viewpayment` (
`p_id` int(255)
,`date` datetime
,`amount` int(255)
,`st_id` int(255)
);

-- --------------------------------------------------------

--
-- Structure for view `listadmins` exported as a table
--
DROP TABLE IF EXISTS `listadmins`;
CREATE TABLE IF NOT EXISTS `listadmins`(
    `adminid` int(255) NOT NULL,
    `username` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
    `password` varchar(255) COLLATE latin1_swedish_ci NOT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listhostel` exported as a table
--
DROP TABLE IF EXISTS `listhostel`;
CREATE TABLE IF NOT EXISTS `listhostel`(
    `hostelid` int(255) NOT NULL,
    `hostname` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
    `adminid` int(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listpayment` exported as a table
--
DROP TABLE IF EXISTS `listpayment`;
CREATE TABLE IF NOT EXISTS `listpayment`(
    `p_id` int(255) NOT NULL,
    `date` datetime NOT NULL,
    `amount` int(255) NOT NULL,
    `st_id` int(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `listroom` exported as a table
--
DROP TABLE IF EXISTS `listroom`;
CREATE TABLE IF NOT EXISTS `listroom`(
    `roomid` int(255) NOT NULL,
    `roomnumber` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
    `st_id` int(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `liststudent` exported as a table
--
DROP TABLE IF EXISTS `liststudent`;
CREATE TABLE IF NOT EXISTS `liststudent`(
    `st_id` int(255) NOT NULL,
    `fname` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
    `lname` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
    `gender` varchar(255) COLLATE latin1_swedish_ci NOT NULL
);

-- --------------------------------------------------------

--
-- Structure for view `viewpayment` exported as a table
--
DROP TABLE IF EXISTS `viewpayment`;
CREATE TABLE IF NOT EXISTS `viewpayment`(
    `p_id` int(255) NOT NULL,
    `date` datetime NOT NULL,
    `amount` int(255) NOT NULL,
    `st_id` int(255) NOT NULL
);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hostel`
--
ALTER TABLE `hostel`
  ADD CONSTRAINT `admin_hostel` FOREIGN KEY (`adminid`) REFERENCES `admin` (`adminid`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `student_payment` FOREIGN KEY (`st_id`) REFERENCES `student` (`st_id`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `student_room` FOREIGN KEY (`st_id`) REFERENCES `student` (`st_id`);


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table admin
--

--
-- Metadata for table hostel
--

--
-- Metadata for table listadmins
--

--
-- Metadata for table listhostel
--

--
-- Metadata for table listpayment
--

--
-- Metadata for table listroom
--

--
-- Metadata for table liststudent
--

--
-- Metadata for table payment
--

--
-- Metadata for table room
--

--
-- Metadata for table student
--

--
-- Metadata for table viewpayment
--

--
-- Metadata for database accomodation_ms
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
