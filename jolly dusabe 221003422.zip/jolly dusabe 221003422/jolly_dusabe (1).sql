-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 03:08 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jolly_dusabe`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `boo` ()  INSERT INTO booking VALUES('8','2','3','2/3/20002')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `book_pro` ()  SELECT * from booking$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cust_pro` ()  SELECT * from customer$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `joll` ()  SELECT names FROM customer WHERE names NOT IN(SELECT c_id FROM booking)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `joo` ()  UPDATE customer set names='gusenga kwiza' WHERE c_id='1'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `jool` ()  DELETE from customer WHERE c_id='2'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pro` ()  INSERT INTO customer VALUES('7','trix','kat','223456')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tike` ()  INSERT INTO ticket VALUES('1','canada','5:00','5/5/2022')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tike_pro` ()  SELECT * from ticket$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `book`
-- (See below for the actual view)
--
CREATE TABLE `book` (
`b_id` int(12)
,`c_id` int(12)
,`t_number` int(12)
,`date` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `b_id` int(12) NOT NULL,
  `c_id` int(12) NOT NULL,
  `t_number` int(12) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`b_id`, `c_id`, `t_number`, `date`) VALUES
(1, 1, 2, '4/12/2022'),
(2, 3, 1, '1/1/2023'),
(3, 4, 2, '4/5/2022'),
(4, 5, 3, '24/2/2022'),
(5, 2, 1, '7/8/2022');

--
-- Triggers `booking`
--
DELIMITER $$
CREATE TRIGGER `jun` AFTER DELETE ON `booking` FOR EACH ROW DELETE FROM booking WHERE b_id='2'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `kez` AFTER UPDATE ON `booking` FOR EACH ROW UPDATE booking  SET date='6/7/2023' WHERE b_id='3'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(12) NOT NULL,
  `names` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `id_number` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `names`, `phonenumber`, `id_number`) VALUES
(1, 'dusabe jolly', '0789345262', '1234'),
(2, 'ishimwe innocent', '0787654341', '2345'),
(3, 'bizaza miss', '0786543212', '34567'),
(4, 'barera baby', '0786534212', '45678'),
(5, 'benny baidu', '0788536354', '67890'),
(20, 'emery', '0789678345', '2001234567');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `JOLLYY` AFTER INSERT ON `customer` FOR EACH ROW INSERT into customer VALUES('12','isimbi nanty','0788878345','20012')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `junior` AFTER DELETE ON `customer` FOR EACH ROW DELETE FROM customer WHERE c_id='20'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `dusabe`
-- (See below for the actual view)
--
CREATE TABLE `dusabe` (
`names` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `info`
-- (See below for the actual view)
--
CREATE TABLE `info` (
`c_id` int(12)
,`names` varchar(100)
,`phonenumber` varchar(100)
,`id_number` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `tic`
-- (See below for the actual view)
--
CREATE TABLE `tic` (
`t_number` int(12)
,`destination` varchar(100)
,`hour` varchar(100)
,`date` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `t_number` int(12) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `hour` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`t_number`, `destination`, `hour`, `date`) VALUES
(1, 'canada', '18:00', '2/2/2022'),
(2, 'zanzibar', '6:00', '1/1/2022'),
(3, 'goma', '2:00', '3/3/2022'),
(4, 'congo', '3:00', '4/5/2022');

--
-- Triggers `ticket`
--
DELIMITER $$
CREATE TRIGGER `dus` AFTER INSERT ON `ticket` FOR EACH ROW INSERT into ticket VALUES('9','kenya','1:30','5/7/2022')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `trix`
-- (See below for the actual view)
--
CREATE TABLE `trix` (
`c_id` int(12)
,`names` varchar(100)
,`phonenumber` varchar(100)
,`id_number` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `book`
--
DROP TABLE IF EXISTS `book`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `book`  AS  select `booking`.`b_id` AS `b_id`,`booking`.`c_id` AS `c_id`,`booking`.`t_number` AS `t_number`,`booking`.`date` AS `date` from `booking` ;

-- --------------------------------------------------------

--
-- Structure for view `dusabe`
--
DROP TABLE IF EXISTS `dusabe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `dusabe`  AS  select `customer`.`names` AS `names` from `customer` where (not(`customer`.`names` in (select `booking`.`c_id` from `booking`))) ;

-- --------------------------------------------------------

--
-- Structure for view `info`
--
DROP TABLE IF EXISTS `info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `info`  AS  select `customer`.`c_id` AS `c_id`,`customer`.`names` AS `names`,`customer`.`phonenumber` AS `phonenumber`,`customer`.`id_number` AS `id_number` from `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `tic`
--
DROP TABLE IF EXISTS `tic`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tic`  AS  select `ticket`.`t_number` AS `t_number`,`ticket`.`destination` AS `destination`,`ticket`.`hour` AS `hour`,`ticket`.`date` AS `date` from `ticket` ;

-- --------------------------------------------------------

--
-- Structure for view `trix`
--
DROP TABLE IF EXISTS `trix`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trix`  AS  select `customer`.`c_id` AS `c_id`,`customer`.`names` AS `names`,`customer`.`phonenumber` AS `phonenumber`,`customer`.`id_number` AS `id_number` from `customer` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`b_id`),
  ADD KEY `c_id` (`c_id`),
  ADD KEY `t_number` (`t_number`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`t_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `b_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `t_number` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`t_number`) REFERENCES `ticket` (`t_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
