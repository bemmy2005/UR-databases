-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 12:28 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ruthabimana`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getclientsDetails` ()  BEGIN
    select * from client;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(10) NOT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `datein` date DEFAULT NULL,
  `dateout` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `receipt_id` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `client`
--
DELIMITER $$
CREATE TRIGGER `insertclients` AFTER INSERT ON `client` FOR EACH ROW BEGIN  
INSERT INTO client VALUES (firstname); 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateclient` AFTER UPDATE ON `client` FOR EACH ROW BEGIN  
UPDATE client SET client_id='003'; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `clientlist`
-- (See below for the actual view)
--
CREATE TABLE `clientlist` (
`client_id` int(10)
,`firstname` varchar(30)
,`lastname` varchar(20)
,`email` varchar(30)
,`phone` varchar(15)
,`gender` varchar(10)
,`datein` date
,`dateout` date
,`user_id` int(11)
,`receipt_id` int(11)
,`payment_id` int(11)
,`room_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(5) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `amount` varchar(10) DEFAULT NULL,
  `receipt_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Stand-in structure for view `payment_list`
-- (See below for the actual view)
--
CREATE TABLE `payment_list` (
`payment_id` int(5)
,`type` varchar(10)
,`amount` varchar(10)
,`receipt_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `receipt_id` int(5) NOT NULL,
  `date` varchar(10) DEFAULT NULL,
  `amount` varchar(10) DEFAULT NULL,
  `firstname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Stand-in structure for view `receipt_list`
-- (See below for the actual view)
--
CREATE TABLE `receipt_list` (
`receipt_id` int(5)
,`date` varchar(10)
,`amount` varchar(10)
,`firstname` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(5) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `number` varchar(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `cost` varchar(10) DEFAULT NULL,
  `user_id` int(10) NOT NULL,
  `receipt_id` int(10) NOT NULL,
  `payment_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `room`
--
DELIMITER $$
CREATE TRIGGER `update` AFTER UPDATE ON `room` FOR EACH ROW UPDATE room SET room_id='004'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `room_list`
-- (See below for the actual view)
--
CREATE TABLE `room_list` (
`room_id` int(5)
,`type` varchar(10)
,`number` varchar(10)
,`status` varchar(10)
,`cost` varchar(10)
,`user_id` int(10)
,`receipt_id` int(10)
,`payment_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(5) NOT NULL,
  `fname` varchar(10) DEFAULT NULL,
  `lname` varchar(10) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  `email` varchar(10) DEFAULT NULL,
  `role` varchar(5) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `insertuser` AFTER INSERT ON `user` FOR EACH ROW BEGIN  
INSERT INTO user VALUES (fname); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_list`
-- (See below for the actual view)
--
CREATE TABLE `user_list` (
`user_id` int(5)
,`fname` varchar(10)
,`lname` varchar(10)
,`phone` varchar(13)
,`email` varchar(10)
,`role` varchar(5)
,`status` varchar(10)
,`username` varchar(30)
,`Password` varchar(30)
);

-- --------------------------------------------------------

--
-- Structure for view `clientlist`
--
DROP TABLE IF EXISTS `clientlist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clientlist`  AS SELECT `client`.`client_id` AS `client_id`, `client`.`firstname` AS `firstname`, `client`.`lastname` AS `lastname`, `client`.`email` AS `email`, `client`.`phone` AS `phone`, `client`.`gender` AS `gender`, `client`.`datein` AS `datein`, `client`.`dateout` AS `dateout`, `client`.`user_id` AS `user_id`, `client`.`receipt_id` AS `receipt_id`, `client`.`payment_id` AS `payment_id`, `client`.`room_id` AS `room_id` FROM `client` ;

-- --------------------------------------------------------

--
-- Structure for view `payment_list`
--
DROP TABLE IF EXISTS `payment_list`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payment_list`  AS SELECT `payment`.`payment_id` AS `payment_id`, `payment`.`type` AS `type`, `payment`.`amount` AS `amount`, `payment`.`receipt_id` AS `receipt_id` FROM `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `receipt_list`
--
DROP TABLE IF EXISTS `receipt_list`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `receipt_list`  AS SELECT `receipt`.`receipt_id` AS `receipt_id`, `receipt`.`date` AS `date`, `receipt`.`amount` AS `amount`, `receipt`.`firstname` AS `firstname` FROM `receipt` ;

-- --------------------------------------------------------

--
-- Structure for view `room_list`
--
DROP TABLE IF EXISTS `room_list`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `room_list`  AS SELECT `room`.`room_id` AS `room_id`, `room`.`type` AS `type`, `room`.`number` AS `number`, `room`.`status` AS `status`, `room`.`cost` AS `cost`, `room`.`user_id` AS `user_id`, `room`.`receipt_id` AS `receipt_id`, `room`.`payment_id` AS `payment_id` FROM `room` ;

-- --------------------------------------------------------

--
-- Structure for view `user_list`
--
DROP TABLE IF EXISTS `user_list`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_list`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`fname` AS `fname`, `user`.`lname` AS `lname`, `user`.`phone` AS `phone`, `user`.`email` AS `email`, `user`.`role` AS `role`, `user`.`status` AS `status`, `user`.`username` AS `username`, `user`.`Password` AS `Password` FROM `user` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `receipt_id` (`receipt_id`),
  ADD KEY `payment_id` (`payment_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `payment_recept` (`receipt_id`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`receipt_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `room_user` (`user_id`),
  ADD KEY `room_recept` (`receipt_id`),
  ADD KEY `room_payment` (`payment_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `client_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`),
  ADD CONSTRAINT `client_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `client_ibfk_3` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`receipt_id`),
  ADD CONSTRAINT `client_ibfk_4` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_recept` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`receipt_id`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_payment` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`),
  ADD CONSTRAINT `room_recept` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`receipt_id`),
  ADD CONSTRAINT `room_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
