-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 01:54 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isengwe_olga`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `agency_display` ()   select * from agency$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `agency_procedure` ()   insert into agency values('3','Trinity','trinity@gmail.com','0788988766')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `booking_display` ()   select * from booking$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `booking_procedure` ()   insert into booking values('6','4','5','12h00')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `bus_delete` ()   delete from bus where bus_id='5'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `bus_display` ()   select * from bus$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `bus_procedure` ()   insert into bus values('5','rad345g','3')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `bus_update` ()   update bus set bus_plate='rac456l' where bus_id='3'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `client_delete` ()   delete from client where client_id='3'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `client_display` ()   select * from client$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `client_procedure` ()   insert into client values('1','dusabe','0788345678','Kicukiro')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `client_update` ()   update client set client_name='semuhungu' where client_id='4'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `subquery` ()   select client_name from client where client_name not in(select client_id from booking)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `agency`
--

CREATE TABLE `agency` (
  `agency_id` int(10) NOT NULL,
  `agency_name` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `phone_number` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agency`
--

INSERT INTO `agency` (`agency_id`, `agency_name`, `email`, `phone_number`) VALUES
(1, 'Horizon', 'ritco@gmail.com', 788345566),
(2, 'Volcano', 'volcano@gmail.com', 783234566),
(3, 'Trinity', 'trinity@gmail.com', 788988766);

--
-- Triggers `agency`
--
DELIMITER $$
CREATE TRIGGER `agency_update` AFTER UPDATE ON `agency` FOR EACH ROW UPDATE agency SET agency_name='Star' WHERE agency_id='1'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `agency_view`
-- (See below for the actual view)
--
CREATE TABLE `agency_view` (
`agency_id` int(10)
,`agency_name` varchar(20)
,`email` varchar(20)
,`phone_number` int(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(10) NOT NULL,
  `client_id` int(10) DEFAULT NULL,
  `bus_id` int(10) DEFAULT NULL,
  `dep_time` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `client_id`, `bus_id`, `dep_time`) VALUES
(1, 1, 1, '11h00'),
(2, 2, 2, '11h00'),
(6, 4, 5, '12h00');

--
-- Triggers `booking`
--
DELIMITER $$
CREATE TRIGGER `booking_delete` AFTER DELETE ON `booking` FOR EACH ROW DELETE FROM booking WHERE booking_id='1'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `booking_trigger` AFTER INSERT ON `booking` FOR EACH ROW INSERT INTO booking VALUES('6','3','2','14h00')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `booking_view`
-- (See below for the actual view)
--
CREATE TABLE `booking_view` (
`booking_id` int(10)
,`client_id` int(10)
,`bus_id` int(10)
,`dep_time` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `bus_id` int(10) NOT NULL,
  `bus_plate` varchar(20) DEFAULT NULL,
  `agency_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`bus_id`, `bus_plate`, `agency_id`) VALUES
(1, 'raf234g', 1),
(2, 'rab123b', 2),
(5, 'rad345g', 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `bus_view`
-- (See below for the actual view)
--
CREATE TABLE `bus_view` (
`bus_id` int(10)
,`bus_plate` varchar(20)
,`agency_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(10) NOT NULL,
  `client_name` varchar(20) DEFAULT NULL,
  `phone_number` int(20) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `client_name`, `phone_number`, `address`) VALUES
(1, 'Ndizihiwe', 788123456, 'Kicukiro'),
(2, 'michel', 782134456, 'Kimironko'),
(4, 'semuhungu', 788345678, 'Kicukiro'),
(5, 'dusabe', 788345678, 'Kicukiro');

--
-- Triggers `client`
--
DELIMITER $$
CREATE TRIGGER `client_delete` AFTER DELETE ON `client` FOR EACH ROW DELETE FROM client WHERE client_id='2'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `client_trigger` AFTER INSERT ON `client` FOR EACH ROW INSERT INTO client VALUES('6','Barera','0788987878','Gisozi')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `client_update` AFTER UPDATE ON `client` FOR EACH ROW UPDATE client SET client_name='Niyonzima' WHERE client_id='4'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `client_view`
-- (See below for the actual view)
--
CREATE TABLE `client_view` (
`client_id` int(10)
,`client_name` varchar(20)
,`phone_number` int(20)
,`address` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `subquery`
-- (See below for the actual view)
--
CREATE TABLE `subquery` (
`client_name` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure for view `agency_view`
--
DROP TABLE IF EXISTS `agency_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `agency_view`  AS SELECT `agency`.`agency_id` AS `agency_id`, `agency`.`agency_name` AS `agency_name`, `agency`.`email` AS `email`, `agency`.`phone_number` AS `phone_number` FROM `agency``agency`  ;

-- --------------------------------------------------------

--
-- Structure for view `booking_view`
--
DROP TABLE IF EXISTS `booking_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `booking_view`  AS SELECT `booking`.`booking_id` AS `booking_id`, `booking`.`client_id` AS `client_id`, `booking`.`bus_id` AS `bus_id`, `booking`.`dep_time` AS `dep_time` FROM `booking``booking`  ;

-- --------------------------------------------------------

--
-- Structure for view `bus_view`
--
DROP TABLE IF EXISTS `bus_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bus_view`  AS SELECT `bus`.`bus_id` AS `bus_id`, `bus`.`bus_plate` AS `bus_plate`, `bus`.`agency_id` AS `agency_id` FROM `bus``bus`  ;

-- --------------------------------------------------------

--
-- Structure for view `client_view`
--
DROP TABLE IF EXISTS `client_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `client_view`  AS SELECT `client`.`client_id` AS `client_id`, `client`.`client_name` AS `client_name`, `client`.`phone_number` AS `phone_number`, `client`.`address` AS `address` FROM `client``client`  ;

-- --------------------------------------------------------

--
-- Structure for view `subquery`
--
DROP TABLE IF EXISTS `subquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subquery`  AS SELECT `client`.`client_name` AS `client_name` FROM `client` WHERE !(`client`.`client_name` in (select `booking`.`client_id` from `booking`))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agency`
--
ALTER TABLE `agency`
  ADD PRIMARY KEY (`agency_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `bus_id` (`bus_id`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`bus_id`),
  ADD KEY `agency_id` (`agency_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`bus_id`) REFERENCES `bus` (`bus_id`);

--
-- Constraints for table `bus`
--
ALTER TABLE `bus`
  ADD CONSTRAINT `bus_ibfk_1` FOREIGN KEY (`agency_id`) REFERENCES `agency` (`agency_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
