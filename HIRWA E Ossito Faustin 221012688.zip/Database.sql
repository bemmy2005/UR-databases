-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 09:21 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ehuyefinder`
--
CREATE DATABASE IF NOT EXISTS `ehuyefinder` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ehuyefinder`;

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteincustomer` (IN `customer_ID` INT(3))  BEGIN DELETE FROM customer where customer_ID=customer_ID; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcustomerinfo` ()  BEGIN SELECT* FROM customer; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getdeliveryinfo` ()  BEGIN SELECT* FROM delivery; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getemployeeinfo` ()  BEGIN SELECT* FROM employee; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getordersinfo` ()  BEGIN SELECT* FROM orders; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getpaymentinfo` ()  BEGIN SELECT* FROM payment; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getproductinfo` ()  BEGIN SELECT* FROM product; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatecustomer` (IN `customer_id` INT(4))  BEGIN UPDATE customer SET firstname='SHEMA' WHERE customer_id=customer_id; END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` int(11) NOT NULL,
  `Firstname` varchar(20) NOT NULL,
  `Lastname` varchar(15) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Tel_number` int(2) NOT NULL,
  `Email_address` varchar(20) NOT NULL,
  `Address` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_id`, `Firstname`, `Lastname`, `Gender`, `Tel_number`, `Email_address`, `Address`) VALUES
(1, 'MUKUNZI', 'Bonfils', 'Male', 79869686, 'mukunzi@gmail.com', 'Huye 1'),
(3, 'Syaka', 'Prince', 'Male', 7859574, 'shyaka@gmail.com', 'Tumba2');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `after_update_customer` AFTER UPDATE ON `customer` FOR EACH ROW BEGIN
UPDATE users set users.Passphrase=CONCATs(customer.Firstname,'@',customer.Lastname )WHERE users.customre_ID=NEW.customer_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_view`
--
CREATE TABLE `customer_view` (
`Customer_id` int(11)
,`Firstname` varchar(20)
,`Lastname` varchar(15)
,`Gender` varchar(6)
,`Tel_number` int(2)
,`Email_address` varchar(20)
,`Address` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `Delivery_id` int(3) NOT NULL,
  `Delivery_Address` varchar(20) NOT NULL,
  `Delivery_details` varchar(20) NOT NULL,
  `Product_id` int(4) NOT NULL,
  `Delivery_amount` int(4) NOT NULL,
  `Customer_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`Delivery_id`, `Delivery_Address`, `Delivery_details`, `Product_id`, `Delivery_amount`, `Customer_id`) VALUES
(1, 'Huye', 'shoes delivered well', 1, 2000, 0),
(2, 'Huye,Tumba', 'T-shirt in progress', 3, 70000, 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delivery_view`
--
CREATE TABLE `delivery_view` (
`Delivery_id` int(3)
,`Delivery_Address` varchar(20)
,`Delivery_details` varchar(20)
,`Product_id` int(4)
,`Delivery_amount` int(4)
,`Customer_id` int(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `employee_view`
--
CREATE TABLE `employee_view` (
`Employee_id` int(3)
,`Employee_Firstname` varchar(20)
,`Employee_Lastname` varchar(20)
,`Empoyee_Tel` bigint(10)
,`Employee_Address` varchar(20)
,`Employee_Emailaddress` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Employee_id` int(3) NOT NULL,
  `Employee_Firstname` varchar(20) NOT NULL,
  `Employee_Lastname` varchar(20) NOT NULL,
  `Empoyee_Tel` bigint(10) NOT NULL,
  `Employee_Address` varchar(20) NOT NULL,
  `Employee_Emailaddress` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Employee_id`, `Employee_Firstname`, `Employee_Lastname`, `Empoyee_Tel`, `Employee_Address`, `Employee_Emailaddress`) VALUES
(1, 'Umwali', 'Keza Vanessa', 78989789, 'Huye', 'kezavan@yahoo.com'),
(2, 'KEZA', 'Bella', 7388273837, 'Huye, Mukoni', 'kezabella@gmail.com'),
(3, 'Mucyo', 'Kevin ', 7900000300, 'Mukoni', 'mucyok@gmail.com'),
(4, 'NTWALI', 'Kevin', 78777778, 'Tumba2', 'ntwali@gmail.com');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_customer`
--
CREATE TABLE `insert_data_into_customer` (
`Customer_id` int(11)
,`Firstname` varchar(20)
,`Lastname` varchar(15)
,`Gender` varchar(6)
,`Tel_number` int(2)
,`Email_address` varchar(20)
,`Address` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_delivery`
--
CREATE TABLE `insert_data_into_delivery` (
`Delivery_id` int(3)
,`Delivery_Address` varchar(20)
,`Delivery_details` varchar(20)
,`Product_id` int(4)
,`Delivery_amount` int(4)
,`Customer_id` int(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_employees`
--
CREATE TABLE `insert_data_into_employees` (
`Employee_id` int(3)
,`Employee_Firstname` varchar(20)
,`Employee_Lastname` varchar(20)
,`Empoyee_Tel` bigint(10)
,`Employee_Address` varchar(20)
,`Employee_Emailaddress` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_orders`
--
CREATE TABLE `insert_data_into_orders` (
`Order_id` int(4)
,`Order_details` varchar(30)
,`product_id` int(4)
,`Customer_id` int(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_payments`
--
CREATE TABLE `insert_data_into_payments` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_products`
--
CREATE TABLE `insert_data_into_products` (
`Product_id` int(4)
,`Product_price` int(4)
,`Quantity` int(3)
,`Customer_id` int(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_rent_houses`
--
CREATE TABLE `insert_data_into_rent_houses` (
);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Order_id` int(4) NOT NULL,
  `Order_details` varchar(30) NOT NULL,
  `product_id` int(4) NOT NULL,
  `Customer_id` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Order_id`, `Order_details`, `product_id`, `Customer_id`) VALUES
(1, 'Ordered at 9am', 1, 1),
(2, 'Ordered at 12pm', 2, 2),
(3, 'Ordered at 3pm', 4, 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `orders_view`
--
CREATE TABLE `orders_view` (
`Order_id` int(4)
,`Order_details` varchar(30)
,`product_id` int(4)
,`Customer_id` int(4)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_id` int(3) NOT NULL,
  `Customer_id` int(3) NOT NULL,
  `product_id` int(3) NOT NULL,
  `Payment_method` varchar(20) NOT NULL,
  `Amount_paid` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_id`, `Customer_id`, `product_id`, `Payment_method`, `Amount_paid`) VALUES
(1, 1, 1, 'Bank BK', 250000),
(2, 2, 2, 'Mtn Moblie Payment', 150000);

-- --------------------------------------------------------

--
-- Stand-in structure for view `payment_view`
--
CREATE TABLE `payment_view` (
);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `Product_id` int(4) NOT NULL,
  `Product_price` int(4) NOT NULL,
  `Quantity` int(3) NOT NULL,
  `Customer_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Product_id`, `Product_price`, `Quantity`, `Customer_id`) VALUES
(1, 20000, 2, 1),
(2, 10000, 1, 2),
(3, 35000, 1, 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `products_view`
--
CREATE TABLE `products_view` (
`Product_id` int(4)
,`Product_price` int(4)
,`Quantity` int(3)
,`Customer_id` int(3)
);

-- --------------------------------------------------------

--
-- Table structure for table `rent_houses`
--

CREATE TABLE `rent_houses` (
  `House_id` int(4) NOT NULL,
  `House_address` varchar(30) NOT NULL,
  `Rent_ammount` int(4) NOT NULL,
  `Rent_details` int(30) NOT NULL,
  `Customer_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `rent_houses_view`
--
CREATE TABLE `rent_houses_view` (
);

-- --------------------------------------------------------

--
-- Structure for view `customer_view`
--
DROP TABLE IF EXISTS `customer_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_view`  AS  select `customer`.`Customer_id` AS `Customer_id`,`customer`.`Firstname` AS `Firstname`,`customer`.`Lastname` AS `Lastname`,`customer`.`Gender` AS `Gender`,`customer`.`Tel_number` AS `Tel_number`,`customer`.`Email_address` AS `Email_address`,`customer`.`Address` AS `Address` from `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `delivery_view`
--
DROP TABLE IF EXISTS `delivery_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delivery_view`  AS  select `delivery`.`Delivery_id` AS `Delivery_id`,`delivery`.`Delivery_Address` AS `Delivery_Address`,`delivery`.`Delivery_details` AS `Delivery_details`,`delivery`.`Product_id` AS `Product_id`,`delivery`.`Delivery_amount` AS `Delivery_amount`,`delivery`.`Customer_id` AS `Customer_id` from `delivery` ;

-- --------------------------------------------------------

--
-- Structure for view `employee_view`
--
DROP TABLE IF EXISTS `employee_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employee_view`  AS  select `employees`.`Employee_id` AS `Employee_id`,`employees`.`Employee_Firstname` AS `Employee_Firstname`,`employees`.`Employee_Lastname` AS `Employee_Lastname`,`employees`.`Empoyee_Tel` AS `Empoyee_Tel`,`employees`.`Employee_Address` AS `Employee_Address`,`employees`.`Employee_Emailaddress` AS `Employee_Emailaddress` from `employees` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_customer`
--
DROP TABLE IF EXISTS `insert_data_into_customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_customer`  AS  select `customer`.`Customer_id` AS `Customer_id`,`customer`.`Firstname` AS `Firstname`,`customer`.`Lastname` AS `Lastname`,`customer`.`Gender` AS `Gender`,`customer`.`Tel_number` AS `Tel_number`,`customer`.`Email_address` AS `Email_address`,`customer`.`Address` AS `Address` from `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_delivery`
--
DROP TABLE IF EXISTS `insert_data_into_delivery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_delivery`  AS  select `delivery`.`Delivery_id` AS `Delivery_id`,`delivery`.`Delivery_Address` AS `Delivery_Address`,`delivery`.`Delivery_details` AS `Delivery_details`,`delivery`.`Product_id` AS `Product_id`,`delivery`.`Delivery_amount` AS `Delivery_amount`,`delivery`.`Customer_id` AS `Customer_id` from `delivery` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_employees`
--
DROP TABLE IF EXISTS `insert_data_into_employees`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_employees`  AS  select `employees`.`Employee_id` AS `Employee_id`,`employees`.`Employee_Firstname` AS `Employee_Firstname`,`employees`.`Employee_Lastname` AS `Employee_Lastname`,`employees`.`Empoyee_Tel` AS `Empoyee_Tel`,`employees`.`Employee_Address` AS `Employee_Address`,`employees`.`Employee_Emailaddress` AS `Employee_Emailaddress` from `employees` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_orders`
--
DROP TABLE IF EXISTS `insert_data_into_orders`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_orders`  AS  select `orders`.`Order_id` AS `Order_id`,`orders`.`Order_details` AS `Order_details`,`orders`.`product_id` AS `product_id`,`orders`.`Customer_id` AS `Customer_id` from `orders` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_payments`
--
DROP TABLE IF EXISTS `insert_data_into_payments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_payments`  AS  select `payment`.`Payment_id` AS `Payment_id`,`payment`.`Customer_id` AS `Customer_id`,`payment`.`product_id` AS `product_id`,`payment`.`Paymen_method` AS `Paymen_method`,`payment`.`Amount_paid` AS `Amount_paid` from `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_products`
--
DROP TABLE IF EXISTS `insert_data_into_products`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_products`  AS  select `products`.`Product_id` AS `Product_id`,`products`.`Product_price` AS `Product_price`,`products`.`Quantity` AS `Quantity`,`products`.`Customer_id` AS `Customer_id` from `products` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_rent_houses`
--
DROP TABLE IF EXISTS `insert_data_into_rent_houses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_rent_houses`  AS  select `rent_houses`.`House_id` AS `House_id`,`rent_houses`.`Hous_addrss` AS `Hous_addrss`,`rent_houses`.`Rent_ammount` AS `Rent_ammount`,`rent_houses`.`Rent_details` AS `Rent_details`,`rent_houses`.`Customer_id` AS `Customer_id` from `rent_houses` ;

-- --------------------------------------------------------

--
-- Structure for view `orders_view`
--
DROP TABLE IF EXISTS `orders_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `orders_view`  AS  select `orders`.`Order_id` AS `Order_id`,`orders`.`Order_details` AS `Order_details`,`orders`.`product_id` AS `product_id`,`orders`.`Customer_id` AS `Customer_id` from `orders` ;

-- --------------------------------------------------------

--
-- Structure for view `payment_view`
--
DROP TABLE IF EXISTS `payment_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payment_view`  AS  select `payment`.`Payment_id` AS `Payment_id`,`payment`.`Customer_id` AS `Customer_id`,`payment`.`product_id` AS `product_id`,`payment`.`Paymen_method` AS `Paymen_method`,`payment`.`Amount_paid` AS `Amount_paid` from `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `products_view`
--
DROP TABLE IF EXISTS `products_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `products_view`  AS  select `products`.`Product_id` AS `Product_id`,`products`.`Product_price` AS `Product_price`,`products`.`Quantity` AS `Quantity`,`products`.`Customer_id` AS `Customer_id` from `products` ;

-- --------------------------------------------------------

--
-- Structure for view `rent_houses_view`
--
DROP TABLE IF EXISTS `rent_houses_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rent_houses_view`  AS  select `rent_houses`.`House_id` AS `House_id`,`rent_houses`.`Hous_addrss` AS `Hous_addrss`,`rent_houses`.`Rent_ammount` AS `Rent_ammount`,`rent_houses`.`Rent_details` AS `Rent_details`,`rent_houses`.`Customer_id` AS `Customer_id` from `rent_houses` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`),
  ADD KEY `Customer_id` (`Customer_id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`Delivery_id`),
  ADD UNIQUE KEY `Product_id` (`Product_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Employee_id`),
  ADD UNIQUE KEY `Employee_id` (`Employee_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_id`),
  ADD UNIQUE KEY `FOREIGN` (`product_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_id`),
  ADD UNIQUE KEY `Customer_id` (`Customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`Product_id`),
  ADD UNIQUE KEY `FOREIGN` (`Customer_id`);

--
-- Indexes for table `rent_houses`
--
ALTER TABLE `rent_houses`
  ADD PRIMARY KEY (`House_id`),
  ADD UNIQUE KEY `FOREIGN` (`Customer_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`Customer_id`) REFERENCES `employees` (`Employee_id`);

--
-- Constraints for table `delivery`
--
ALTER TABLE `delivery`
  ADD CONSTRAINT `delivery_ibfk_1` FOREIGN KEY (`Delivery_id`) REFERENCES `products` (`Product_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Payment_id`) REFERENCES `products` (`Product_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`Product_id`) REFERENCES `orders` (`Order_id`);

--
-- Constraints for table `rent_houses`
--
ALTER TABLE `rent_houses`
  ADD CONSTRAINT `rent_houses_ibfk_1` FOREIGN KEY (`House_id`) REFERENCES `customer` (`Customer_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
