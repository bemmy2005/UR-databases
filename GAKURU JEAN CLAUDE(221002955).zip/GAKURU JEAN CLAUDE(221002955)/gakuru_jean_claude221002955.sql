-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 02:13 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gakuru_jean_claude221002955`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCarsDetails` ()  BEGIN
    create VIEW viewwithsubquery as (SELECT bfname,blname,bgender,bbirthdate,bfather,bmother,vdate from vaccines join registration on vaccines.vid=registration.vid join baby on baby.bid=registration.bid where vdate=(SELECT vdate from vaccines where vdate BETWEEN '2022-05-05' and '2022-10-12'));
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listofbaby` ()  BEGIN
    DELETE FROM `listofbaby` WHERE `listofbaby`.`bid` = 16;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listofhospitals` ()  BEGIN
   UPDATE `listofhospitals` SET `hsector` = 'gahinihhhhhh' WHERE `listofhospitals`.`Hid` = 7;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listofnurses` ()  BEGIN
    select * from nurses;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listofregistration` ()  BEGIN
    select * from registration;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listofvaccines` ()  BEGIN
    select * from vaccines;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `baby`
--

CREATE TABLE `baby` (
  `bid` int(5) NOT NULL,
  `bfname` varchar(10) NOT NULL,
  `blname` varchar(10) NOT NULL,
  `bgender` varchar(1) NOT NULL,
  `bbirthdate` date NOT NULL,
  `bfather` varchar(15) NOT NULL,
  `bmother` varchar(15) NOT NULL,
  `ptelephone` int(10) NOT NULL,
  `bcountry` varchar(10) NOT NULL,
  `bprovince` varchar(12) NOT NULL,
  `bdistrict` varchar(10) NOT NULL,
  `bsecctor` varchar(13) NOT NULL,
  `bcell` varchar(12) NOT NULL,
  `bvillage` varchar(13) NOT NULL,
  `bYears_months` varchar(10) NOT NULL,
  `nid FK` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `baby`
--

INSERT INTO `baby` (`bid`, `bfname`, `blname`, `bgender`, `bbirthdate`, `bfather`, `bmother`, `ptelephone`, `bcountry`, `bprovince`, `bdistrict`, `bsecctor`, `bcell`, `bvillage`, `bYears_months`, `nid FK`) VALUES
(10, 'umurerwa', 'gracee', 'f', '2021-12-01', 'sengabo jean', 'giraneza marry', 780012895, 'rwanda', 'west', 'karongi', 'rugabano', 'mukimba', 'kamonyi', '7months', 1),
(11, 'gagag', 'claude', 'm', '2020-07-22', 'nsabimana emman', 'mutuyimana bett', 781076338, 'rwanda', 'east', 'rwamagana', 'muhazi', 'murambi', 'ndego', '2year', 8),
(13, 'keza', 'gakuba', 'f', '2015-12-01', 'kjhgfd', 'tftyugukhjkl', 784678567, 'rwanda', 'north', 'gisagara', 'kibilizi', 'mbazi', 'ruriba', '7yers', 2),
(14, 'umurerwa', 'gracee', 'f', '2021-12-01', 'sengabo jean', 'giraneza marry', 780012895, 'rwanda', 'west', 'karongi', 'rugabano', 'mukimba', 'kamonyi', '7months', 1),
(15, 'ngabo', 'claude', 'm', '2020-07-22', 'nsabimana emman', 'mutuyimana bett', 781076338, 'rwanda', 'east', 'rwamagana', 'muhazi', 'murambi', 'ndego', '2year', 8),
(17, 'keza', 'juliette', 'f', '2015-12-01', 'mukiza', 'clever', 784678567, 'rwanda', 'north', 'gisagara', 'kibilizi', 'mbazi', 'ruriba', '7yers', 2),
(20, 'gakuru', 'john', 'm', '2022-07-07', 'sengabo jean', 'giraneza marry', 780012895, 'rwanda', 'west', 'karongi', 'rugabano', 'mukimba', 'kamonyi', 'one year', 8);

--
-- Triggers `baby`
--
DELIMITER $$
CREATE TRIGGER `Deletebaby` AFTER INSERT ON `baby` FOR EACH ROW BEGIN  
DELETE FROM `baby` WHERE `baby`.`bid` = 16;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateAlert` AFTER INSERT ON `baby` FOR EACH ROW BEGIN  
UPDATE `baby` SET `blname` = 'gakuba', `bfather` = 'kjhgfd', `bmother` = 'tftyugukhjkl' WHERE `listofbaby`.`bid` = 13;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertAlert` AFTER INSERT ON `baby` FOR EACH ROW BEGIN  
INSERT INTO `baby` (`bid`, `bfname`, `blname`, `bgender`, `bbirthdate`, `bfather`, `bmother`, `ptelephone`, `bcountry`, `bprovince`, `bdistrict`, `bsecctor`, `bcell`, `bvillage`, `bYears_months`) VALUES (NULL, 'umurerwa', 'gracee', 'f', '2021-12-01', 'sengabo jean', 'giraneza marry', '0780012895', 'rwanda', 'west', 'karongi', 'rugabano', 'mukimba', 'kamonyi', '7months'); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `hospitals`
--

CREATE TABLE `hospitals` (
  `Hid` int(5) NOT NULL,
  `Hname` varchar(10) NOT NULL,
  `Hemail` varchar(15) NOT NULL,
  `htelephone` int(10) NOT NULL,
  `Hprovince` varchar(10) NOT NULL,
  `hdistrict` varchar(15) NOT NULL,
  `hsector` varchar(10) NOT NULL,
  `hcell` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitals`
--

INSERT INTO `hospitals` (`Hid`, `Hname`, `Hemail`, `htelephone`, `Hprovince`, `hdistrict`, `hsector`, `hcell`) VALUES
(1, 'kibuye', 'kibuye@gmail.co', 556600, 'west', 'karongi', 'bwishyura', 'bwishyura'),
(2, 'kirinda', 'kirinda ', 700800, 'wet', 'karongi', 'rwankuba', 'mbazi'),
(3, 'gahini', 'gahini@gmail.co', 785678340, 'east', 'kayonza', 'gahini', 'ndaro'),
(4, 'chub', 'chb@gmail.com', 8955656, 'north', 'huye', 'mamba', 'mamba'),
(5, 'kibuye', 'kibuye@gmail.co', 556600, 'west', 'karongi', 'bwishyura', 'bwishyura'),
(6, 'kirinda', 'kirinda ', 700800, 'wet', 'karongi', 'rwankuba', 'mbazi'),
(7, 'gahini', 'gahini@gmail.co', 785678340, 'east', 'kayonza', 'gahinihhhh', 'ndaro'),
(8, 'chub', 'chb@gmail.com', 8955656, 'north', 'huye', 'mamba', 'mamba');

--
-- Triggers `hospitals`
--
DELIMITER $$
CREATE TRIGGER `DeleteAlert` AFTER INSERT ON `hospitals` FOR EACH ROW BEGIN  
DELETE FROM `hospitals` WHERE `hospitals`.`Hid` = 10; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateAlerthospitals` AFTER INSERT ON `hospitals` FOR EACH ROW BEGIN  
UPDATE `hospitals` SET `hsector` = 'gahinihhhhhh' WHERE `hospitals`.`Hid` = 7; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertview`
-- (See below for the actual view)
--
CREATE TABLE `insertview` (
`bfname` varchar(10)
,`blname` varchar(10)
,`bgender` varchar(1)
,`bbirthdate` date
,`bfather` varchar(15)
,`bmother` varchar(15)
,`ptelephone` int(10)
,`bcountry` varchar(10)
,`bprovince` varchar(12)
,`bdistrict` varchar(10)
,`bsecctor` varchar(13)
,`bcell` varchar(12)
,`bvillage` varchar(13)
,`bYears_months` varchar(10)
,`nfname` varchar(10)
,`nlname` varchar(10)
,`npost` varchar(11)
,`ntelephone` int(10)
,`nemail` varchar(15)
,`vname` varchar(10)
,`vdate` date
,`vorder` varchar(25)
,`vrange` varchar(20)
,`comments` varchar(30)
,`quantity` int(11)
,`Hname` varchar(10)
,`Hemail` varchar(15)
,`htelephone` int(10)
,`Hprovince` varchar(10)
,`hdistrict` varchar(15)
,`hsector` varchar(10)
,`hcell` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofbaby`
-- (See below for the actual view)
--
CREATE TABLE `listofbaby` (
`bid` int(5)
,`bfname` varchar(10)
,`blname` varchar(10)
,`bgender` varchar(1)
,`bbirthdate` date
,`bfather` varchar(15)
,`bmother` varchar(15)
,`ptelephone` int(10)
,`bcountry` varchar(10)
,`bprovince` varchar(12)
,`bdistrict` varchar(10)
,`bsecctor` varchar(13)
,`bcell` varchar(12)
,`bvillage` varchar(13)
,`bYears_months` varchar(10)
,`nid FK` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofhospitals`
-- (See below for the actual view)
--
CREATE TABLE `listofhospitals` (
`Hid` int(5)
,`Hname` varchar(10)
,`Hemail` varchar(15)
,`htelephone` int(10)
,`Hprovince` varchar(10)
,`hdistrict` varchar(15)
,`hsector` varchar(10)
,`hcell` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofnurses`
-- (See below for the actual view)
--
CREATE TABLE `listofnurses` (
`nid` int(5)
,`nfname` varchar(10)
,`nlname` varchar(10)
,`npost` varchar(11)
,`ntelephone` int(10)
,`nemail` varchar(15)
,`ndistrict` varchar(10)
,`nsector` varchar(10)
,`ncell` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofregistration`
-- (See below for the actual view)
--
CREATE TABLE `listofregistration` (
`rid` int(5)
,`bid` int(5)
,`vid` int(5)
,`hid` int(5)
,`rdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofvaccines`
-- (See below for the actual view)
--
CREATE TABLE `listofvaccines` (
);

-- --------------------------------------------------------

--
-- Table structure for table `nurses`
--

CREATE TABLE `nurses` (
  `nid` int(5) NOT NULL,
  `nfname` varchar(10) NOT NULL,
  `nlname` varchar(10) NOT NULL,
  `npost` varchar(11) NOT NULL,
  `ntelephone` int(10) NOT NULL,
  `nemail` varchar(15) NOT NULL,
  `ndistrict` varchar(10) NOT NULL,
  `nsector` varchar(10) NOT NULL,
  `ncell` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nurses`
--

INSERT INTO `nurses` (`nid`, `nfname`, `nlname`, `npost`, `ntelephone`, `nemail`, `ndistrict`, `nsector`, `ncell`) VALUES
(1, 'byiringiro', 'pacifique', 'health care', 725678908, 'byiringiropacy@', 'nyabihu', 'rugera', 'mata'),
(2, 'ishimwe', 'crema', 'health care', 732538790, 'cremanceishi@gm', 'karongi', 'rubengera', 'mataba'),
(3, 'luka', 'moses', 'health care', 790098756, 'mosesluka@gmail', 'rwamagana', 'ndizi', 'ruba'),
(4, 'ineza', 'grace', 'health care', 798098654, 'graceine@gmail.', 'kayonza', 'mukarange', 'mukimba'),
(5, 'byiringiro', 'pacifique', 'health care', 725678908, 'byiringiropacy@', 'nyabihu', 'rugera', 'mata'),
(6, 'ishimwe', 'crema', 'health care', 732538790, 'cremanceishi@gm', 'karongi', 'rubengera', 'mataba'),
(7, 'luka', 'moses', 'health care', 790098756, 'mosesluka@gmail', 'rwamagana', 'ndizi', 'ruba'),
(8, 'ineza', 'grace', 'health care', 798098654, 'graceine@gmail.', 'kayonza', 'mukarange', 'mukimba'),
(9, 'ishimwe', 'elyse', 'nursing', 782765467, 'ishimweely@gmai', 'karongi', 'rugabano', 'mbogo'),
(10, 'umuhoza', 'del', 'health care', 789879461, 'umuhozade@gmail', 'nyagatare', 'ndego', 'gateare');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `rid` int(5) NOT NULL,
  `bid` int(5) NOT NULL,
  `vid` int(5) NOT NULL,
  `hid` int(5) NOT NULL,
  `rdate` date NOT NULL,
  `nid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`rid`, `bid`, `vid`, `hid`, `rdate`, `nid`) VALUES
(1, 11, 2, 1, '2022-07-12', 0),
(2, 17, 1, 6, '2022-04-12', 0),
(3, 14, 2, 7, '2020-11-10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vaccines`
--

CREATE TABLE `vaccines` (
  `vid` int(5) NOT NULL,
  `vname` varchar(10) NOT NULL,
  `vdate` date NOT NULL,
  `vorder` varchar(25) NOT NULL,
  `vrange` varchar(20) NOT NULL,
  `comments` varchar(30) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vaccines`
--

INSERT INTO `vaccines` (`vid`, `vname`, `vdate`, `vorder`, `vrange`, `comments`, `quantity`) VALUES
(1, 'Hepatitis ', '2022-03-01', 'catch other dose after 3m', 'birth', ' baby takes 3 dose of hepatiti', 100),
(2, 'Rotavirus', '2019-10-01', 'first dose at 2months fro', 'from birth to two mo', 'Rotavirus (RV) RV1(2_dose) fir', 300),
(3, 'Tetanus', '2022-07-01', '1dose to 2month,2dose to ', 'during 2month to 6mo', 'tetanus contains 4dose taken i', 400),
(4, 'influenza(', '2022-07-22', 'annual vaccination 1 or 2', 'taken to 6month', 'annual vaccination can take 1d', 90),
(5, 'Hepatitis ', '2022-04-14', 'catch other dose after 3m', 'from birth ', ' baby takes 3 dose of hepatiti', 100),
(6, 'Rotavirus', '2019-10-01', 'first dose at 2months fro', 'from birth to two mo', 'Rotavirus (RV) RV1(2_dose) fir', 350),
(7, 'Hepatitis ', '2022-07-13', 'catch other dose after 3m', 'from birth ', ' baby takes 3 dose of hepatiti', 100);

--
-- Triggers `vaccines`
--
DELIMITER $$
CREATE TRIGGER `insertAlertVaccines` AFTER INSERT ON `vaccines` FOR EACH ROW BEGIN  
INSERT INTO `vaccines` (`vid`, `vname`, `vdate`, `vorder`, `vrange`, `comments`, `quantity`, `bid`) VALUES (NULL, 'Hepatitis B', '2022-03-01', 'catch other dose after 3months', 'birth', ' baby takes 3 dose of hepatitis b from birth to 15months', '100', ''); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewwithsubquery`
-- (See below for the actual view)
--
CREATE TABLE `viewwithsubquery` (
`bfname` varchar(10)
,`blname` varchar(10)
,`bgender` varchar(1)
,`bbirthdate` date
,`bfather` varchar(15)
,`bmother` varchar(15)
,`vdate` date
);

-- --------------------------------------------------------

--
-- Structure for view `insertview`
--
DROP TABLE IF EXISTS `insertview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertview`  AS  (select `baby`.`bfname` AS `bfname`,`baby`.`blname` AS `blname`,`baby`.`bgender` AS `bgender`,`baby`.`bbirthdate` AS `bbirthdate`,`baby`.`bfather` AS `bfather`,`baby`.`bmother` AS `bmother`,`baby`.`ptelephone` AS `ptelephone`,`baby`.`bcountry` AS `bcountry`,`baby`.`bprovince` AS `bprovince`,`baby`.`bdistrict` AS `bdistrict`,`baby`.`bsecctor` AS `bsecctor`,`baby`.`bcell` AS `bcell`,`baby`.`bvillage` AS `bvillage`,`baby`.`bYears_months` AS `bYears_months`,`nurses`.`nfname` AS `nfname`,`nurses`.`nlname` AS `nlname`,`nurses`.`npost` AS `npost`,`nurses`.`ntelephone` AS `ntelephone`,`nurses`.`nemail` AS `nemail`,`vaccines`.`vname` AS `vname`,`vaccines`.`vdate` AS `vdate`,`vaccines`.`vorder` AS `vorder`,`vaccines`.`vrange` AS `vrange`,`vaccines`.`comments` AS `comments`,`vaccines`.`quantity` AS `quantity`,`hospitals`.`Hname` AS `Hname`,`hospitals`.`Hemail` AS `Hemail`,`hospitals`.`htelephone` AS `htelephone`,`hospitals`.`Hprovince` AS `Hprovince`,`hospitals`.`hdistrict` AS `hdistrict`,`hospitals`.`hsector` AS `hsector`,`hospitals`.`hcell` AS `hcell` from ((((`baby` join `registration` on(`baby`.`bid` = `registration`.`bid`)) join `vaccines` on(`vaccines`.`vid` = `registration`.`vid`)) join `hospitals` on(`hospitals`.`Hid` = `registration`.`vid`)) join `nurses` on(`nurses`.`nid` = `registration`.`nid`))) ;

-- --------------------------------------------------------

--
-- Structure for view `listofbaby`
--
DROP TABLE IF EXISTS `listofbaby`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofbaby`  AS  (select `baby`.`bid` AS `bid`,`baby`.`bfname` AS `bfname`,`baby`.`blname` AS `blname`,`baby`.`bgender` AS `bgender`,`baby`.`bbirthdate` AS `bbirthdate`,`baby`.`bfather` AS `bfather`,`baby`.`bmother` AS `bmother`,`baby`.`ptelephone` AS `ptelephone`,`baby`.`bcountry` AS `bcountry`,`baby`.`bprovince` AS `bprovince`,`baby`.`bdistrict` AS `bdistrict`,`baby`.`bsecctor` AS `bsecctor`,`baby`.`bcell` AS `bcell`,`baby`.`bvillage` AS `bvillage`,`baby`.`bYears_months` AS `bYears_months`,`baby`.`nid FK` AS `nid FK` from `baby`) ;

-- --------------------------------------------------------

--
-- Structure for view `listofhospitals`
--
DROP TABLE IF EXISTS `listofhospitals`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofhospitals`  AS  (select `hospitals`.`Hid` AS `Hid`,`hospitals`.`Hname` AS `Hname`,`hospitals`.`Hemail` AS `Hemail`,`hospitals`.`htelephone` AS `htelephone`,`hospitals`.`Hprovince` AS `Hprovince`,`hospitals`.`hdistrict` AS `hdistrict`,`hospitals`.`hsector` AS `hsector`,`hospitals`.`hcell` AS `hcell` from `hospitals`) ;

-- --------------------------------------------------------

--
-- Structure for view `listofnurses`
--
DROP TABLE IF EXISTS `listofnurses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofnurses`  AS  (select `nurses`.`nid` AS `nid`,`nurses`.`nfname` AS `nfname`,`nurses`.`nlname` AS `nlname`,`nurses`.`npost` AS `npost`,`nurses`.`ntelephone` AS `ntelephone`,`nurses`.`nemail` AS `nemail`,`nurses`.`ndistrict` AS `ndistrict`,`nurses`.`nsector` AS `nsector`,`nurses`.`ncell` AS `ncell` from `nurses`) ;

-- --------------------------------------------------------

--
-- Structure for view `listofregistration`
--
DROP TABLE IF EXISTS `listofregistration`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofregistration`  AS  (select `registration`.`rid` AS `rid`,`registration`.`bid` AS `bid`,`registration`.`vid` AS `vid`,`registration`.`hid` AS `hid`,`registration`.`rdate` AS `rdate` from `registration`) ;

-- --------------------------------------------------------

--
-- Structure for view `listofvaccines`
--
DROP TABLE IF EXISTS `listofvaccines`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofvaccines`  AS  (select `vaccines`.`vid` AS `vid`,`vaccines`.`vname` AS `vname`,`vaccines`.`vdate` AS `vdate`,`vaccines`.`vorder` AS `vorder`,`vaccines`.`vrange` AS `vrange`,`vaccines`.`comments` AS `comments`,`vaccines`.`quantity` AS `quantity`,`vaccines`.`bid` AS `bid` from `vaccines`) ;

-- --------------------------------------------------------

--
-- Structure for view `viewwithsubquery`
--
DROP TABLE IF EXISTS `viewwithsubquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewwithsubquery`  AS  (select `baby`.`bfname` AS `bfname`,`baby`.`blname` AS `blname`,`baby`.`bgender` AS `bgender`,`baby`.`bbirthdate` AS `bbirthdate`,`baby`.`bfather` AS `bfather`,`baby`.`bmother` AS `bmother`,`vaccines`.`vdate` AS `vdate` from ((`vaccines` join `registration` on(`vaccines`.`vid` = `registration`.`vid`)) join `baby` on(`baby`.`bid` = `registration`.`bid`)) where `vaccines`.`vdate` = (select `vaccines`.`vdate` from `vaccines` where `vaccines`.`vdate` between '2022-05-05' and '2022-10-12')) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `baby`
--
ALTER TABLE `baby`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `nid FK` (`nid FK`);

--
-- Indexes for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`Hid`);

--
-- Indexes for table `nurses`
--
ALTER TABLE `nurses`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `bid` (`bid`),
  ADD KEY `vid` (`vid`),
  ADD KEY `hid` (`hid`);

--
-- Indexes for table `vaccines`
--
ALTER TABLE `vaccines`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `baby`
--
ALTER TABLE `baby`
  MODIFY `bid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `hospitals`
--
ALTER TABLE `hospitals`
  MODIFY `Hid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `nurses`
--
ALTER TABLE `nurses`
  MODIFY `nid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `rid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vaccines`
--
ALTER TABLE `vaccines`
  MODIFY `vid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `baby`
--
ALTER TABLE `baby`
  ADD CONSTRAINT `baby_ibfk_1` FOREIGN KEY (`nid FK`) REFERENCES `nurses` (`nid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `baby` (`bid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `registration_ibfk_2` FOREIGN KEY (`hid`) REFERENCES `hospitals` (`Hid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `registration_ibfk_3` FOREIGN KEY (`vid`) REFERENCES `vaccines` (`vid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
