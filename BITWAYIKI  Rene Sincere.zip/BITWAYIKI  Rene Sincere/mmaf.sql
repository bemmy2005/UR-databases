-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2022 at 03:31 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mmaf`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_farmer` (IN `FarmerID` INT(5))  BEGIN
DELETE FROM farmer WHERE farmer.FarmerID=FarmerID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_user` (IN `UserID` INT(5))  BEGIN
DELETE FROM login WHERE login.UserID=UserID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_approve` (IN `Appr_ID` INT(5), `Crop_Name` VARCHAR(30), `CropID` INT(5), `Date` DATE)  BEGIN
INSERT INTO approve VALUES(Appr_ID,Crop_Name,CropID, Date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_crop` (IN `CropID` INT(5), `Crop_Name` VARCHAR(30), `Description` VARCHAR(70), `Quantity` INT(10), `FarmerID` INT(5))  BEGIN
INSERT INTO crop VALUES( CropID,Crop_Name,Description,Quantity	, FarmerID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_farmer` (IN `FarmerID` INT(5), `Names` VARCHAR(30), `Phone` INT(10), `NID` INT(16), `Location` VARCHAR(30))  BEGIN
INSERT INTO farmer VALUES( FarmerID, Names, Phone,NID,Location);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_login` (IN `UserID` INT(5), `Username` VARCHAR(20), `Password` VARCHAR(20))  BEGIN
INSERT INTO login VALUES( UserID ,Username , Password);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_reject` (IN `Rej_ID` INT(5), `Crop_Name` VARCHAR(30), `CropID` INT(5), `Cause` VARCHAR(70))  BEGIN
INSERT INTO reject VALUES(Rej_ID,Crop_Name,CropID, Cause);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `select_approve` ()  BEGIN
SELECT * FROM `approve`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `select_crops` ()  BEGIN
SELECT * FROM `crop`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `select_farmers` ()  BEGIN
SELECT * FROM `farmer`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `select_reject` ()  BEGIN
SELECT * FROM `reject`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `select_users` ()  BEGIN
SELECT * FROM `login`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_farmer` (IN `FarmerID` INT(5), `Phones` INT(10))  BEGIN
UPDATE `farmer` SET `Phone` = Phones WHERE `farmer`.`FarmerID` = FarmerID ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user` (IN `UserID` INT(5), `Pass` VARCHAR(20))  BEGIN
UPDATE `login` SET `Password` = Pass WHERE `login`.`UserID` = UserID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `approve`
--

CREATE TABLE `approve` (
  `Appr_ID` int(5) NOT NULL,
  `Crop_Name` varchar(30) NOT NULL,
  `CropID` int(5) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `UserID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approve`
--

INSERT INTO `approve` (`Appr_ID`, `Crop_Name`, `CropID`, `Date`, `UserID`) VALUES
(1, 'Coffee', 2, '2022-07-20', NULL),
(2, 'Beins', 3, '2022-07-21', NULL),
(3, 'soya', 4, '2022-07-27', NULL);

--
-- Triggers `approve`
--
DELIMITER $$
CREATE TRIGGER `after_delete_approve` AFTER DELETE ON `approve` FOR EACH ROW BEGIN
DELETE FROM crop WHERE old.CropID=crop.CropID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `crop`
--

CREATE TABLE `crop` (
  `CropID` int(5) NOT NULL,
  `Crop_Name` varchar(30) NOT NULL,
  `Description` varchar(70) DEFAULT NULL,
  `Quantity` int(10) DEFAULT NULL,
  `FarmerID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crop`
--

INSERT INTO `crop` (`CropID`, `Crop_Name`, `Description`, `Quantity`, `FarmerID`) VALUES
(1, 'Maize', 'Ibride', 60, 1),
(2, 'Coffee', 'Black Coffee', 200, 2),
(3, 'Beins', 'tubura', 1000, 3),
(4, 'soya', 'kkkk', 479, 1);

--
-- Triggers `crop`
--
DELIMITER $$
CREATE TRIGGER `after_insert_crop` AFTER INSERT ON `crop` FOR EACH ROW BEGIN
INSERT INTO approve VALUES('',new.Crop_Name,new.CropID,NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_crop` AFTER UPDATE ON `crop` FOR EACH ROW BEGIN
UPDATE approve SET approve.Crop_Name=new.Crop_Name, approve.Date=NOW() WHERE approve.CropID=old.CropID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `FarmerID` int(5) NOT NULL,
  `Names` varchar(30) NOT NULL,
  `Phone` int(10) DEFAULT NULL,
  `NID` int(16) DEFAULT NULL,
  `Location` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`FarmerID`, `Names`, `Phone`, `NID`, `Location`) VALUES
(1, 'Gaspar', 788922334, 1970802234, 'Huye'),
(2, 'Rose', 781239094, 1908321374, 'Huye'),
(3, 'Jimmy', 788812320, 1972342218, 'Huye');

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_approved`
-- (See below for the actual view)
--
CREATE TABLE `list_of_approved` (
`Appr_ID` int(5)
,`Crop_Name` varchar(30)
,`CropID` int(5)
,`Date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_crops`
-- (See below for the actual view)
--
CREATE TABLE `list_of_crops` (
`CropID` int(5)
,`Crop_Name` varchar(30)
,`Description` varchar(70)
,`Quantity` int(10)
,`FarmerID` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_farmers`
-- (See below for the actual view)
--
CREATE TABLE `list_of_farmers` (
`FarmerID` int(5)
,`Names` varchar(30)
,`Phone` int(10)
,`NID` int(16)
,`Location` varchar(30)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_rejected`
-- (See below for the actual view)
--
CREATE TABLE `list_of_rejected` (
`Rej_ID` int(5)
,`Crop_Name` varchar(30)
,`CropID` int(5)
,`Cause` varchar(70)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_user`
-- (See below for the actual view)
--
CREATE TABLE `list_of_user` (
`UserID` int(5)
,`Username` varchar(20)
,`Password` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `UserID` int(5) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`UserID`, `Username`, `Password`) VALUES
(2, 'Rene', 'rene@1'),
(3, 'Adam', 'adam#178');

-- --------------------------------------------------------

--
-- Table structure for table `reject`
--

CREATE TABLE `reject` (
  `Rej_ID` int(5) NOT NULL,
  `Crop_Name` varchar(30) NOT NULL,
  `CropID` int(5) DEFAULT NULL,
  `Cause` varchar(70) DEFAULT NULL,
  `UserID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure for view `list_of_approved`
--
DROP TABLE IF EXISTS `list_of_approved`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_approved`  AS SELECT `approve`.`Appr_ID` AS `Appr_ID`, `approve`.`Crop_Name` AS `Crop_Name`, `approve`.`CropID` AS `CropID`, `approve`.`Date` AS `Date` FROM `approve` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_crops`
--
DROP TABLE IF EXISTS `list_of_crops`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_crops`  AS SELECT `crop`.`CropID` AS `CropID`, `crop`.`Crop_Name` AS `Crop_Name`, `crop`.`Description` AS `Description`, `crop`.`Quantity` AS `Quantity`, `crop`.`FarmerID` AS `FarmerID` FROM `crop` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_farmers`
--
DROP TABLE IF EXISTS `list_of_farmers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_farmers`  AS SELECT `farmer`.`FarmerID` AS `FarmerID`, `farmer`.`Names` AS `Names`, `farmer`.`Phone` AS `Phone`, `farmer`.`NID` AS `NID`, `farmer`.`Location` AS `Location` FROM `farmer` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_rejected`
--
DROP TABLE IF EXISTS `list_of_rejected`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_rejected`  AS SELECT `reject`.`Rej_ID` AS `Rej_ID`, `reject`.`Crop_Name` AS `Crop_Name`, `reject`.`CropID` AS `CropID`, `reject`.`Cause` AS `Cause` FROM `reject` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_user`
--
DROP TABLE IF EXISTS `list_of_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_user`  AS SELECT `login`.`UserID` AS `UserID`, `login`.`Username` AS `Username`, `login`.`Password` AS `Password` FROM `login` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approve`
--
ALTER TABLE `approve`
  ADD PRIMARY KEY (`Appr_ID`),
  ADD KEY `CropID` (`CropID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `crop`
--
ALTER TABLE `crop`
  ADD PRIMARY KEY (`CropID`),
  ADD KEY `FarmerID` (`FarmerID`);

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`FarmerID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `reject`
--
ALTER TABLE `reject`
  ADD PRIMARY KEY (`Rej_ID`),
  ADD KEY `CropID` (`CropID`),
  ADD KEY `UserID` (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approve`
--
ALTER TABLE `approve`
  MODIFY `Appr_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `crop`
--
ALTER TABLE `crop`
  MODIFY `CropID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `farmer`
--
ALTER TABLE `farmer`
  MODIFY `FarmerID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `UserID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reject`
--
ALTER TABLE `reject`
  MODIFY `Rej_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approve`
--
ALTER TABLE `approve`
  ADD CONSTRAINT `approve_ibfk_1` FOREIGN KEY (`CropID`) REFERENCES `crop` (`CropID`),
  ADD CONSTRAINT `approve_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `login` (`UserID`);

--
-- Constraints for table `crop`
--
ALTER TABLE `crop`
  ADD CONSTRAINT `crop_ibfk_1` FOREIGN KEY (`FarmerID`) REFERENCES `farmer` (`FarmerID`);

--
-- Constraints for table `reject`
--
ALTER TABLE `reject`
  ADD CONSTRAINT `reject_ibfk_1` FOREIGN KEY (`CropID`) REFERENCES `crop` (`CropID`),
  ADD CONSTRAINT `reject_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `login` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
