-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 27, 2022 at 02:04 PM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `GatesiKevine`
--

-- --------------------------------------------------------

--
-- Table structure for table `Bus`
--

CREATE TABLE `Bus` (
  `Bid` int(11) NOT NULL,
  `Model` varchar(100) NOT NULL,
  `Plate` varchar(100) NOT NULL,
  `Sit_Number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Bus`
--

INSERT INTO `Bus` (`Bid`, `Model`, `Plate`, `Sit_Number`) VALUES
(1, 'Hyundai', 'RAE 677 R', 32);

-- --------------------------------------------------------

--
-- Table structure for table `Client`
--

CREATE TABLE `Client` (
  `Cid` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Contact` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Client`
--

INSERT INTO `Client` (`Cid`, `Username`, `Age`, `Gender`, `Contact`) VALUES
(1, 'Gatesi_Kevine', 20, 'Male', '07887663672');

-- --------------------------------------------------------

--
-- Table structure for table `Company_Manager`
--

CREATE TABLE `Company_Manager` (
  `Mid` int(11) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Company_Manager`
--

INSERT INTO `Company_Manager` (`Mid`, `Fname`, `Lname`, `Email`, `Contact`) VALUES
(1, 'Gatesi', 'Kevine', 'gatesK@gmail.com', '0783933224');

-- --------------------------------------------------------

--
-- Table structure for table `Ticket`
--

CREATE TABLE `Ticket` (
  `Tid` int(11) NOT NULL,
  `Cid` int(11) NOT NULL,
  `Mid` int(11) NOT NULL,
  `Bid` int(11) NOT NULL,
  `Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Ticket`
--

INSERT INTO `Ticket` (`Tid`, `Cid`, `Mid`, `Bid`, `Amount`) VALUES
(1, 1, 1, 1, 2100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Bus`
--
ALTER TABLE `Bus`
  ADD PRIMARY KEY (`Bid`);

--
-- Indexes for table `Client`
--
ALTER TABLE `Client`
  ADD PRIMARY KEY (`Cid`);

--
-- Indexes for table `Company_Manager`
--
ALTER TABLE `Company_Manager`
  ADD PRIMARY KEY (`Mid`);

--
-- Indexes for table `Ticket`
--
ALTER TABLE `Ticket`
  ADD PRIMARY KEY (`Tid`),
  ADD KEY `Cid` (`Cid`),
  ADD KEY `Mid` (`Mid`),
  ADD KEY `Bid` (`Bid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Bus`
--
ALTER TABLE `Bus`
  MODIFY `Bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Client`
--
ALTER TABLE `Client`
  MODIFY `Cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Company_Manager`
--
ALTER TABLE `Company_Manager`
  MODIFY `Mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Ticket`
--
ALTER TABLE `Ticket`
  MODIFY `Tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Ticket`
--
ALTER TABLE `Ticket`
  ADD CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`Bid`) REFERENCES `Bus` (`Bid`),
  ADD CONSTRAINT `ticket_ibfk_2` FOREIGN KEY (`Cid`) REFERENCES `Client` (`Cid`),
  ADD CONSTRAINT `ticket_ibfk_3` FOREIGN KEY (`Mid`) REFERENCES `Company_Manager` (`Mid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
