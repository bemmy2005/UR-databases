-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 06:09 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inva_mansystem`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_employees` (IN `Emp_ID` VARCHAR(5), `FName` VARCHAR(100), `LName` VARCHAR(100), `Emp_DB` DATE, `Address` VARCHAR(100), `SSN` INT(10), `Gender` VARCHAR(10))  BEGIN
DELETE FROM employees  WHERE Employee_ID=Emp_ID AND Gender="Female";
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERT_employee` (IN `emp_ID` INT(3), `FName` VARCHAR(100), `LName` VARCHAR(100), `Emp_DB` DATE, `Address` VARCHAR(50), `SSN` INT(10), `Gender` VARCHAR(8))  BEGIN
INSERT INTO employee VALUES(emp_ID,FName,LName,Emp_DB,Address,SSN,Gender);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_inventory` (IN `itemID` INT(100), `storage_number` INT(100), `Qntty` INT(15), `Date` DATE, `emp_ID` INT(10))  BEGIN
INSERT INTO inventory VALUES(itemID,storage_number, Qntty , Date , emp_ID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_orderli` (IN `orderID` INT(10), `admin_ID` INT(10), `quantity` INT(100), `price` DECIMAL(8,3), `orderdate` DATE, `Total_Price` DECIMAL(8,2))  BEGIN
INSERT INTO insert_oderli VALUES(orderID, admin_ID,quantity,price ,orderdate,Total_Price);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_store` (IN `storage_number` INT(5), `storage_location` VARCHAR(100))  BEGIN
INSERT INTO store VALUES(storage_number	,storage_location);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_users` (IN `user_id` INT(10), `Username` VARCHAR(20), `Password` TEXT)  BEGIN
INSERT INTO insert_users VALUES(user_id,Username , Password);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `the_list_of_employeeS` ()  BEGIN
SELECT * FROM employee;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `the_list_of_inventory` ()  BEGIN
SELECT * FROM inventory;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_employees` (IN `Emp_ID` VARCHAR(5), `FName` VARCHAR(100), `LName` VARCHAR(100), `Emp_DB` DATE, `Address` VARCHAR(100), `SSN` INT(10), `Gender` VARCHAR(10))  BEGIN
UPDATE employees SET Emp_DB=employee_Date_Of_Birth WHERE emp_ID=emp_ID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_ID` int(10) NOT NULL,
  `admin_SSN` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_ID`, `admin_SSN`) VALUES
(12, 100),
(23, 89),
(9, 200),
(23, 333),
(300, 90000),
(12, 3098),
(13, 777);

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `admin_ID` int(10) NOT NULL,
  `AdminUserName` varchar(100) NOT NULL,
  `AdminPassword` varchar(100) NOT NULL,
  `UpdateItem` varchar(100) NOT NULL,
  `ViewSalesDetaits` varchar(100) NOT NULL,
  `PrintReport` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`admin_ID`, `AdminUserName`, `AdminPassword`, `UpdateItem`, `ViewSalesDetaits`, `PrintReport`) VALUES
(234, 'Adam', '9987djzanz\':;', 'Rice', 'Rice + Salt', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustId` int(5) NOT NULL,
  `FName` varchar(20) DEFAULT NULL,
  `LName` varchar(20) NOT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `MartStatus` varchar(12) DEFAULT NULL,
  `PhoneNumber` varchar(15) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustId`, `FName`, `LName`, `Gender`, `MartStatus`, `PhoneNumber`, `Email`) VALUES
(9, 'Thierry', 'Bony', 'Male', 'Mariage', '+49008774', 'adrophe@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_ID` int(3) NOT NULL,
  `FName` varchar(100) NOT NULL,
  `LName` varchar(100) NOT NULL,
  `Emp_DB` date DEFAULT NULL,
  `Address` varchar(50) NOT NULL,
  `SSN` int(10) DEFAULT NULL,
  `Gender` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_ID`, `FName`, `LName`, `Emp_DB`, `Address`, `SSN`, `Gender`) VALUES
(2, 'Cruty', 'Harry', '0000-00-00', '1998-07-09', 233, ''),
(3, 'Udre', 'Mart', '2003-12-23', 'Kenya', 300, ''),
(9, 'Kelvin', 'Rame', '2002-03-13', 'Germany', 3000, ''),
(10, 'Queen', 'Loy', '0000-00-00', '1988-07-29', 3, ''),
(12, 'Luis', 'Omp', '2023-03-23', 'India', 3998, ''),
(13, 'Adam', 'Ruto', '1990-04-23', 'Quator', 34, ''),
(17, 'Adam', 'Der', '2000-07-23', 'France', 3112, ''),
(23, 'Wign', 'ASE', '2020-08-09', 'London', 23, 'MALE'),
(32, 'Rose', 'Bongo', '0000-00-00', '1994-07-07', 233, ''),
(33, 'Urty', 'Preguez', '0000-00-00', '77-12-23', 99, ''),
(44, 'Tito', 'Tonz', '0000-00-00', '2000-02-11', 2, ''),
(112, 'Nelly', 'Konte', '2000-07-23', 'Senegal', 30444, ''),
(129, 'Paul', 'Qtyles', '1999-04-23', 'Burundi', 34, ''),
(138, 'Kalim', 'Wers', '2000-07-23', 'Lithuania', 3032, ''),
(174, 'Adam', 'Alves', '2000-07-23', 'Libya', 300944, ''),
(200, 'Cruty', 'Harry', '0000-00-00', '1998-07-09', 233, ''),
(223, 'Issa', 'Wers', '1977-07-01', 'Rwanda', 1, ''),
(233, 'Amina', 'Fortnee', '2012-07-04', 'KENYA', NULL, 'MALE'),
(244, 'Cruty', 'Harry', '0000-00-00', '1998-07-09', 233, ''),
(309, 'Rope', 'Porty', '2000-07-23', 'Sudan', 32321, ''),
(333, 'Adam', 'Wers', '2000-07-23', 'France', 3344, ''),
(440, 'Cruddt', 'Eric', '0000-00-00', '2011-11-19', 213, ''),
(888, 'Cruty', 'Harry', '0000-00-00', '1998-07-09', 233, ''),
(900, 'Adam', 'Trael', '2000-07-23', 'Zambia', 3497, ''),
(990, 'Adam', 'Asta', '2000-07-23', 'France', 3987, ''),
(993, 'Mike', 'Ats', '1990-12-23', 'Ukrain', 330, ''),
(999, 'Omari', 'Kano', '0000-00-00', '2010-04-19', 90, ''),
(1290, 'Adam', 'Julias', '2000-07-23', 'Tanzania', 31344, ''),
(3287, 'WELAS', 'KAMILL', '2013-07-17', 'Kigali, KG100 st', 74783, 'Male'),
(3421, 'HENRY', 'MIKE', '2012-07-31', 'Huye, southern', 7838, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `finance`
--

CREATE TABLE `finance` (
  `Sales_ID` int(10) DEFAULT NULL,
  `Category` varchar(100) NOT NULL,
  `Duration` date DEFAULT NULL,
  `DisplayPOS` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `finance`
--

INSERT INTO `finance` (`Sales_ID`, `Category`, `Duration`, `DisplayPOS`) VALUES
(NULL, 'No 2', '2022-07-06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `itemID` int(100) DEFAULT NULL,
  `storage_number` int(100) NOT NULL,
  `Qntty` int(12) NOT NULL,
  `Date` date DEFAULT NULL,
  `emp_ID` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`itemID`, `storage_number`, `Qntty`, `Date`, `emp_ID`) VALUES
(980, 209, 20000, '2022-07-07', 138),
(777, 999, 7000000, '2022-07-21', 900),
(7, 209, 1200000, '2022-07-10', 12),
(120, 999, 24000000, '2022-07-02', 990),
(11, 21, 3000000, '2014-07-11', 999);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `itemID` int(10) NOT NULL,
  `Item_Name` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`itemID`, `Item_Name`) VALUES
(7, 'Bike'),
(11, 'Coats'),
(12, 'Cups'),
(13, 'Plates'),
(20, 'Tyres'),
(21, 'Bags'),
(43, 'SAMSANG'),
(44, 'Computer'),
(90, 'Shoe'),
(100, 'Books'),
(120, 'iPhone'),
(121, 'Batery'),
(142, 'Mat'),
(321, 'Desk'),
(348, 'Clothes'),
(421, 'Helmat'),
(701, 'Pents'),
(777, 'Cables'),
(834, 'Solar'),
(890, 'IronSheet'),
(980, 'Motor'),
(1222, 'Planes'),
(1230, 'Cars'),
(9087, 'T-shirt');

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_admin`
-- (See below for the actual view)
--
CREATE TABLE `list_of_admin` (
`admin_ID` int(10)
,`admin_SSN` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_customer`
-- (See below for the actual view)
--
CREATE TABLE `list_of_customer` (
`CustId` int(5)
,`FName` varchar(20)
,`LName` varchar(20)
,`Gender` varchar(6)
,`MartStatus` varchar(12)
,`PhoneNumber` varchar(15)
,`Email` varchar(30)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_employees`
-- (See below for the actual view)
--
CREATE TABLE `list_of_employees` (
`emp_ID` int(3)
,`FName` varchar(100)
,`LName` varchar(100)
,`Emp_DB` date
,`Address` varchar(50)
,`SSN` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_inventory`
-- (See below for the actual view)
--
CREATE TABLE `list_of_inventory` (
`itemID` int(100)
,`storage_number` int(100)
,`Qntty` int(12)
,`Date` date
,`emp_ID` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_items`
-- (See below for the actual view)
--
CREATE TABLE `list_of_items` (
`itemID` int(10)
,`Item_Name` varchar(12)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_orders`
-- (See below for the actual view)
--
CREATE TABLE `list_of_orders` (
`orderID` int(10)
,`admin_ID` int(10)
,`quantity` int(100)
,`price` decimal(8,0)
,`orderdate` date
,`Total_Price` decimal(8,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_store`
-- (See below for the actual view)
--
CREATE TABLE `list_of_store` (
`storage_number` int(100)
,`storage_location` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_users`
-- (See below for the actual view)
--
CREATE TABLE `list_of_users` (
`user_id` int(10)
,`Username` varchar(20)
,`Password` text
);

-- --------------------------------------------------------

--
-- Table structure for table `orderli`
--

CREATE TABLE `orderli` (
  `orderID` int(10) NOT NULL,
  `admin_ID` int(10) DEFAULT NULL,
  `quantity` int(100) DEFAULT NULL,
  `price` decimal(8,0) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `Total_Price` decimal(8,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderli`
--

INSERT INTO `orderli` (`orderID`, `admin_ID`, `quantity`, `price`, `orderdate`, `Total_Price`) VALUES
(1, 23, 100, '2000', '2022-07-28', '200000'),
(120, 234, 349, '2000', '2022-07-16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `P_ID` int(10) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact` int(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`P_ID`, `FirstName`, `LastName`, `Address`, `Contact`) VALUES
(12, 'Serge', 'James', 'Lithuania', 347989499),
(1234, 'Adam', 'IRADUKUNDA', 'Kigali,Rwanda', 789341211);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `RepID` int(20) NOT NULL,
  `DateViewed` date DEFAULT NULL,
  `DiplayReport` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `Sales_ID` int(10) NOT NULL,
  `Sales_Date` date DEFAULT NULL,
  `CustId` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`Sales_ID`, `Sales_Date`, `CustId`) VALUES
(233, '2022-09-11', 9);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_ID` int(12) NOT NULL,
  `Staff_Username` varchar(100) NOT NULL,
  `Staff_Password` varchar(100) NOT NULL,
  `EnterItem` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_ID`, `Staff_Username`, `Staff_Password`, `EnterItem`) VALUES
(122, 'Kelvin', 'kss340040', 'Maize');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `storage_number` int(100) NOT NULL,
  `storage_location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`storage_number`, `storage_location`) VALUES
(21, 'BURUNDI H21'),
(32, 'PAKSTAN'),
(111, 'KENYA K11'),
(209, 'ENGLAND'),
(999, 'GERMAN'),
(7443, 'ITALY'),
(7773, 'SENEGAL');

-- --------------------------------------------------------

--
-- Table structure for table `updateitems`
--

CREATE TABLE `updateitems` (
  `UpdateID` int(12) NOT NULL,
  `UpdateDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `updateitems`
--

INSERT INTO `updateitems` (`UpdateID`, `UpdateDate`) VALUES
(12, '2022-07-05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `Username` varchar(20) DEFAULT NULL,
  `Password` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `Username`, `Password`) VALUES
(1, 'Adam', '00opu'),
(23, 'ser', 'kwerit');

-- --------------------------------------------------------

--
-- Structure for view `list_of_admin`
--
DROP TABLE IF EXISTS `list_of_admin`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_admin`  AS SELECT `admin`.`admin_ID` AS `admin_ID`, `admin`.`admin_SSN` AS `admin_SSN` FROM `admin` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_customer`
--
DROP TABLE IF EXISTS `list_of_customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_customer`  AS SELECT `customer`.`CustId` AS `CustId`, `customer`.`FName` AS `FName`, `customer`.`LName` AS `LName`, `customer`.`Gender` AS `Gender`, `customer`.`MartStatus` AS `MartStatus`, `customer`.`PhoneNumber` AS `PhoneNumber`, `customer`.`Email` AS `Email` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_employees`
--
DROP TABLE IF EXISTS `list_of_employees`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_employees`  AS SELECT `employee`.`emp_ID` AS `emp_ID`, `employee`.`FName` AS `FName`, `employee`.`LName` AS `LName`, `employee`.`Emp_DB` AS `Emp_DB`, `employee`.`Address` AS `Address`, `employee`.`SSN` AS `SSN` FROM `employee` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_inventory`
--
DROP TABLE IF EXISTS `list_of_inventory`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_inventory`  AS SELECT `inventory`.`itemID` AS `itemID`, `inventory`.`storage_number` AS `storage_number`, `inventory`.`Qntty` AS `Qntty`, `inventory`.`Date` AS `Date`, `inventory`.`emp_ID` AS `emp_ID` FROM `inventory` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_items`
--
DROP TABLE IF EXISTS `list_of_items`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_items`  AS SELECT `items`.`itemID` AS `itemID`, `items`.`Item_Name` AS `Item_Name` FROM `items` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_orders`
--
DROP TABLE IF EXISTS `list_of_orders`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_orders`  AS SELECT `orderli`.`orderID` AS `orderID`, `orderli`.`admin_ID` AS `admin_ID`, `orderli`.`quantity` AS `quantity`, `orderli`.`price` AS `price`, `orderli`.`orderdate` AS `orderdate`, `orderli`.`Total_Price` AS `Total_Price` FROM `orderli` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_store`
--
DROP TABLE IF EXISTS `list_of_store`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_store`  AS SELECT `store`.`storage_number` AS `storage_number`, `store`.`storage_location` AS `storage_location` FROM `store` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_users`
--
DROP TABLE IF EXISTS `list_of_users`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_users`  AS SELECT `users`.`user_id` AS `user_id`, `users`.`Username` AS `Username`, `users`.`Password` AS `Password` FROM `users` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`admin_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustId`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_ID`);

--
-- Indexes for table `finance`
--
ALTER TABLE `finance`
  ADD KEY `Sales_ID` (`Sales_ID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD KEY `emp_ID` (`emp_ID`),
  ADD KEY `itemID` (`itemID`),
  ADD KEY `storage_number` (`storage_number`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `orderli`
--
ALTER TABLE `orderli`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`P_ID`),
  ADD UNIQUE KEY `Contact` (`Contact`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`RepID`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`Sales_ID`),
  ADD KEY `CustId` (`CustId`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_ID`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`storage_number`);

--
-- Indexes for table `updateitems`
--
ALTER TABLE `updateitems`
  ADD PRIMARY KEY (`UpdateID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `admin_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CustId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `P_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1235;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `RepID` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `Sales_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=234;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `finance`
--
ALTER TABLE `finance`
  ADD CONSTRAINT `finance_ibfk_1` FOREIGN KEY (`Sales_ID`) REFERENCES `sales` (`Sales_ID`);

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`emp_ID`) REFERENCES `employee` (`emp_ID`),
  ADD CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`itemID`) REFERENCES `items` (`itemID`),
  ADD CONSTRAINT `inventory_ibfk_3` FOREIGN KEY (`storage_number`) REFERENCES `store` (`storage_number`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`CustId`) REFERENCES `customer` (`CustId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
