-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 10:16 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletepayment` (IN `pay_idParam` INT(10), `amountparam` INT(100), `customer_idparam` INT(10), `product_idparam` INT(10), `user_idparam` INT(10), `paid_dateparam` DATE)  BEGIN
    delete from payment where pay_id=1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteproduct` (IN `product_idParam` INT(10), `productnameparam` VARCHAR(100), `product_typeparam` VARCHAR(100), `amountparam` INT(100), `date_madeparam` DATE, `date_expiredparam` DATE, `user_idparam` INT(10))  BEGIN
    delete from product where product_id=2;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcustomerByID` (IN `customer_idParam` INT(10), `firstnameparam` VARCHAR(100), `lastnameparam` VARCHAR(100), `telephonenumberparam` VARCHAR(10))  BEGIN
    select * from customer;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getorder_tbByID` (IN `paid_idParam` INT(10), `amountparam` INT(100), `customer_idaram` INT(10), `product_idparam` INT(10), `user_idparam` INT(10), `paid_dateparam` DATE)  BEGIN
    select * from payment;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getproductByID` (IN `product_idParam` INT(10), `productnameparam` VARCHAR(100), `product_typearam` VARCHAR(100), `amountparam` INT(100), `date_madeparam` DATE, `date_expiredparam` DATE, `user_idparam` INT(10))  BEGIN
    select * from product;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getuserByID` (IN `user_idParam` INT(10), `first_nameparam` VARCHAR(50), `last_nameparam` VARCHAR(50), `passwordparam` VARCHAR(50))  BEGIN
    select * from user;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertcustomer` (IN `customer_Idparam` INT(10), `Fnameparam` VARCHAR(100), `Lnameparam` VARCHAR(100), `telePhoneNumberparam` INT(10))  BEGIN
    insert into customer values (customer_Idparam,  Fnameparam, Lnameparam,telePhoneNumberparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertorder_tb` (IN `order_idParam` INT(10), `quantityParam` VARCHAR(100), `amountParam` INT(100), `product_idParam` INT(10), `customer_idParam` INT(10), `ordered_dateParam` DATE)  BEGIN
    insert into order_tb values (order_idParam, quantityParam, amountParam, product_idParam,customer_id_idParam,ordered_dateParam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertpayment` (IN `pay_idParam` INT(10), `amountParam` INT(100), `customer_idParam` INT(10), `product_idParam` INT(10), `user_idParam` INT(10), `paid_dateParam` DATE)  BEGIN insert into payment values (pay_idParam, amountParam, customer_idParam,product_idParam,user_idParam,paid_dateParam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertuser` (IN `user_idparam` INT(10), `first_nameparam` VARCHAR(50), `last_nameparam` VARCHAR(50), `passwordparam` VARCHAR(50))  BEGIN
    insert into user values (user_idparam,firstnameparam,last_nameparam,passwordparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCcustomer` (IN `customer_idParam` INT(10), `firstnameparam` VARCHAR(100), `lastnameparam` VARCHAR(100), `telephonenumberparam` VARCHAR(100))  BEGIN
    update customer set firstname='emmanuel'where customer_id=1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateuser` (IN `user_idParam` INT(10), `first_nameparam` VARCHAR(50), `lastnameparam` VARCHAR(50), `passwordparam` VARCHAR(50))  BEGIN
    update user set firstname='emmy'where user_id=2;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(10) NOT NULL,
  `first name` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `telephonenumber` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `first name`, `lastname`, `telephonenumber`) VALUES
(1, 'nkubana amarie', 'malke', '0786636907'),
(2, 'akimana', 'joselyne', '0784455667'),
(5, 'muneza', 'aldo', '0786636907');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `customer_trigger` AFTER INSERT ON `customer` FOR EACH ROW INSERT INTO `customer` (`customer_id`, `first name`, `lastname`, `telephonenumber`) VALUES (NULL, 'nkubana', 'malke', '0786636907'), (NULL, 'akimana', 'joselyne', '0784455667')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `listinsert`
-- (See below for the actual view)
--
CREATE TABLE `listinsert` (
`customer_id` int(10)
,`first name` varchar(100)
,`lastname` varchar(100)
,`telephonenumber` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listorder_tb`
-- (See below for the actual view)
--
CREATE TABLE `listorder_tb` (
`order_id` int(10)
,`quantity` varchar(100)
,`amount` int(100)
,`product_id` int(10)
,`customer_id` int(10)
,`ordered_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list select`
-- (See below for the actual view)
--
CREATE TABLE `list select` (
`order_id` int(10)
,`quantity` varchar(100)
,`amount` int(100)
,`product_id` int(10)
,`customer_id` int(10)
,`ordered_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list selectpayment`
-- (See below for the actual view)
--
CREATE TABLE `list selectpayment` (
`pay_id` int(10)
,`amount` int(100)
,`customer_id` int(10)
,`product_id` int(10)
,`user_id` int(10)
,`paid_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list selectproduct`
-- (See below for the actual view)
--
CREATE TABLE `list selectproduct` (
`product_id` int(10)
,`productname` varchar(100)
,`product_type` varchar(100)
,`amount` int(100)
,`date_made` date
,`date_ expired` date
,`user_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list selectuser`
-- (See below for the actual view)
--
CREATE TABLE `list selectuser` (
`user_id` int(10)
,`first _name` varchar(50)
,`last_name` varchar(50)
,`password` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `order_tb`
--

CREATE TABLE `order_tb` (
  `order_id` int(10) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `amount` int(100) NOT NULL,
  `product_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `ordered_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_tb`
--

INSERT INTO `order_tb` (`order_id`, `quantity`, `amount`, `product_id`, `customer_id`, `ordered_date`) VALUES
(1, '25KG', 10000, 1, 1, '2022-07-26'),
(2, '450', 18000, 1, 1, '2022-07-26'),
(3, '2000', 1000, 1, 2, '2022-07-26');

--
-- Triggers `order_tb`
--
DELIMITER $$
CREATE TRIGGER `delete trigger2` BEFORE DELETE ON `order_tb` FOR EACH ROW DELETE FROM `order_tb` WHERE `order_tb`.`order_id` =3
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `order_tb` AFTER INSERT ON `order_tb` FOR EACH ROW INSERT INTO `order_tb` (`order_id`, `quantity`, `amount`, `product_id`, `customer_id`, `ordered_date`) VALUES (NULL, '25KG', '10000', '1', '1', '2022-07-26'), (NULL, '45', '18000', '1', '1', '2022-07-26')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_id` int(10) NOT NULL,
  `amount` int(100) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `paid_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_id`, `amount`, `customer_id`, `product_id`, `user_id`, `paid_date`) VALUES
(1, 1000, 1, 1, 1, '2022-07-26'),
(2, 1000, 2, 1, 1, '2022-07-26');

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `delete trigger` AFTER DELETE ON `payment` FOR EACH ROW DELETE FROM `payment` WHERE `payment`.`pay_id` ='2'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update trigger` AFTER INSERT ON `payment` FOR EACH ROW UPDATE `payment` SET `amount` = '100' WHERE `payment`.`pay_id` = 1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(10) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `product_type` varchar(100) NOT NULL,
  `amount` int(100) NOT NULL,
  `date_made` date NOT NULL,
  `date_ expired` date NOT NULL,
  `user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `productname`, `product_type`, `amount`, `date_made`, `date_ expired`, `user_id`) VALUES
(1, 'IBIJUMBA', 'SUPPER', 10000, '2022-07-26', '2022-07-13', 1),
(2, 'IBIRAYI', 'SUPPER1', 18000, '2022-07-26', '2022-07-26', 2),
(3, 'pizza', 'supper', 2000, '2022-07-13', '2024-07-30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(10) NOT NULL,
  `first _name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first _name`, `last_name`, `password`) VALUES
(1, 'ELIAS', 'KAMANA', 'kamani'),
(2, 'KANANI', 'JADOS', 'erichabibu'),
(3, 'ELIAzari', 'KAMANA', 'kamani');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `update trigger2` BEFORE INSERT ON `user` FOR EACH ROW UPDATE `user` SET `first _name` = 'ELIASi' WHERE `user`.`user_id` = 1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `listinsert`
--
DROP TABLE IF EXISTS `listinsert`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listinsert`  AS  select `customer`.`customer_id` AS `customer_id`,`customer`.`first name` AS `first name`,`customer`.`lastname` AS `lastname`,`customer`.`telephonenumber` AS `telephonenumber` from `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `listorder_tb`
--
DROP TABLE IF EXISTS `listorder_tb`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listorder_tb`  AS  select `order_tb`.`order_id` AS `order_id`,`order_tb`.`quantity` AS `quantity`,`order_tb`.`amount` AS `amount`,`order_tb`.`product_id` AS `product_id`,`order_tb`.`customer_id` AS `customer_id`,`order_tb`.`ordered_date` AS `ordered_date` from `order_tb` ;

-- --------------------------------------------------------

--
-- Structure for view `list select`
--
DROP TABLE IF EXISTS `list select`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list select`  AS  select `order_tb`.`order_id` AS `order_id`,`order_tb`.`quantity` AS `quantity`,`order_tb`.`amount` AS `amount`,`order_tb`.`product_id` AS `product_id`,`order_tb`.`customer_id` AS `customer_id`,`order_tb`.`ordered_date` AS `ordered_date` from `order_tb` ;

-- --------------------------------------------------------

--
-- Structure for view `list selectpayment`
--
DROP TABLE IF EXISTS `list selectpayment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list selectpayment`  AS  select `payment`.`pay_id` AS `pay_id`,`payment`.`amount` AS `amount`,`payment`.`customer_id` AS `customer_id`,`payment`.`product_id` AS `product_id`,`payment`.`user_id` AS `user_id`,`payment`.`paid_date` AS `paid_date` from `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `list selectproduct`
--
DROP TABLE IF EXISTS `list selectproduct`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list selectproduct`  AS  select `product`.`product_id` AS `product_id`,`product`.`productname` AS `productname`,`product`.`product_type` AS `product_type`,`product`.`amount` AS `amount`,`product`.`date_made` AS `date_made`,`product`.`date_ expired` AS `date_ expired`,`product`.`user_id` AS `user_id` from `product` ;

-- --------------------------------------------------------

--
-- Structure for view `list selectuser`
--
DROP TABLE IF EXISTS `list selectuser`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list selectuser`  AS  select `user`.`user_id` AS `user_id`,`user`.`first _name` AS `first _name`,`user`.`last_name` AS `last_name`,`user`.`password` AS `password` from `user` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `order_tb`
--
ALTER TABLE `order_tb`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `product_order_tb` (`product_id`),
  ADD KEY `customer_order_tb` (`customer_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_id`),
  ADD KEY `customer_payment` (`customer_id`),
  ADD KEY `product_payment` (`product_id`),
  ADD KEY `user_payment` (`user_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `user_product` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `order_tb`
--
ALTER TABLE `order_tb`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_tb`
--
ALTER TABLE `order_tb`
  ADD CONSTRAINT `customer_order_tb` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `product_order_tb` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `customer_payment` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `product_payment` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `user_payment` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `user_product` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
