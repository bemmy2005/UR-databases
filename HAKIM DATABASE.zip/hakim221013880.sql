-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 09:06 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hakim221013880`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `comxInsert` ()  BEGIN
    INSERT INTO `commx` (`commx_id`, `commx_purpose`, `commx_details`, `st_id`, `Lec_id`, `Dos_id`) VALUES ('7', 'cheated', 'vjvdh dcm ', '2', '1', '87');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCarsDetails` ()  BEGIN
  DELETE FROM `dos` WHERE `dos`.`Dos_id` = 3;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcomxDetails` ()  BEGIN
    select * from commx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcoursexDetails` ()  BEGIN
    select * from coursex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDosDetails` ()  BEGIN
    select * from dos;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getlectureDetails` ()  BEGIN
    select * from letuere;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getStudentDetails` ()  BEGIN
    select * from student;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getUserDetails` ()  BEGIN
    select * from usersx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `gInsertLecturer` ()  BEGIN
    INSERT INTO `letuere` (`Lec_id`, `Lec_Name`, `Lec_Number`, `Lec_gender`, `Lec_suject`, `Lec_degree`) VALUES ('', 'hakimu', '21919333', 'male', 'DB and Sy3', 'doctor');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertCourses` ()  BEGIN
    INSERT INTO `coursex` (`course_id`, `course_Name`, `course_marks`, `Lec_id`, `Dos_id`) VALUES ('5', 'quantitative', '230', '87', '87');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertStudents` ()  BEGIN
    INSERT INTO `student` (`st_id`, `st_Fname`, `st_Lname`, `st_Department`, `st_number`, `st_gender`) VALUES ('', 'Habibi', 'Hakim', 'CPA', '221918372', 'female');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertUsersx` ()  BEGIN
   INSERT INTO `usersx` (`user_id`, `user_status`, `user_password`, `st_id`, `Lec_id`, `Dos_id`) VALUES ('4', 'DoS', '12321', '76', '87', '2');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `storedwithsubquery` ()  BEGIN
   create VIEW viewwithsubquery as(SELECT st_Fname,st_Lname,st_Department,st_number,st_gender,course_Name,course_marks FROM student join usersx on student.st_id=usersx.st_id join letuere on letuere.Lec_id=usersx.Lec_id join coursex on letuere.Lec_id=coursex.Lec_id where course_marks>(SELECT AVG(course_marks)));
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateLecturer` ()  BEGIN
    UPDATE `letuere` SET `Lec_Name` = 'chris brown', `Lec_Number` = '221201387' WHERE `letuere`.`Lec_id` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdatestudentData` ()  BEGIN
    UPDATE `student` SET `st_Fname` = 'norther', `st_Lname` = 'joel' WHERE `student`.`st_id` = 2;


END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `commx`
--

CREATE TABLE `commx` (
  `commx_id` int(10) NOT NULL,
  `commx_purpose` varchar(12) NOT NULL,
  `commx_details` varchar(200) DEFAULT NULL,
  `st_id` int(5) DEFAULT NULL,
  `Lec_id` int(5) DEFAULT NULL,
  `Dos_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `commxinfo`
-- (See below for the actual view)
--
CREATE TABLE `commxinfo` (
`commx_id` int(10)
,`commx_purpose` varchar(12)
,`commx_details` varchar(200)
,`st_id` int(5)
,`Lec_id` int(5)
,`Dos_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `coursex`
--

CREATE TABLE `coursex` (
  `course_id` int(10) NOT NULL,
  `course_Name` varchar(12) NOT NULL,
  `course_marks` int(10) NOT NULL,
  `Lec_id` int(10) DEFAULT NULL,
  `Dos_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursex`
--

INSERT INTO `coursex` (`course_id`, `course_Name`, `course_marks`, `Lec_id`, `Dos_id`) VALUES
(1, 'System Engin', 230, 1, 2),
(2, 'database', 100, 87, 1),
(5, 'quantitative', 230, 87, 87);

-- --------------------------------------------------------

--
-- Stand-in structure for view `coursexinfo`
-- (See below for the actual view)
--
CREATE TABLE `coursexinfo` (
`course_id` int(10)
,`course_Name` varchar(12)
,`course_marks` int(10)
,`Lec_id` int(10)
,`Dos_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `dos`
--

CREATE TABLE `dos` (
  `Dos_id` int(10) NOT NULL,
  `Dos_Name` varchar(12) NOT NULL,
  `Dos_Number` int(10) NOT NULL,
  `Dos_gender` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dos`
--

INSERT INTO `dos` (`Dos_id`, `Dos_Name`, `Dos_Number`, `Dos_gender`) VALUES
(1, 'hashakimana', 2220101, 'MAle'),
(2, 'carine', 2212333, 'Female'),
(87, 'shema', 7864321, 'male');

--
-- Triggers `dos`
--
DELIMITER $$
CREATE TRIGGER `insertDosAlert` AFTER INSERT ON `dos` FOR EACH ROW BEGIN  
INSERT INTO `dos` (`Dos_id`, `Dos_Name`, `Dos_Number`, `Dos_gender`) VALUES ('97', 'shema', '07364321', 'male'); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `dosinfo`
-- (See below for the actual view)
--
CREATE TABLE `dosinfo` (
`Dos_id` int(10)
,`Dos_Name` varchar(12)
,`Dos_Number` int(10)
,`Dos_gender` varchar(7)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `lectuereinfo`
-- (See below for the actual view)
--
CREATE TABLE `lectuereinfo` (
`Lec_id` int(5)
,`Lec_Name` varchar(12)
,`Lec_Number` int(10)
,`Lec_gender` varchar(7)
,`Lec_suject` varchar(10)
,`Lec_degree` varchar(12)
);

-- --------------------------------------------------------

--
-- Table structure for table `letuere`
--

CREATE TABLE `letuere` (
  `Lec_id` int(5) NOT NULL,
  `Lec_Name` varchar(12) NOT NULL,
  `Lec_Number` int(10) DEFAULT NULL,
  `Lec_gender` varchar(7) NOT NULL,
  `Lec_suject` varchar(10) DEFAULT NULL,
  `Lec_degree` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `letuere`
--

INSERT INTO `letuere` (`Lec_id`, `Lec_Name`, `Lec_Number`, `Lec_gender`, `Lec_suject`, `Lec_degree`) VALUES
(0, 'hakimu', 21919333, 'male', 'DB and Sy3', 'doctor'),
(1, 'chris', 22101387, 'Male', 'Database', 'PHD'),
(87, 'bugingo', 123, 'male', 'DB and Sy', 'doctor'),
(645, 'rugwiro', 7867653, 'male', 'database', 'diploma');

--
-- Triggers `letuere`
--
DELIMITER $$
CREATE TRIGGER `DELETEAlert` AFTER INSERT ON `letuere` FOR EACH ROW BEGIN  
DELETE FROM `letuere` WHERE `letuere`.`Lec_id` = 645; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `DELETElecAlert` AFTER INSERT ON `letuere` FOR EACH ROW BEGIN  
DELETE FROM `letuere` WHERE `letuere`.`Lec_id` = 645; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateLetuerelert` AFTER INSERT ON `letuere` FOR EACH ROW BEGIN  
UPDATE `letuere` SET `Lec_Name` = 'chrishat', `Lec_Number` = '22121387' WHERE `letuere`.`Lec_id` = 1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `st_id` int(5) NOT NULL,
  `st_Fname` varchar(15) NOT NULL,
  `st_Lname` varchar(15) NOT NULL,
  `st_Department` varchar(10) NOT NULL,
  `st_number` int(10) DEFAULT NULL,
  `st_gender` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`st_id`, `st_Fname`, `st_Lname`, `st_Department`, `st_number`, `st_gender`) VALUES
(0, 'Habibi', 'Hakim', 'CPA', 221918372, 'female'),
(1, 'sauda', 'uwiman', 'finance', 234456, 'female'),
(4, 'Innocent', 'Ishimwe', 'BIT', 22937745, 'Male'),
(76, 'hirval', 'vestine', 'accounting', 7899874, 'female');

--
-- Triggers `student`
--
DELIMITER $$
CREATE TRIGGER `DeleteStuAlert` AFTER INSERT ON `student` FOR EACH ROW BEGIN  
DELETE FROM `student` WHERE `student`.`st_id` = 645; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateStudentAlert` AFTER INSERT ON `student` FOR EACH ROW BEGIN  
UPDATE `student` SET `st_Fname` = 'northern', `st_Lname` = 'joewe' WHERE `student`.`st_id` = 2;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `studentinfo`
-- (See below for the actual view)
--
CREATE TABLE `studentinfo` (
`st_id` int(5)
,`st_Fname` varchar(15)
,`st_Lname` varchar(15)
,`st_Department` varchar(10)
,`st_number` int(10)
,`st_gender` varchar(7)
);

-- --------------------------------------------------------

--
-- Table structure for table `usersx`
--

CREATE TABLE `usersx` (
  `user_id` int(10) NOT NULL,
  `user_status` varchar(15) NOT NULL,
  `user_password` int(10) NOT NULL,
  `st_id` int(5) DEFAULT NULL,
  `Lec_id` int(10) DEFAULT NULL,
  `Dos_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersx`
--

INSERT INTO `usersx` (`user_id`, `user_status`, `user_password`, `st_id`, `Lec_id`, `Dos_id`) VALUES
(4, 'DoS', 12321, 76, 87, 2);

--
-- Triggers `usersx`
--
DELIMITER $$
CREATE TRIGGER `insertUserAlert` AFTER INSERT ON `usersx` FOR EACH ROW BEGIN  
INSERT INTO `usersx` (`user_id`, `user_status`, `user_password`, `st_id`, `Lec_id`, `Dos_id`) VALUES ('1', 'DoS', '12321', '76', '87', '2');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `usersxinfo`
-- (See below for the actual view)
--
CREATE TABLE `usersxinfo` (
`user_id` int(10)
,`user_status` varchar(15)
,`user_password` int(10)
,`st_id` int(5)
,`Lec_id` int(10)
,`Dos_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewwithsubquery`
-- (See below for the actual view)
--
CREATE TABLE `viewwithsubquery` (
`st_Fname` varchar(15)
,`st_Lname` varchar(15)
,`st_Department` varchar(10)
,`st_number` int(10)
,`st_gender` varchar(7)
,`course_Name` varchar(12)
,`course_marks` int(10)
);

-- --------------------------------------------------------

--
-- Structure for view `commxinfo`
--
DROP TABLE IF EXISTS `commxinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `commxinfo`  AS  (select `commx`.`commx_id` AS `commx_id`,`commx`.`commx_purpose` AS `commx_purpose`,`commx`.`commx_details` AS `commx_details`,`commx`.`st_id` AS `st_id`,`commx`.`Lec_id` AS `Lec_id`,`commx`.`Dos_id` AS `Dos_id` from `commx`) ;

-- --------------------------------------------------------

--
-- Structure for view `coursexinfo`
--
DROP TABLE IF EXISTS `coursexinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `coursexinfo`  AS  (select `coursex`.`course_id` AS `course_id`,`coursex`.`course_Name` AS `course_Name`,`coursex`.`course_marks` AS `course_marks`,`coursex`.`Lec_id` AS `Lec_id`,`coursex`.`Dos_id` AS `Dos_id` from `coursex`) ;

-- --------------------------------------------------------

--
-- Structure for view `dosinfo`
--
DROP TABLE IF EXISTS `dosinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `dosinfo`  AS  (select `dos`.`Dos_id` AS `Dos_id`,`dos`.`Dos_Name` AS `Dos_Name`,`dos`.`Dos_Number` AS `Dos_Number`,`dos`.`Dos_gender` AS `Dos_gender` from `dos`) ;

-- --------------------------------------------------------

--
-- Structure for view `lectuereinfo`
--
DROP TABLE IF EXISTS `lectuereinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lectuereinfo`  AS  (select `letuere`.`Lec_id` AS `Lec_id`,`letuere`.`Lec_Name` AS `Lec_Name`,`letuere`.`Lec_Number` AS `Lec_Number`,`letuere`.`Lec_gender` AS `Lec_gender`,`letuere`.`Lec_suject` AS `Lec_suject`,`letuere`.`Lec_degree` AS `Lec_degree` from `letuere`) ;

-- --------------------------------------------------------

--
-- Structure for view `studentinfo`
--
DROP TABLE IF EXISTS `studentinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `studentinfo`  AS  (select `student`.`st_id` AS `st_id`,`student`.`st_Fname` AS `st_Fname`,`student`.`st_Lname` AS `st_Lname`,`student`.`st_Department` AS `st_Department`,`student`.`st_number` AS `st_number`,`student`.`st_gender` AS `st_gender` from `student`) ;

-- --------------------------------------------------------

--
-- Structure for view `usersxinfo`
--
DROP TABLE IF EXISTS `usersxinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `usersxinfo`  AS  (select `usersx`.`user_id` AS `user_id`,`usersx`.`user_status` AS `user_status`,`usersx`.`user_password` AS `user_password`,`usersx`.`st_id` AS `st_id`,`usersx`.`Lec_id` AS `Lec_id`,`usersx`.`Dos_id` AS `Dos_id` from `usersx`) ;

-- --------------------------------------------------------

--
-- Structure for view `viewwithsubquery`
--
DROP TABLE IF EXISTS `viewwithsubquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewwithsubquery`  AS  (select `student`.`st_Fname` AS `st_Fname`,`student`.`st_Lname` AS `st_Lname`,`student`.`st_Department` AS `st_Department`,`student`.`st_number` AS `st_number`,`student`.`st_gender` AS `st_gender`,`coursex`.`course_Name` AS `course_Name`,`coursex`.`course_marks` AS `course_marks` from (((`student` join `usersx` on(`student`.`st_id` = `usersx`.`st_id`)) join `letuere` on(`letuere`.`Lec_id` = `usersx`.`Lec_id`)) join `coursex` on(`letuere`.`Lec_id` = `coursex`.`Lec_id`)) where `coursex`.`course_marks` > (select avg(`coursex`.`course_marks`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `commx`
--
ALTER TABLE `commx`
  ADD PRIMARY KEY (`commx_id`),
  ADD KEY `st_id` (`st_id`),
  ADD KEY `Lec_id` (`Lec_id`),
  ADD KEY `Dos_id` (`Dos_id`);

--
-- Indexes for table `coursex`
--
ALTER TABLE `coursex`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `Lec_id` (`Lec_id`),
  ADD KEY `Dos_id` (`Dos_id`);

--
-- Indexes for table `dos`
--
ALTER TABLE `dos`
  ADD PRIMARY KEY (`Dos_id`);

--
-- Indexes for table `letuere`
--
ALTER TABLE `letuere`
  ADD PRIMARY KEY (`Lec_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `usersx`
--
ALTER TABLE `usersx`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `st_id` (`st_id`),
  ADD KEY `Lec_id` (`Lec_id`),
  ADD KEY `Dos_id` (`Dos_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `commx`
--
ALTER TABLE `commx`
  ADD CONSTRAINT `commx_ibfk_1` FOREIGN KEY (`Lec_id`) REFERENCES `letuere` (`Lec_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commx_ibfk_2` FOREIGN KEY (`st_id`) REFERENCES `student` (`st_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commx_ibfk_3` FOREIGN KEY (`Dos_id`) REFERENCES `dos` (`Dos_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `coursex`
--
ALTER TABLE `coursex`
  ADD CONSTRAINT `coursex_ibfk_1` FOREIGN KEY (`Lec_id`) REFERENCES `letuere` (`Lec_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `coursex_ibfk_2` FOREIGN KEY (`Dos_id`) REFERENCES `dos` (`Dos_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usersx`
--
ALTER TABLE `usersx`
  ADD CONSTRAINT `usersx_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `student` (`st_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usersx_ibfk_2` FOREIGN KEY (`Lec_id`) REFERENCES `letuere` (`Lec_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usersx_ibfk_3` FOREIGN KEY (`Dos_id`) REFERENCES `dos` (`Dos_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usersx_ibfk_4` FOREIGN KEY (`st_id`) REFERENCES `student` (`st_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
