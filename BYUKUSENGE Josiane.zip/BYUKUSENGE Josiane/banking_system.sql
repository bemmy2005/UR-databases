-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 02:38 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banking_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Accountdel_procedure` (IN `A_iddel` INT(10))  BEGIN
DELETE from account WHERE A_id=A_iddel;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Account_pro` (IN `A_ida` INT(10), `C_ida` INT(10), `Account_namea` VARCHAR(50), `Account_numbera` VARCHAR(16), `Account_typea` VARCHAR(50))  BEGIN
SELECT * FROM Account;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Account_procedure` (IN `A_ida` INT(10), IN `C_ida` INT(10), IN `Account_namea` VARCHAR(50), IN `Account_numbera` VARCHAR(16), IN `Account_typea` VARCHAR(50), IN `U_ida` INT(10))  BEGIN
INSERT INTO Account VALUES(A_ida,C_ida,Account_namea,Account_numbera,Account_typea,U_ida);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Customer_pro` (`C_idb` INT(10), `Firstnameb` VARCHAR(50), `Lastnameb` VARCHAR(50), `Genderb` VARCHAR(6), `Date_of_birthb` DATE, `Residanceb` VARCHAR(100), `Phonenumberb` INT(12), `National_idb` INT(16), `Account_guardianb` VARCHAR(50))  BEGIN
SELECT * FROM Customer;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Customer_procedure` (`C_idb` INT(10), `Firstnameb` VARCHAR(50), `Lastnameb` VARCHAR(50), `Genderb` VARCHAR(6), `Date_of_birthb` DATE, `Residanceb` VARCHAR(100), `Phonenumberb` INT(12), `National_idb` INT(16), `Account_guardianb` VARCHAR(50))  BEGIN
INSERT INTO Customer VALUES(C_idb,Firstnameb,Lastnameb,Genderb,Date_of_birthb,Residanceb,Phonenumberb,National_idb,Account_guardianb);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Historical_pro` (IN `H_ide` INT(10), `Datee` DATE, `C_ide` INT(10), `A_ide` INT(10), `T_ide` INT(10))  BEGIN
SELECT * FROM historical;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `historical_procedure` (IN `H_idh` INT(10))  BEGIN
DELETE FROM historical WHERE H_id=H_idh;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Subquerytransaction` (IN `T_idd` INT(12), `Date_of_transactiond` DATE, `A_idd` INT(10), `Deposit_amountd` INT(9), `Wihdraw_amountd` INT(9), `Total_amountd` INT(9), `Messaged` VARCHAR(255), `U_idd` INT(10))  BEGIN
SELECT T_idd,Date_of_transactiond,A_idd,Deposit_amountd,Wihdraw_amountd,Total_amountd,Messaged,U_idd FROM Transaction WHERE Deposite_amount>=(SELECT Deposite_amount>=50000 FROM transaction);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Transaction_pro` (IN `T_idc` INT(10), `Date_of_transactionc` DATE, `A_idc` INT(10), `Deposit_amountc` INT(9), `wihdraw_amountc` INT(9), `Total_amountc` INT(9), `Messagec` VARCHAR(255))  BEGIN
SELECT * FROM Transaction;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Transaction_procedure` (IN `T_idc` INT(10), `Date_of_transactionc` DATE, `A_idc` INT(10), `Deposit_amountc` INT(9), `wihdraw_amountc` INT(9), `Total_amountc` INT(9), `Messagec` VARCHAR(255), `U_idc` INT(10))  BEGIN
INSERT INTO Transaction VALUES(T_idc,Date_of_transactionc,A_idc,Deposit_amountc,wihdraw_amountc,Total_amountc,Messagec,U_idc);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Updateusers_procedure` (IN `Genderr` VARCHAR(6))  BEGIN
UPDATE Users SET Gender='F' WHERE Gender=Genderr;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_procedure` (IN `Accounttypep` VARCHAR(50))  BEGIN
UPDATE Account SET Accounttype=Accounttypep WHERE A_id=1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Users_pro` (IN `U_idd` INT(10), `Firstnamed` VARCHAR(50), `Lastnamed` VARCHAR(50), `Genderd` VARCHAR(6), `Aged` INT(3), `Usernamed` VARCHAR(50), `Passwordd` VARCHAR(50), `Usertyped` VARCHAR(50))  BEGIN
SELECT * FROM Users;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Users_procedure` (IN `U_idd` INT(10), `Firstnamed` VARCHAR(50), `Lastnamed` VARCHAR(50), `Genderd` VARCHAR(6), `Aged` INT(3), `Usernamed` VARCHAR(50), `Passwordd` VARCHAR(50), `Usertyped` VARCHAR(50))  BEGIN
INSERT INTO Users VALUES(U_idd,Firstnamed,Lastnamed,Genderd,Aged,Usernamed,Passwordd,Usertyped);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `A_id` int(10) NOT NULL,
  `C_id` int(10) DEFAULT NULL,
  `Account_name` varchar(50) NOT NULL,
  `Accountnumber` varchar(16) NOT NULL,
  `Accounttype` varchar(50) NOT NULL,
  `U_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`A_id`, `C_id`, `Account_name`, `Accountnumber`, `Accounttype`, `U_id`) VALUES
(1, 1, 'student account', '2147483647', 'Saving and credit account', NULL),
(2, 2, 'business', '401510078788', 'saving_account', NULL),
(3, 2, 'business', '2147483647', 'block account', NULL),
(4, 1, 'student account', '12974887367', 'saving account', NULL),
(6, 1, 'Student account', '34689032677', 'Credit account', NULL);

--
-- Triggers `account`
--
DELIMITER $$
CREATE TRIGGER `Account_trigger` AFTER INSERT ON `account` FOR EACH ROW INSERT INTO Account VALUES(NEW.Account_name)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Accounts_trigger` AFTER DELETE ON `account` FOR EACH ROW DELETE FROM Account WHERE A_id=3
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `account_view`
-- (See below for the actual view)
--
CREATE TABLE `account_view` (
`A_id` int(10)
,`c_id` int(10)
,`Account_name` varchar(50)
,`Accountname` varchar(16)
,`Accounttype` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `C_id` int(10) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) DEFAULT NULL,
  `Gender` varchar(6) NOT NULL,
  `Date_of_birth` date DEFAULT NULL,
  `Residance` varchar(100) NOT NULL,
  `Phonenumber` int(12) NOT NULL,
  `National_id` int(16) NOT NULL,
  `Account_guardian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`C_id`, `Firstname`, `Lastname`, `Gender`, `Date_of_birth`, `Residance`, `Phonenumber`, `National_id`, `Account_guardian`) VALUES
(1, 'Josiane', 'Byukusenge', 'female', '0000-00-00', 'kigali,gasabo,gisozi,musezero', 788237961, 2147483647, 'sister'),
(2, 'Orla', 'Ishimwe', 'femele', '0000-00-00', 'Amajyepfo', 780824352, 2147483647, 'father'),
(6, 'axel', 'mugisha', 'male', '0000-00-00', 'kigali', 789553282, 2147483647, 'father');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `Customer_trigger` AFTER UPDATE ON `customer` FOR EACH ROW UPDATE Customer SET Gender='F' WHERE Gender='Female'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_view`
-- (See below for the actual view)
--
CREATE TABLE `customer_view` (
`C_id` int(10)
,`Firstname` varchar(50)
,`Lastname` varchar(50)
,`Gender` varchar(6)
,`Date_of_birth` date
,`Residance` varchar(100)
,`Phonenumber` int(12)
,`National_id` int(16)
,`Account_guardian` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `historical`
--

CREATE TABLE `historical` (
  `H_id` int(10) NOT NULL,
  `Date` date DEFAULT NULL,
  `C_id` int(10) DEFAULT NULL,
  `A_id` int(10) DEFAULT NULL,
  `T_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `historical`
--

INSERT INTO `historical` (`H_id`, `Date`, `C_id`, `A_id`, `T_id`) VALUES
(1, '0000-00-00', 1, 1, 1),
(4, '0000-00-00', 2, 3, 1),
(5, '0000-00-00', 1, 1, 1),
(6, '0000-00-00', 1, 1, 1),
(7, '0000-00-00', 1, 1, 1);

--
-- Triggers `historical`
--
DELIMITER $$
CREATE TRIGGER `Historial_trigger` AFTER DELETE ON `historical` FOR EACH ROW DELETE FROM Historical where H_id=5
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `historical_view`
-- (See below for the actual view)
--
CREATE TABLE `historical_view` (
`H_id` int(10)
,`Date` date
,`C_id` int(10)
,`A_id` int(10)
,`T_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `operation_view`
-- (See below for the actual view)
--
CREATE TABLE `operation_view` (
`T_id` int(10)
,`Date_of_Transaction` date
,`A_id` int(10)
,`Deposit_amount` int(9)
,`Wihdraw_amount` int(9)
,`Total_amount` int(9)
,`Message` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `T_id` int(10) NOT NULL,
  `Date_of_transaction` date DEFAULT NULL,
  `A_id` int(10) DEFAULT NULL,
  `Deposit_amount` int(9) DEFAULT NULL,
  `Wihdraw_amount` int(9) DEFAULT NULL,
  `Total_amount` int(9) DEFAULT NULL,
  `Message` varchar(255) NOT NULL,
  `U_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`T_id`, `Date_of_transaction`, `A_id`, `Deposit_amount`, `Wihdraw_amount`, `Total_amount`, `Message`, `U_id`) VALUES
(1, '0000-00-00', 1, 200000, 5000, 15000, 'payment received', NULL),
(3, '0000-00-00', 1, 10000, 0, 10000, 'deposite successfull', NULL),
(4, '0000-00-00', 3, 50000, 10000, 190000, 'transaction successful', NULL);

--
-- Triggers `transaction`
--
DELIMITER $$
CREATE TRIGGER `Transaction_trigger` AFTER INSERT ON `transaction` FOR EACH ROW INSERT INTO Transaction VALUES(new.Total_amount-100)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `transaction_view`
-- (See below for the actual view)
--
CREATE TABLE `transaction_view` (
`T_id` int(10)
,`Date_of_transaction` date
,`A_id` int(10)
,`Deposit_amount` int(9)
,`Wihdraw_amount` int(9)
,`Total_amount` int(9)
,`Message` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `U_id` int(10) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) DEFAULT NULL,
  `Gender` varchar(6) NOT NULL,
  `Age` int(3) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Usertype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`U_id`, `Firstname`, `Lastname`, `Gender`, `Age`, `Username`, `Password`, `Usertype`) VALUES
(1, 'Epiphanie', 'Ishimwe', 'female', 20, '', '', ''),
(2, 'Agahozo', 'aime', 'female', 25, 'aime', '@aime123', 'Manager'),
(3, 'Mutimura', 'Louise', 'female', 27, 'Mutimura', 'LOusie@345', 'customer');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `user_trigger` AFTER UPDATE ON `users` FOR EACH ROW UPDATE Users SET Lastname=U(Lastname) WHERE(new.Lastname)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_view`
-- (See below for the actual view)
--
CREATE TABLE `user_view` (
`U_id` int(10)
,`Firstname` varchar(50)
,`Lastname` varchar(50)
,`Gender` varchar(6)
,`Age` int(3)
);

-- --------------------------------------------------------

--
-- Structure for view `account_view`
--
DROP TABLE IF EXISTS `account_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `account_view`  AS  select `account`.`A_id` AS `A_id`,`account`.`C_id` AS `c_id`,`account`.`Account_name` AS `Account_name`,`account`.`Accountnumber` AS `Accountname`,`account`.`Accounttype` AS `Accounttype` from `account` ;

-- --------------------------------------------------------

--
-- Structure for view `customer_view`
--
DROP TABLE IF EXISTS `customer_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_view`  AS  select `customer`.`C_id` AS `C_id`,`customer`.`Firstname` AS `Firstname`,`customer`.`Lastname` AS `Lastname`,`customer`.`Gender` AS `Gender`,`customer`.`Date_of_birth` AS `Date_of_birth`,`customer`.`Residance` AS `Residance`,`customer`.`Phonenumber` AS `Phonenumber`,`customer`.`National_id` AS `National_id`,`customer`.`Account_guardian` AS `Account_guardian` from `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `historical_view`
--
DROP TABLE IF EXISTS `historical_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `historical_view`  AS  select `historical`.`H_id` AS `H_id`,`historical`.`Date` AS `Date`,`historical`.`C_id` AS `C_id`,`historical`.`A_id` AS `A_id`,`historical`.`T_id` AS `T_id` from `historical` ;

-- --------------------------------------------------------

--
-- Structure for view `operation_view`
--
DROP TABLE IF EXISTS `operation_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `operation_view`  AS  select `transaction_view`.`T_id` AS `T_id`,`transaction_view`.`Date_of_transaction` AS `Date_of_Transaction`,`transaction_view`.`A_id` AS `A_id`,`transaction_view`.`Deposit_amount` AS `Deposit_amount`,`transaction_view`.`Wihdraw_amount` AS `Wihdraw_amount`,`transaction_view`.`Total_amount` AS `Total_amount`,`transaction_view`.`Message` AS `Message` from `transaction_view` where `transaction_view`.`Total_amount` >= (select `transaction_view`.`Total_amount` >= 15000) ;

-- --------------------------------------------------------

--
-- Structure for view `transaction_view`
--
DROP TABLE IF EXISTS `transaction_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transaction_view`  AS  select `transaction`.`T_id` AS `T_id`,`transaction`.`Date_of_transaction` AS `Date_of_transaction`,`transaction`.`A_id` AS `A_id`,`transaction`.`Deposit_amount` AS `Deposit_amount`,`transaction`.`Wihdraw_amount` AS `Wihdraw_amount`,`transaction`.`Total_amount` AS `Total_amount`,`transaction`.`Message` AS `Message` from `transaction` ;

-- --------------------------------------------------------

--
-- Structure for view `user_view`
--
DROP TABLE IF EXISTS `user_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_view`  AS  select `users`.`U_id` AS `U_id`,`users`.`Firstname` AS `Firstname`,`users`.`Lastname` AS `Lastname`,`users`.`Gender` AS `Gender`,`users`.`Age` AS `Age` from `users` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`A_id`),
  ADD KEY `C_id` (`C_id`),
  ADD KEY `U_id` (`U_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`C_id`);

--
-- Indexes for table `historical`
--
ALTER TABLE `historical`
  ADD PRIMARY KEY (`H_id`),
  ADD KEY `C_id` (`C_id`),
  ADD KEY `A_id` (`A_id`),
  ADD KEY `T_id` (`T_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`T_id`),
  ADD KEY `A_id` (`A_id`),
  ADD KEY `U_id` (`U_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`U_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `A_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `C_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `historical`
--
ALTER TABLE `historical`
  MODIFY `H_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `T_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `U_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `account_ibfk_1` FOREIGN KEY (`C_id`) REFERENCES `customer` (`C_id`),
  ADD CONSTRAINT `account_ibfk_2` FOREIGN KEY (`U_id`) REFERENCES `users` (`U_id`);

--
-- Constraints for table `historical`
--
ALTER TABLE `historical`
  ADD CONSTRAINT `historical_ibfk_1` FOREIGN KEY (`C_id`) REFERENCES `customer` (`C_id`),
  ADD CONSTRAINT `historical_ibfk_2` FOREIGN KEY (`A_id`) REFERENCES `account` (`A_id`),
  ADD CONSTRAINT `historical_ibfk_3` FOREIGN KEY (`T_id`) REFERENCES `transaction` (`T_id`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`A_id`) REFERENCES `account` (`A_id`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`U_id`) REFERENCES `users` (`U_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
