-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 10:41 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletegrade` (IN `grade_idParam` INT(12))   BEGIN
delete from grade where grade_id=67;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteuser` (IN `user_idParam` INT(12))   BEGIN
delete from user where user_id=12;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getdepartmentDetails` ()   BEGIN
    select * from department;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getemployeeDetails` ()   BEGIN
    select * from employee;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getemp_salaryDetails` ()   BEGIN
    select * from employee_salary_details;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getgradeDetails` ()   BEGIN
    select * from grade;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getgrade_of_employeeDetails` ()   BEGIN
    select * from employee_salary_details;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getuserDetails` ()   BEGIN
    select * from user;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insergrade` (IN `grade_idparam` INT(12), `grade_nameparam` VARCHAR(25), `grade_short_nameparam` VARCHAR(25), `grade_basicparam` INT(12), `grade_taparam` INT(12), `grade_daparam` INT(12), `grade_hraparam` INT(12), `grade_maparam` INT(12), `grade_bonusparam` INT(12), `grade_pfparam` INT(12), `grade_ptparam` INT(25))   BEGIN
    insert into grade values (grade_idparam, grade_nameparam, grade_short_nameparam, grade_basicparam,grade_taparam ,grade_daparam, grade_hraparam,grade_maparam ,grade_bonusparam, grade_pfparam, grade_ptparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertdepartment` (IN `dept_idparam` INT(12), `dept_nameParam` VARCHAR(25))   BEGIN
    insert into department values (dept_idParam,dept_nameParam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertemployee` (IN `emp_id_idparam` INT(12), `emp_titleparam` VARCHAR(25), `emp_nameParam` VARCHAR(25), `emp_dobparam` DATE, `emp_dojparam` DATE, `emp_addressparam` VARCHAR(25), `emp_cityparam` VARCHAR(25), `emp_pincodeparam` INT(15), `emp_mobile_noparam` INT(15), `emp_stateparam` VARCHAR(25), `emp_mail_idparam` VARCHAR(25), `emp_pan_noparam` VARCHAR(25), `emp_upload_panparam` VARCHAR(25))   BEGIN
    insert into employee values (emp_id_idparam,emp_titleparam,emp_nameParam ,emp_dobparam ,emp_dojparam,emp_addressparam,emp_cityparam ,emp_pincodeparam ,emp_mobile_noparam ,emp_stateparam ,emp_mail_idparam ,emp_pan_noparam ,emp_upload_panparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertemployee_grade_details` (IN `transaction_idparam` INT(12), `emp_idparam` INT(12), `emp_deptparam` INT(12), `emp_gradeparam` INT(12), `emp_from_dateparam` DATE, `emp_to_dateparam` DATE)   BEGIN
    insert into employee_grade_details values (transaction_idparam, emp_idparam, emp_deptparam,emp_gradeparam,emp_from_dateparam,emp_to_dateparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertemployee_salary_details` (IN `transaction_idparam` INT(12), `emp_idparam` INT(12), `emp_salary_monthparam` VARCHAR(25), `emp_salary_yearparam` VARCHAR(25), `emp_salary_eimbursmentparam` DATETIME, `emp_dept_idparam` INT(12), `emp_grade_idparam` INT(12), `emp_basicparam` INT(12), `emp_daparam` INT(12), `emp_taparam` INT(12), `emp_hraparam` INT(12), `emp_maparam` INT(12), `emp_bonusparam` INT(12), `emp_pfparam` INT(12), `emp_ptparam` INT(12), `emp_grossparam` INT(12), `emp_total_salaryparam` INT(12))   BEGIN
    insert into employee_salary_details values (transaction_idparam,emp_idparam,emp_salary_monthparam, emp_salary_yearparam,emp_salary_eimbursmentparam,emp_dept_idparam,emp_grade_idparam,emp_basicparam,emp_daparam,emp_taparam,emp_hraparam,emp_maparam,emp_bonusparam,emp_pfparam,emp_ptparam,emp_grossparam,emp_total_salaryparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertgrade` (IN `grade_idparam` INT(12), `grade_nameparam` VARCHAR(25), `grade_short_nameparam` VARCHAR(25), `grade_basicparam` INT(12), `grade_taparam` INT(12), `grade_daparam` INT(12), `grade_hraparam` INT(12), `grade_maparam` INT(12), `grade_bonusparam` INT(12), `grade_pfparam` INT(12), `grade_ptparam` INT(25))   BEGIN
    insert into grade values (grade_idparam, grade_nameparam, grade_short_nameparam, grade_basicparam,grade_taparam ,grade_daparam, grade_hraparam,grade_maparam ,grade_bonusparam, grade_pfparam, grade_ptparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertuser` (IN `user_idparam` INT(12), `user_nameparam` VARCHAR(25), `passwordparam` VARCHAR(25), `email_idparam` VARCHAR(25), `user_typeparam` VARCHAR(25))   BEGIN
    insert into user values (user_idparam,user_nameparam,passwordparam,email_idparam ,user_typeparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updategrade` (IN `grade_idParam` INT(12))   BEGIN
    update grade set grade_da=20000 where grade_id= grade_idParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateuser` (IN `user_idParam` INT(12))   BEGIN
    update user set password=00022 where user_id=12;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(25) NOT NULL,
  `dept_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `dept_name`) VALUES
(1, 'finance'),
(3, 'HRM'),
(4, 'procurement'),
(5, 'innovation and creativity'),
(44, 'Auditing');

-- --------------------------------------------------------

--
-- Stand-in structure for view `details_on_grade`
-- (See below for the actual view)
--
CREATE TABLE `details_on_grade` (
`transaction_id` int(12)
,`emp_id` int(12)
,`emp_dept` int(12)
,`emp_grade` int(12)
,`emp_from_date` date
,`emp_to_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `details_on_salaries`
-- (See below for the actual view)
--
CREATE TABLE `details_on_salaries` (
`transaction_id` int(12)
,`emp_id` int(12)
,`emp_salary_month` varchar(25)
,`emp_salary_year` varchar(25)
,`emp_salary_eimbursment` datetime
,`emp_dept_id` int(12)
,`emp_grade_id` int(12)
,`emp_basic` int(12)
,`emp_da` int(12)
,`emp_ta` int(12)
,`emp_hra` int(12)
,`emp_ma` int(12)
,`emp_bonus` int(12)
,`emp_pf` int(12)
,`emp_pt` int(12)
,`emp_gross` int(12)
,`emp_total_salary` int(12)
);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(12) NOT NULL,
  `emp_title` varchar(25) NOT NULL,
  `emp_name` varchar(25) NOT NULL,
  `emp_dob` date NOT NULL,
  `emp_doj` date NOT NULL,
  `emp_address` varchar(25) NOT NULL,
  `emp_city` varchar(25) NOT NULL,
  `emp_pincode` int(15) NOT NULL,
  `emp_mobile_no` int(15) NOT NULL,
  `emp_state` varchar(25) NOT NULL,
  `emp_mail_id` varchar(25) NOT NULL,
  `emp_pan_no` varchar(25) NOT NULL,
  `emp_upload_pan` varchar(25) NOT NULL,
  `dept_id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `emp_title`, `emp_name`, `emp_dob`, `emp_doj`, `emp_address`, `emp_city`, `emp_pincode`, `emp_mobile_no`, `emp_state`, `emp_mail_id`, `emp_pan_no`, `emp_upload_pan`, `dept_id`) VALUES
(1, 'admin', 'habakubaho fidele', '0000-00-00', '2017-06-05', 'ntarama-bugesera', 'nyamata', 0, 789831961, 'rwanda', 'hafidele9@gmail.com', '00000', '', 0),
(2, 'supervisor', 'nshuti eric', '2019-06-09', '2021-09-13', 'huye', 'huye', 0, 784698008, 'rwanda', 'eric12@gamail.com', '00000', '', 0),
(44, 'Auditor', 'cyiza jeph', '2020-06-08', '2000-06-18', 'ntarama-bugesera', 'nyamata', 0, 789001961, 'rwanda', 'cyiza9@gmail.com', '00000', '', 0),
(56, 'supervisor', 'junior rumaga', '1998-11-26', '1899-08-22', 'nyagatare', 'nyagatare', 0, 788931961, 'rwanda', '[value-11]', 'rumaga1@gmail.com', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee_grade_details`
--

CREATE TABLE `employee_grade_details` (
  `transaction_id` int(12) NOT NULL,
  `emp_id` int(12) NOT NULL,
  `emp_dept` int(12) NOT NULL,
  `emp_grade` int(12) NOT NULL,
  `emp_from_date` date NOT NULL,
  `emp_to_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_grade_details`
--

INSERT INTO `employee_grade_details` (`transaction_id`, `emp_id`, `emp_dept`, `emp_grade`, `emp_from_date`, `emp_to_date`) VALUES
(1, 3, 5, 3, '2021-06-08', '2022-07-24'),
(6, 13, 5, 0, '2011-02-22', '2022-08-01'),
(7, 21, 9, 2, '2020-06-08', '2022-08-25'),
(12, 33, 5, 3, '2021-06-08', '2022-07-24');

-- --------------------------------------------------------

--
-- Table structure for table `employee_salary_details`
--

CREATE TABLE `employee_salary_details` (
  `transaction_id` int(12) NOT NULL,
  `emp_id` int(12) NOT NULL,
  `emp_salary_month` varchar(25) NOT NULL,
  `emp_salary_year` varchar(25) NOT NULL,
  `emp_salary_eimbursment` datetime NOT NULL,
  `emp_dept_id` int(12) NOT NULL,
  `emp_grade_id` int(12) NOT NULL,
  `emp_basic` int(12) NOT NULL,
  `emp_da` int(12) NOT NULL,
  `emp_ta` int(12) NOT NULL,
  `emp_hra` int(12) NOT NULL,
  `emp_ma` int(12) NOT NULL,
  `emp_bonus` int(12) NOT NULL,
  `emp_pf` int(12) NOT NULL,
  `emp_pt` int(12) NOT NULL,
  `emp_gross` int(12) NOT NULL,
  `emp_total_salary` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_salary_details`
--

INSERT INTO `employee_salary_details` (`transaction_id`, `emp_id`, `emp_salary_month`, `emp_salary_year`, `emp_salary_eimbursment`, `emp_dept_id`, `emp_grade_id`, `emp_basic`, `emp_da`, `emp_ta`, `emp_hra`, `emp_ma`, `emp_bonus`, `emp_pf`, `emp_pt`, `emp_gross`, `emp_total_salary`) VALUES
(2, 34, 'june', '2022', '2022-07-18 00:29:59', 5, 76, 500000, 40000, 34000, 98000, 52000, 100200, 70000, 43000, 897000, 765300),
(11, 15, 'may', '2018', '0000-00-00 00:00:00', 11, 15, 300000, 40000, 42000, 53500, 31000, 100000, 21000, 31000, 645000, 486000),
(27, 31, 'may', '2022', '2022-07-18 00:29:59', 14, 13, 30000, 120000, 125300, 310000, 67000, 296000, 23700, 12300, 835000, 647500),
(98, 21, 'SEPT', '1999', '2021-07-12 12:33:16', 67, 34, 120000, 50000, 10000, 76000, 33000, 500000, 28000, 96000, 895000, 693000);

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `grade_id` int(12) NOT NULL,
  `grade_name` varchar(25) NOT NULL,
  `grade_short_name` varchar(25) NOT NULL,
  `grade_basic` int(25) NOT NULL,
  `grade_ta` int(25) NOT NULL,
  `grade_da` int(25) NOT NULL,
  `grade_hra` int(25) NOT NULL,
  `grade_ma` int(25) NOT NULL,
  `grade_bonus` int(25) NOT NULL,
  `grade_pf` int(25) NOT NULL,
  `grade_pt` int(25) NOT NULL,
  `dept_id` int(12) NOT NULL,
  `transaction_id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`grade_id`, `grade_name`, `grade_short_name`, `grade_basic`, `grade_ta`, `grade_da`, `grade_hra`, `grade_ma`, `grade_bonus`, `grade_pf`, `grade_pt`, `dept_id`, `transaction_id`) VALUES
(1, 'seniors', 's', 1000000, 20000, 20000, 320000, 70000, 370000, 146500, 98000, 0, 0),
(2, 'runnerup', 'r', 700000, 15000, 15000, 120000, 50000, 180000, 57900, 75400, 0, 0),
(67, 'seniors', 's', 1000000, 20000, 20000, 320000, 70000, 370000, 146500, 98000, 0, 0);

--
-- Triggers `grade`
--
DELIMITER $$
CREATE TRIGGER `after_grade_insert` AFTER INSERT ON `grade` FOR EACH ROW BEGIN
        INSERT INTO grade(grade_id,grade_name,grade_short_name,grade_basic,grade_ta,
          grade_da,grade_hra,grade_ma,grade_bonus,grade_pf,grade_pt)
        VALUES(6,'sinior','s',500000,70000,20000,360000,120000,300000,135000,780000);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_grade_update` AFTER UPDATE ON `grade` FOR EACH ROW BEGIN
       UPDATE user SET grade_name='bignner'WHERE grade_id=6;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `level`
-- (See below for the actual view)
--
CREATE TABLE `level` (
`grade_id` int(12)
,`grade_name` varchar(25)
,`grade_short_name` varchar(25)
,`grade_basic` int(25)
,`grade_ta` int(25)
,`grade_da` int(25)
,`grade_hra` int(25)
,`grade_ma` int(25)
,`grade_bonus` int(25)
,`grade_pf` int(25)
,`grade_pt` int(25)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_departments`
-- (See below for the actual view)
--
CREATE TABLE `list_of_departments` (
`dept_id` int(25)
,`dept_name` varchar(25)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_employee`
-- (See below for the actual view)
--
CREATE TABLE `list_of_employee` (
`emp_id` int(12)
,`emp_title` varchar(25)
,`emp_name` varchar(25)
,`emp_dob` date
,`emp_doj` date
,`emp_address` varchar(25)
,`emp_city` varchar(25)
,`emp_pincode` int(15)
,`emp_mobile_no` int(15)
,`emp_state` varchar(25)
,`emp_mail_id` varchar(25)
,`emp_pan_no` varchar(25)
,`emp_upload_pan` varchar(25)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `transactions`
-- (See below for the actual view)
--
CREATE TABLE `transactions` (
`user_id` int(25)
,`user_name` varchar(25)
,`password` varchar(25)
,`email_id` varchar(25)
,`user_type` varchar(25)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(25) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `email_id` varchar(25) NOT NULL,
  `user_type` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `password`, `email_id`, `user_type`) VALUES
(1, 'habakubaho fidele', '00001', 'hafidele9@gmail.com', 'admin'),
(2, 'nshuti eric', '0000', 'eric2@gmail.com', 'supervisor'),
(3, 'kadahumeka henry', '00111', 'kadahumeka2@gmail', 'techinician');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `after_user_insert` AFTER INSERT ON `user` FOR EACH ROW BEGIN
        INSERT INTO user(user_idId,user_name,password,email_id,user_type)
        VALUES(77,'mbogo ally','00333','mbogo@gmail.com','worker');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_user_update` AFTER UPDATE ON `user` FOR EACH ROW BEGIN
       UPDATE user SET grade_name='bignner'WHERE grade_id=6;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `details_on_grade`
--
DROP TABLE IF EXISTS `details_on_grade`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `details_on_grade`  AS SELECT `employee_grade_details`.`transaction_id` AS `transaction_id`, `employee_grade_details`.`emp_id` AS `emp_id`, `employee_grade_details`.`emp_dept` AS `emp_dept`, `employee_grade_details`.`emp_grade` AS `emp_grade`, `employee_grade_details`.`emp_from_date` AS `emp_from_date`, `employee_grade_details`.`emp_to_date` AS `emp_to_date` FROM `employee_grade_details``employee_grade_details`  ;

-- --------------------------------------------------------

--
-- Structure for view `details_on_salaries`
--
DROP TABLE IF EXISTS `details_on_salaries`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `details_on_salaries`  AS SELECT `employee_salary_details`.`transaction_id` AS `transaction_id`, `employee_salary_details`.`emp_id` AS `emp_id`, `employee_salary_details`.`emp_salary_month` AS `emp_salary_month`, `employee_salary_details`.`emp_salary_year` AS `emp_salary_year`, `employee_salary_details`.`emp_salary_eimbursment` AS `emp_salary_eimbursment`, `employee_salary_details`.`emp_dept_id` AS `emp_dept_id`, `employee_salary_details`.`emp_grade_id` AS `emp_grade_id`, `employee_salary_details`.`emp_basic` AS `emp_basic`, `employee_salary_details`.`emp_da` AS `emp_da`, `employee_salary_details`.`emp_ta` AS `emp_ta`, `employee_salary_details`.`emp_hra` AS `emp_hra`, `employee_salary_details`.`emp_ma` AS `emp_ma`, `employee_salary_details`.`emp_bonus` AS `emp_bonus`, `employee_salary_details`.`emp_pf` AS `emp_pf`, `employee_salary_details`.`emp_pt` AS `emp_pt`, `employee_salary_details`.`emp_gross` AS `emp_gross`, `employee_salary_details`.`emp_total_salary` AS `emp_total_salary` FROM `employee_salary_details``employee_salary_details`  ;

-- --------------------------------------------------------

--
-- Structure for view `level`
--
DROP TABLE IF EXISTS `level`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `level`  AS SELECT `grade`.`grade_id` AS `grade_id`, `grade`.`grade_name` AS `grade_name`, `grade`.`grade_short_name` AS `grade_short_name`, `grade`.`grade_basic` AS `grade_basic`, `grade`.`grade_ta` AS `grade_ta`, `grade`.`grade_da` AS `grade_da`, `grade`.`grade_hra` AS `grade_hra`, `grade`.`grade_ma` AS `grade_ma`, `grade`.`grade_bonus` AS `grade_bonus`, `grade`.`grade_pf` AS `grade_pf`, `grade`.`grade_pt` AS `grade_pt` FROM `grade``grade`  ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_departments`
--
DROP TABLE IF EXISTS `list_of_departments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_departments`  AS SELECT `department`.`dept_id` AS `dept_id`, `department`.`dept_name` AS `dept_name` FROM `department``department`  ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_employee`
--
DROP TABLE IF EXISTS `list_of_employee`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_employee`  AS SELECT `employee`.`emp_id` AS `emp_id`, `employee`.`emp_title` AS `emp_title`, `employee`.`emp_name` AS `emp_name`, `employee`.`emp_dob` AS `emp_dob`, `employee`.`emp_doj` AS `emp_doj`, `employee`.`emp_address` AS `emp_address`, `employee`.`emp_city` AS `emp_city`, `employee`.`emp_pincode` AS `emp_pincode`, `employee`.`emp_mobile_no` AS `emp_mobile_no`, `employee`.`emp_state` AS `emp_state`, `employee`.`emp_mail_id` AS `emp_mail_id`, `employee`.`emp_pan_no` AS `emp_pan_no`, `employee`.`emp_upload_pan` AS `emp_upload_pan` FROM `employee``employee`  ;

-- --------------------------------------------------------

--
-- Structure for view `transactions`
--
DROP TABLE IF EXISTS `transactions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transactions`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`user_name` AS `user_name`, `user`.`password` AS `password`, `user`.`email_id` AS `email_id`, `user`.`user_type` AS `user_type` FROM `user``user`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `employee_grade_details`
--
ALTER TABLE `employee_grade_details`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `emp_id` (`emp_id`);

--
-- Indexes for table `employee_salary_details`
--
ALTER TABLE `employee_salary_details`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`grade_id`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `employee_grade_details`
--
ALTER TABLE `employee_grade_details`
  MODIFY `transaction_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `employee_salary_details`
--
ALTER TABLE `employee_salary_details`
  MODIFY `transaction_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
