-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 11:12 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gahuzamiryango_jean_de_dieu`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletcourse` (IN `Course_idparam` VARCHAR(30))  BEGIN
    Delete from course where Course_id=Course_idparam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deletecourse` (IN `Course_idParam` VARCHAR(30))  BEGIN
    delete from course where Course_id=Course_idparam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteenrollement` (IN `enroll_idparam` VARCHAR(30))  BEGIN
    delete from enrollement where enroll_id=enroll_idparam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertcombination` (IN `Combination_idParam` VARCHAR(30))  BEGIN
    update combination set Academic_year=2023 where Combination_id=Combination_idParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertemployee` ()  BEGIN
    select * from employee;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertenrollement` ()  BEGIN
    select * from enrollement;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertloginaccount` ()  BEGIN
    select * from login_account;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertlogin_account` (IN `Login_idparam` INT(100), `User_codeparam` VARCHAR(100), `passwordParam` VARCHAR(150))  BEGIN
    insert into login_account values (Login_idparam, User_codeparam,passwordParam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertmarks` ()  BEGIN
    select * from marks;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertportifolio` (IN `Mark_idparam` VARCHAR(30))  BEGIN
    update combination set Academic_year=2 where Mark_id_id=Mark_idparam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertstudent_registered` ()  BEGIN
    select * from student_registered;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `combination`
--

CREATE TABLE `combination` (
  `Combination_id` int(100) NOT NULL,
  `Combination_name` varchar(100) NOT NULL,
  `User_code` int(100) DEFAULT NULL,
  `Academic_year` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `combination`
--

INSERT INTO `combination` (`Combination_id`, `Combination_name`, `User_code`, `Academic_year`) VALUES
(1, 'SOFTWARE DEVELOPMENT', 1, 2023),
(2, 'NETWORKING', 2, 2020),
(3, 'MCB', 2, 2020),
(4, 'networking', 2, 2022);

--
-- Triggers `combination`
--
DELIMITER $$
CREATE TRIGGER `insertcombination` AFTER INSERT ON `combination` FOR EACH ROW BEGIN  
INSERT INTO combination VALUES (NULL, 'SOFTWARE DEVELOPMENT', '1', '2020'); 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updatecombination` AFTER UPDATE ON `combination` FOR EACH ROW BEGIN  
update counters set Academic_year=Academic_year+1; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `Course_id` int(100) NOT NULL,
  `Course_name` varchar(100) NOT NULL,
  `Course_credits` int(50) DEFAULT NULL,
  `Employee_id` int(100) DEFAULT NULL,
  `User_code` int(100) DEFAULT NULL,
  `Total_assessments` int(100) DEFAULT NULL,
  `Exam` int(100) DEFAULT NULL,
  `Total` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`Course_id`, `Course_name`, `Course_credits`, `Employee_id`, `User_code`, `Total_assessments`, `Exam`, `Total`) VALUES
(1, 'DATABASE TECHNOLOGY', 75, 1, 1, 80, 86, 83),
(2, 'DATABASE TECHNOLOGY', 75, 1, 2, 70, 78, 74),
(3, 'CARPENTARY', 75, 3, 3, 90, 90, 90);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_id` int(100) NOT NULL,
  `Employee_firstname` varchar(100) NOT NULL,
  `Employee_lastname` varchar(100) DEFAULT NULL,
  `Employee_role` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Telephone` int(100) DEFAULT NULL,
  `Employee_address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_id`, `Employee_firstname`, `Employee_lastname`, `Employee_role`, `Email`, `Telephone`, `Employee_address`) VALUES
(1, 'KALISA', 'Joseph', 'Teacher', 'kalisa@gmail.com', 787994855, 'RULINDO'),
(2, 'KABATESI', 'Marie', 'Secrterait', 'uwase@gmail.com', 784332503, 'MUSANZE'),
(3, 'RWEMA', 'Jado', 'Headteacher', 'rwema@gmail.com', 787994855, 'KICUKIRO'),
(4, 'Audi', 'Sharp', 'manager', 'audi@gmail.coom', 784332503, 'huye');

-- --------------------------------------------------------

--
-- Table structure for table `enrollement`
--

CREATE TABLE `enrollement` (
  `enroll_id` int(100) NOT NULL,
  `User_code` int(100) NOT NULL,
  `Course_id` int(100) DEFAULT NULL,
  `Employee_id` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enrollement`
--

INSERT INTO `enrollement` (`enroll_id`, `User_code`, `Course_id`, `Employee_id`) VALUES
(1, 2, 1, 1),
(2, 1, 2, 2),
(3, 2, 1, 4);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listaccounts`
-- (See below for the actual view)
--
CREATE TABLE `listaccounts` (
`Login_id` int(100)
,`User_code` int(100)
,`password` varchar(150)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listcombination`
-- (See below for the actual view)
--
CREATE TABLE `listcombination` (
`Combination_id` int(100)
,`Combination_name` varchar(100)
,`User_code` int(100)
,`Academic_year` int(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listcourse`
-- (See below for the actual view)
--
CREATE TABLE `listcourse` (
`Course_id` int(100)
,`Course_name` varchar(100)
,`Course_credits` int(50)
,`Employee_id` int(100)
,`User_code` int(100)
,`Total_assessments` int(100)
,`Exam` int(100)
,`Total` int(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listemployee`
-- (See below for the actual view)
--
CREATE TABLE `listemployee` (
`Employee_id` int(100)
,`Employee_firstname` varchar(100)
,`Employee_lastname` varchar(100)
,`Employee_role` varchar(100)
,`Email` varchar(100)
,`Telephone` int(100)
,`Employee_address` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listmarks`
-- (See below for the actual view)
--
CREATE TABLE `listmarks` (
`Mark_id` int(100)
,`User_code` int(100)
,`Employee_id` int(100)
,`Updated_date` date
,`Course_id` int(100)
,`Combination_id` int(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listpayment`
-- (See below for the actual view)
--
CREATE TABLE `listpayment` (
`Pay_id` int(100)
,`User_code` int(100)
,`payed_date` date
,`Amount` int(100)
,`Momo_account` int(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listportifolio`
-- (See below for the actual view)
--
CREATE TABLE `listportifolio` (
`port_id` int(50)
,`User_code` int(100)
,`Internaship_documents` varchar(100)
,`Discipline_document` varchar(50)
,`Mark_id` int(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listschool`
-- (See below for the actual view)
--
CREATE TABLE `listschool` (
`School_id` int(100)
,`School_name` varchar(100)
,`Head_school` varchar(40)
,`School_address_province` varchar(100)
,`School_address_district` varchar(100)
,`School_address_sector` varchar(100)
,`School_address_cell` varchar(100)
,`Email` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `liststudents`
-- (See below for the actual view)
--
CREATE TABLE `liststudents` (
`User_code` int(100)
,`Firstname` varchar(100)
,`Lastname` varchar(100)
,`Gender` varchar(10)
,`Birth_date` date
,`Student_orgins` varchar(20)
,`Guardian_names` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `login_account`
--

CREATE TABLE `login_account` (
  `Login_id` int(100) NOT NULL,
  `User_code` int(100) NOT NULL,
  `password` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_account`
--

INSERT INTO `login_account` (`Login_id`, `User_code`, `password`) VALUES
(9, 1, '1111111111'),
(10, 2, 'Sharp');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `Mark_id` int(100) NOT NULL,
  `User_code` int(100) NOT NULL,
  `Employee_id` int(100) DEFAULT NULL,
  `Updated_date` date DEFAULT NULL,
  `Course_id` int(100) DEFAULT NULL,
  `Combination_id` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`Mark_id`, `User_code`, `Employee_id`, `Updated_date`, `Course_id`, `Combination_id`) VALUES
(1, 1, 2, '2022-07-30', 1, 1),
(2, 2, 1, '2022-07-22', 2, 2),
(3, 2, 2, '2022-07-29', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Pay_id` int(100) NOT NULL,
  `User_code` int(100) NOT NULL,
  `payed_date` date DEFAULT NULL,
  `Amount` int(100) DEFAULT NULL,
  `Momo_account` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Pay_id`, `User_code`, `payed_date`, `Amount`, `Momo_account`) VALUES
(2, 2, '2022-07-23', 100000, 784332503),
(3, 2, '2022-07-29', 98000, 787994855);

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `insertpayment` AFTER INSERT ON `payment` FOR EACH ROW BEGIN  
update counters set Amount=Amount+100; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updatepayment` AFTER UPDATE ON `payment` FOR EACH ROW BEGIN  
update counters set Amount=Amount+100; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `portifolio`
--

CREATE TABLE `portifolio` (
  `port_id` int(50) NOT NULL,
  `User_code` int(100) NOT NULL,
  `Internaship_documents` varchar(100) NOT NULL,
  `Discipline_document` varchar(50) NOT NULL,
  `Mark_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `portifolio`
--

INSERT INTO `portifolio` (`port_id`, `User_code`, `Internaship_documents`, `Discipline_document`, `Mark_id`) VALUES
(1, 1, 'LINK', 'LINK', 1),
(2, 2, 'LINK', 'LINK', 2),
(3, 2, 'LINK', 'LINK', 2),
(4, 2, 'ghj', 'jjk', 3);

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `School_id` int(100) NOT NULL,
  `School_name` varchar(100) NOT NULL,
  `Head_school` varchar(40) DEFAULT NULL,
  `School_address_province` varchar(100) DEFAULT NULL,
  `School_address_district` varchar(100) DEFAULT NULL,
  `School_address_sector` varchar(100) DEFAULT NULL,
  `School_address_cell` varchar(100) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`School_id`, `School_name`, `Head_school`, `School_address_province`, `School_address_district`, `School_address_sector`, `School_address_cell`, `Email`) VALUES
(2, 'CSAMZ', 'BISIMWA Biemvenue', 'NORTHERN', 'GICUMBI', 'MUKO', 'KARUNDI', 'csamz@gmail.com'),
(3, 'MUKONO', 'MUNEZA Richard', 'WEST', 'KARONGI', 'MUSEBEYA', 'MUSEBEYA', 'mukono@gmail.com');

--
-- Triggers `school`
--
DELIMITER $$
CREATE TRIGGER `insertschool` AFTER INSERT ON `school` FOR EACH ROW BEGIN  
update counters set School_name='MINEDUC'; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `student_registered`
--

CREATE TABLE `student_registered` (
  `User_code` int(100) NOT NULL,
  `Firstname` varchar(100) DEFAULT NULL,
  `Lastname` varchar(100) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Birth_date` date DEFAULT NULL,
  `Student_orgins` varchar(20) DEFAULT NULL,
  `Guardian_names` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_registered`
--

INSERT INTO `student_registered` (`User_code`, `Firstname`, `Lastname`, `Gender`, `Birth_date`, `Student_orgins`, `Guardian_names`) VALUES
(1, 'MUGISHA', 'Gabriel', 'M', '2010-07-18', 'GASABO', 'MURENZI Patric'),
(2, 'KASANDE', 'Jolly', 'F', '2015-10-20', 'GATSIBO', 'BERWA JMV'),
(3, 'MUPENZI', 'Hertier', 'M', '2000-07-21', 'GISENYI', 'NZANIRA'),
(4, 'Audi', 'Sharp', 'manager', '0000-00-00', '784332503', 'huye');

-- --------------------------------------------------------

--
-- Structure for view `listaccounts`
--
DROP TABLE IF EXISTS `listaccounts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listaccounts`  AS  select `login_account`.`Login_id` AS `Login_id`,`login_account`.`User_code` AS `User_code`,`login_account`.`password` AS `password` from `login_account` ;

-- --------------------------------------------------------

--
-- Structure for view `listcombination`
--
DROP TABLE IF EXISTS `listcombination`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listcombination`  AS  select `combination`.`Combination_id` AS `Combination_id`,`combination`.`Combination_name` AS `Combination_name`,`combination`.`User_code` AS `User_code`,`combination`.`Academic_year` AS `Academic_year` from `combination` ;

-- --------------------------------------------------------

--
-- Structure for view `listcourse`
--
DROP TABLE IF EXISTS `listcourse`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listcourse`  AS  select `course`.`Course_id` AS `Course_id`,`course`.`Course_name` AS `Course_name`,`course`.`Course_credits` AS `Course_credits`,`course`.`Employee_id` AS `Employee_id`,`course`.`User_code` AS `User_code`,`course`.`Total_assessments` AS `Total_assessments`,`course`.`Exam` AS `Exam`,`course`.`Total` AS `Total` from `course` ;

-- --------------------------------------------------------

--
-- Structure for view `listemployee`
--
DROP TABLE IF EXISTS `listemployee`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listemployee`  AS  select `employee`.`Employee_id` AS `Employee_id`,`employee`.`Employee_firstname` AS `Employee_firstname`,`employee`.`Employee_lastname` AS `Employee_lastname`,`employee`.`Employee_role` AS `Employee_role`,`employee`.`Email` AS `Email`,`employee`.`Telephone` AS `Telephone`,`employee`.`Employee_address` AS `Employee_address` from `employee` ;

-- --------------------------------------------------------

--
-- Structure for view `listmarks`
--
DROP TABLE IF EXISTS `listmarks`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listmarks`  AS  select `marks`.`Mark_id` AS `Mark_id`,`marks`.`User_code` AS `User_code`,`marks`.`Employee_id` AS `Employee_id`,`marks`.`Updated_date` AS `Updated_date`,`marks`.`Course_id` AS `Course_id`,`marks`.`Combination_id` AS `Combination_id` from `marks` ;

-- --------------------------------------------------------

--
-- Structure for view `listpayment`
--
DROP TABLE IF EXISTS `listpayment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listpayment`  AS  select `payment`.`Pay_id` AS `Pay_id`,`payment`.`User_code` AS `User_code`,`payment`.`payed_date` AS `payed_date`,`payment`.`Amount` AS `Amount`,`payment`.`Momo_account` AS `Momo_account` from `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `listportifolio`
--
DROP TABLE IF EXISTS `listportifolio`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listportifolio`  AS  select `portifolio`.`port_id` AS `port_id`,`portifolio`.`User_code` AS `User_code`,`portifolio`.`Internaship_documents` AS `Internaship_documents`,`portifolio`.`Discipline_document` AS `Discipline_document`,`portifolio`.`Mark_id` AS `Mark_id` from `portifolio` ;

-- --------------------------------------------------------

--
-- Structure for view `listschool`
--
DROP TABLE IF EXISTS `listschool`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listschool`  AS  select `school`.`School_id` AS `School_id`,`school`.`School_name` AS `School_name`,`school`.`Head_school` AS `Head_school`,`school`.`School_address_province` AS `School_address_province`,`school`.`School_address_district` AS `School_address_district`,`school`.`School_address_sector` AS `School_address_sector`,`school`.`School_address_cell` AS `School_address_cell`,`school`.`Email` AS `Email` from `school` ;

-- --------------------------------------------------------

--
-- Structure for view `liststudents`
--
DROP TABLE IF EXISTS `liststudents`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `liststudents`  AS  select `student_registered`.`User_code` AS `User_code`,`student_registered`.`Firstname` AS `Firstname`,`student_registered`.`Lastname` AS `Lastname`,`student_registered`.`Gender` AS `Gender`,`student_registered`.`Birth_date` AS `Birth_date`,`student_registered`.`Student_orgins` AS `Student_orgins`,`student_registered`.`Guardian_names` AS `Guardian_names` from `student_registered` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `combination`
--
ALTER TABLE `combination`
  ADD PRIMARY KEY (`Combination_id`),
  ADD KEY `student_registered_combination` (`User_code`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`Course_id`),
  ADD UNIQUE KEY `User_code_2` (`User_code`),
  ADD KEY `employee_course` (`Employee_id`),
  ADD KEY `User_code` (`User_code`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_id`);

--
-- Indexes for table `enrollement`
--
ALTER TABLE `enrollement`
  ADD PRIMARY KEY (`enroll_id`),
  ADD KEY `employee_enrollement` (`Employee_id`),
  ADD KEY `course_enrollement` (`Course_id`),
  ADD KEY `student_registered_enrollement` (`User_code`);

--
-- Indexes for table `login_account`
--
ALTER TABLE `login_account`
  ADD PRIMARY KEY (`Login_id`),
  ADD KEY `student_registered_login_account` (`User_code`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`Mark_id`),
  ADD KEY `student_registered_marks` (`User_code`),
  ADD KEY `course_marks` (`Course_id`),
  ADD KEY `combination_marks` (`Combination_id`),
  ADD KEY `employee_id` (`Employee_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Pay_id`),
  ADD KEY `student_registered_payment` (`User_code`);

--
-- Indexes for table `portifolio`
--
ALTER TABLE `portifolio`
  ADD PRIMARY KEY (`port_id`),
  ADD KEY `student_registered_portifolio` (`User_code`),
  ADD KEY `marks_portifolio` (`Mark_id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`School_id`);

--
-- Indexes for table `student_registered`
--
ALTER TABLE `student_registered`
  ADD PRIMARY KEY (`User_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `combination`
--
ALTER TABLE `combination`
  MODIFY `Combination_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `Course_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Employee_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `enrollement`
--
ALTER TABLE `enrollement`
  MODIFY `enroll_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `login_account`
--
ALTER TABLE `login_account`
  MODIFY `Login_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `Mark_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Pay_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `portifolio`
--
ALTER TABLE `portifolio`
  MODIFY `port_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `School_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `student_registered`
--
ALTER TABLE `student_registered`
  MODIFY `User_code` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `combination`
--
ALTER TABLE `combination`
  ADD CONSTRAINT `student_registered_combination` FOREIGN KEY (`User_code`) REFERENCES `student_registered` (`User_code`);

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `employee_course` FOREIGN KEY (`Employee_id`) REFERENCES `employee` (`Employee_id`),
  ADD CONSTRAINT `student_registered_course` FOREIGN KEY (`User_code`) REFERENCES `student_registered` (`User_code`);

--
-- Constraints for table `enrollement`
--
ALTER TABLE `enrollement`
  ADD CONSTRAINT `course_enrollement` FOREIGN KEY (`Course_id`) REFERENCES `course` (`Course_id`),
  ADD CONSTRAINT `employee_enrollement` FOREIGN KEY (`Employee_id`) REFERENCES `employee` (`Employee_id`),
  ADD CONSTRAINT `student_registered_enrollement` FOREIGN KEY (`User_code`) REFERENCES `student_registered` (`User_code`);

--
-- Constraints for table `login_account`
--
ALTER TABLE `login_account`
  ADD CONSTRAINT `student_registered_login_account` FOREIGN KEY (`User_code`) REFERENCES `student_registered` (`User_code`);

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `combination_marks` FOREIGN KEY (`Combination_id`) REFERENCES `combination` (`Combination_id`),
  ADD CONSTRAINT `course_marks` FOREIGN KEY (`Course_id`) REFERENCES `course` (`Course_id`),
  ADD CONSTRAINT `student_registered_marks` FOREIGN KEY (`User_code`) REFERENCES `student_registered` (`User_code`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `student_registered_payment` FOREIGN KEY (`User_code`) REFERENCES `student_registered` (`User_code`);

--
-- Constraints for table `portifolio`
--
ALTER TABLE `portifolio`
  ADD CONSTRAINT `marks_portifolio` FOREIGN KEY (`Mark_id`) REFERENCES `marks` (`Mark_id`),
  ADD CONSTRAINT `student_registered_portifolio` FOREIGN KEY (`User_code`) REFERENCES `student_registered` (`User_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
