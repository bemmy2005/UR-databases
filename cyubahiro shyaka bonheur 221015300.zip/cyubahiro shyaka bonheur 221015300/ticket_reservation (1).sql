-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 07:15 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket_reservation`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `available_bus`
-- (See below for the actual view)
--
CREATE TABLE `available_bus` (
`bus_id` varchar(10)
,`bus_name` varchar(20)
,`bus_plate_number` varchar(15)
,`bus_seat_number` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `available_seats`
-- (See below for the actual view)
--
CREATE TABLE `available_seats` (
`seat_id` varchar(10)
,`seat_bus_id` varchar(20)
,`seat_passenger_id` varchar(15)
,`seat_type` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `bus_id` varchar(10) DEFAULT NULL,
  `bus_name` varchar(20) DEFAULT NULL,
  `bus_plate_number` varchar(15) NOT NULL,
  `bus_seat_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`bus_id`, `bus_name`, `bus_plate_number`, `bus_seat_number`) VALUES
('16', 'toyota bus', 'RAB 456 b', 29);

-- --------------------------------------------------------

--
-- Table structure for table `bus_route`
--

CREATE TABLE `bus_route` (
  `bus_router_id` varchar(10) NOT NULL,
  `bus_route_name` varchar(20) NOT NULL,
  `bus_route_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bus_route`
--

INSERT INTO `bus_route` (`bus_router_id`, `bus_route_name`, `bus_route_type`) VALUES
('32', 'kigali_nyamagabe', 'tarmaric');

-- --------------------------------------------------------

--
-- Stand-in structure for view `info_route`
-- (See below for the actual view)
--
CREATE TABLE `info_route` (
`bus_router_id` varchar(10)
,`bus_route_name` varchar(20)
,`bus_route_type` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `info_ticket`
-- (See below for the actual view)
--
CREATE TABLE `info_ticket` (
`ticket_booking_id` varchar(10)
,`passenger_id` varchar(15)
,`ticket_booking_type` varchar(20)
,`ticket_booking_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_passengers`
-- (See below for the actual view)
--
CREATE TABLE `list_of_passengers` (
`passenger_id` varchar(10)
,`passenger_name` varchar(20)
,`passenger_mobile` varchar(15)
,`passenger_email` varchar(30)
,`passenger_username` varchar(30)
,`passenger_password` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `passenger_id` varchar(10) NOT NULL,
  `passenger_name` varchar(20) DEFAULT NULL,
  `passenger_mobile` varchar(15) DEFAULT NULL,
  `passenger_email` varchar(30) DEFAULT NULL,
  `passenger_username` varchar(30) DEFAULT NULL,
  `passenger_password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`passenger_id`, `passenger_name`, `passenger_mobile`, `passenger_email`, `passenger_username`, `passenger_password`) VALUES
('2234', 'sano yves', '+250786545346', 'yves@gmail.com', 'ironside', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `seat`
--

CREATE TABLE `seat` (
  `seat_id` varchar(10) NOT NULL,
  `seat_bus_id` varchar(20) NOT NULL,
  `seat_passenger_id` varchar(15) NOT NULL,
  `seat_type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seat`
--

INSERT INTO `seat` (`seat_id`, `seat_bus_id`, `seat_passenger_id`, `seat_type`) VALUES
('178', '16', '2234', 'double');

-- --------------------------------------------------------

--
-- Stand-in structure for view `subqueriesview`
-- (See below for the actual view)
--
CREATE TABLE `subqueriesview` (
`seat_id` varchar(10)
,`seat_bus_id` varchar(20)
,`seat_passenger_id` varchar(15)
,`seat_type` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_booking`
--

CREATE TABLE `ticket_booking` (
  `ticket_booking_id` varchar(10) NOT NULL,
  `passenger_id` varchar(15) NOT NULL,
  `ticket_booking_type` varchar(20) NOT NULL,
  `ticket_booking_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticket_booking`
--

INSERT INTO `ticket_booking` (`ticket_booking_id`, `passenger_id`, `ticket_booking_type`, `ticket_booking_date`) VALUES
('1235', '2234', 'half', '2022-08-04');

-- --------------------------------------------------------

--
-- Structure for view `available_bus`
--
DROP TABLE IF EXISTS `available_bus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `available_bus`  AS  (select `bus`.`bus_id` AS `bus_id`,`bus`.`bus_name` AS `bus_name`,`bus`.`bus_plate_number` AS `bus_plate_number`,`bus`.`bus_seat_number` AS `bus_seat_number` from `bus`) ;

-- --------------------------------------------------------

--
-- Structure for view `available_seats`
--
DROP TABLE IF EXISTS `available_seats`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `available_seats`  AS  (select `seat`.`seat_id` AS `seat_id`,`seat`.`seat_bus_id` AS `seat_bus_id`,`seat`.`seat_passenger_id` AS `seat_passenger_id`,`seat`.`seat_type` AS `seat_type` from `seat`) ;

-- --------------------------------------------------------

--
-- Structure for view `info_route`
--
DROP TABLE IF EXISTS `info_route`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `info_route`  AS  (select `bus_route`.`bus_router_id` AS `bus_router_id`,`bus_route`.`bus_route_name` AS `bus_route_name`,`bus_route`.`bus_route_type` AS `bus_route_type` from `bus_route`) ;

-- --------------------------------------------------------

--
-- Structure for view `info_ticket`
--
DROP TABLE IF EXISTS `info_ticket`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `info_ticket`  AS  (select `ticket_booking`.`ticket_booking_id` AS `ticket_booking_id`,`ticket_booking`.`passenger_id` AS `passenger_id`,`ticket_booking`.`ticket_booking_type` AS `ticket_booking_type`,`ticket_booking`.`ticket_booking_date` AS `ticket_booking_date` from `ticket_booking`) ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_passengers`
--
DROP TABLE IF EXISTS `list_of_passengers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_passengers`  AS  (select `passenger`.`passenger_id` AS `passenger_id`,`passenger`.`passenger_name` AS `passenger_name`,`passenger`.`passenger_mobile` AS `passenger_mobile`,`passenger`.`passenger_email` AS `passenger_email`,`passenger`.`passenger_username` AS `passenger_username`,`passenger`.`passenger_password` AS `passenger_password` from `passenger`) ;

-- --------------------------------------------------------

--
-- Structure for view `subqueriesview`
--
DROP TABLE IF EXISTS `subqueriesview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subqueriesview`  AS  (select `seat`.`seat_id` AS `seat_id`,`seat`.`seat_bus_id` AS `seat_bus_id`,`seat`.`seat_passenger_id` AS `seat_passenger_id`,`seat`.`seat_type` AS `seat_type` from `seat` where `seat`.`seat_passenger_id` = (select `seat`.`seat_passenger_id` from `passenger` where `seat`.`seat_passenger_id` = '2234')) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`bus_plate_number`),
  ADD UNIQUE KEY `bus_id` (`bus_id`);

--
-- Indexes for table `bus_route`
--
ALTER TABLE `bus_route`
  ADD PRIMARY KEY (`bus_router_id`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`passenger_id`);

--
-- Indexes for table `seat`
--
ALTER TABLE `seat`
  ADD PRIMARY KEY (`seat_id`),
  ADD KEY `seat_bus_id` (`seat_bus_id`),
  ADD KEY `seat_passenger_id` (`seat_passenger_id`);

--
-- Indexes for table `ticket_booking`
--
ALTER TABLE `ticket_booking`
  ADD PRIMARY KEY (`ticket_booking_id`),
  ADD KEY `passenger_id` (`passenger_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `seat`
--
ALTER TABLE `seat`
  ADD CONSTRAINT `seat_ibfk_1` FOREIGN KEY (`seat_bus_id`) REFERENCES `bus` (`bus_id`),
  ADD CONSTRAINT `seat_ibfk_2` FOREIGN KEY (`seat_passenger_id`) REFERENCES `passenger` (`passenger_id`);

--
-- Constraints for table `ticket_booking`
--
ALTER TABLE `ticket_booking`
  ADD CONSTRAINT `ticket_booking_ibfk_1` FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
