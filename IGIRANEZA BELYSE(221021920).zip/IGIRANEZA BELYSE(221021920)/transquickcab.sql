-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 01:50 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admid` int(8) NOT NULL,
  `adfname` varchar(25) NOT NULL,
  `adlname` varchar(25) NOT NULL,
  `admin_username` varchar(10) NOT NULL,
  `admin_password` varchar(10) NOT NULL,
  `adgender` varchar(6) NOT NULL,
  `adphone` decimal(10,0) NOT NULL,
  PRIMARY KEY (`admid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admid`, `adfname`, `adlname`, `admin_username`, `admin_password`, `adgender`, `adphone`) VALUES
(0, 'Bahati', 'Dieu Merci', 'dieume', 'dieu@12', 'f', '786765'),
(2, 'MBokani ', 'bahti', 'bhtcorp.', 'BHt1233', 'f', '786775');

-- --------------------------------------------------------

--
-- Stand-in structure for view `admin_view`
--
CREATE TABLE IF NOT EXISTS `admin_view` (
`admid` int(8)
,`adfname` varchar(25)
,`adlname` varchar(25)
,`admin_username` varchar(10)
,`admin_password` varchar(10)
,`adgender` varchar(6)
,`adphone` decimal(10,0)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `all_infos`
--
CREATE TABLE IF NOT EXISTS `all_infos` (
`client_firstname` varchar(50)
,`client_lastname` varchar(50)
,`adfname` varchar(25)
,`adlname` varchar(25)
,`booking_id` int(8)
,`destination` varchar(50)
,`pre_payment` int(20)
,`car_type` varchar(20)
,`car_name` varchar(20)
,`driver_firstname` varchar(50)
,`driver_lastname` varchar(50)
,`amount` int(20)
);
-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `booking_id` int(8) NOT NULL AUTO_INCREMENT,
  `client_id` int(8) NOT NULL,
  `admid` int(8) NOT NULL,
  `date_time` date NOT NULL,
  `time_stamp` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `destination` varchar(50) NOT NULL,
  `car_id` int(8) NOT NULL,
  `pre_payment` int(20) NOT NULL,
  PRIMARY KEY (`booking_id`),
  KEY `client_id` (`client_id`,`car_id`),
  KEY `client_id_2` (`client_id`,`car_id`),
  KEY `client_id_3` (`client_id`,`car_id`),
  KEY `car_id` (`car_id`),
  KEY `client_id_4` (`client_id`),
  KEY `admid` (`admid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `client_id`, `admid`, `date_time`, `time_stamp`, `destination`, `car_id`, `pre_payment`) VALUES
(1, 1, 0, '2022-07-26', '0000-00-00 00:00:00.000000', 'kanombe', 1, 20000),
(2, 2, 0, '2022-07-27', '0000-00-00 00:00:00.000000', 'kibagabaga', 2, 10000),
(3, 2, 0, '2022-07-13', '0000-00-00 00:00:00.000000', 'rwampala', 2, 10000),
(5, 1, 2, '2022-07-13', '0000-00-00 00:00:00.000000', '10', 2, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE IF NOT EXISTS `car` (
  `car_id` int(5) NOT NULL AUTO_INCREMENT,
  `car_type` varchar(20) NOT NULL,
  `car_name` varchar(20) NOT NULL,
  `car_sit` int(2) NOT NULL,
  `plate_number` varchar(8) NOT NULL,
  PRIMARY KEY (`car_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`car_id`, `car_type`, `car_name`, `car_sit`, `plate_number`) VALUES
(1, 'bus', 'Coaster', 30, 'RAB234L'),
(2, 'Jeep', 'Prado', 8, 'RAD234z'),
(3, 'MInbus', 'COgeasa', 14, 'RAA433A');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `client_id` int(8) NOT NULL AUTO_INCREMENT,
  `client_firstname` varchar(50) NOT NULL,
  `client_lastname` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `client_firstname`, `client_lastname`, `username`, `password`, `gender`, `phone_number`) VALUES
(1, 'MBONIGABA', 'Jofre', 'jomboni', 'mbonigaba', 'male', '0788921534'),
(2, 'RWEMA', 'Johnson', 'johnrwema', 'rwema', 'male', '0788921535'),
(3, 'Baba', 'Giga', 'bhhhhhhh', 'gghjg ', 'm', '098789');

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE IF NOT EXISTS `driver` (
  `driver_id` int(8) NOT NULL AUTO_INCREMENT,
  `driver_firstname` varchar(50) NOT NULL,
  `driver_lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  PRIMARY KEY (`driver_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`driver_id`, `driver_firstname`, `driver_lastname`, `username`, `password`, `gender`, `phone_number`) VALUES
(1, 'HABYARAMUNGU', 'Bernard', 'bernamungu', 'habyaramungu', 'male', '0788921536'),
(2, 'NYINAWUMUNTU', 'Claire', 'clairewumuntu', 'nyinawumuntu', 'female', '0788921537'),
(3, 'gasore', 'Jan cooaja', 'heart12', '123456', 'f', '1234567');

-- --------------------------------------------------------

--
-- Stand-in structure for view `report`
--
CREATE TABLE IF NOT EXISTS `report` (
`client_firstname` varchar(50)
,`adfname` varchar(25)
,`booking_id` int(8)
,`destination` varchar(50)
,`pre_payment` int(20)
,`car_type` varchar(20)
,`car_name` varchar(20)
,`driver_firstname` varchar(50)
,`driver_lastname` varchar(50)
,`amount` int(20)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `reports`
--
CREATE TABLE IF NOT EXISTS `reports` (
`client_firstname` varchar(50)
,`client_lastname` varchar(50)
,`driver_firstname` varchar(50)
,`driver_lastname` varchar(50)
,`location` int(10)
,`amount` int(20)
);
-- --------------------------------------------------------

--
-- Table structure for table `travel`
--

CREATE TABLE IF NOT EXISTS `travel` (
  `travel_id` int(10) NOT NULL AUTO_INCREMENT,
  `car_id` int(5) NOT NULL,
  `client_id` int(8) NOT NULL,
  `driver_id` int(8) NOT NULL,
  `location` int(10) NOT NULL,
  `amount` int(20) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`travel_id`),
  KEY `client_id` (`client_id`,`driver_id`),
  KEY `driver_id` (`driver_id`),
  KEY `car_id` (`car_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `travel`
--

INSERT INTO `travel` (`travel_id`, `car_id`, `client_id`, `driver_id`, `location`, `amount`, `time`) VALUES
(1, 0, 5, 1, 100, 15000, '2022-07-25 20:13:46'),
(2, 1, 2, 1, 23, 12000, '2022-07-26 22:41:50');

-- --------------------------------------------------------

--
-- Structure for view `admin_view`
--
DROP TABLE IF EXISTS `admin_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admin_view` AS (select `admin`.`admid` AS `admid`,`admin`.`adfname` AS `adfname`,`admin`.`adlname` AS `adlname`,`admin`.`admin_username` AS `admin_username`,`admin`.`admin_password` AS `admin_password`,`admin`.`adgender` AS `adgender`,`admin`.`adphone` AS `adphone` from `admin`);

-- --------------------------------------------------------

--
-- Structure for view `all_infos`
--
DROP TABLE IF EXISTS `all_infos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_infos` AS (select `client`.`client_firstname` AS `client_firstname`,`client`.`client_lastname` AS `client_lastname`,`admin`.`adfname` AS `adfname`,`admin`.`adlname` AS `adlname`,`booking`.`booking_id` AS `booking_id`,`booking`.`destination` AS `destination`,`booking`.`pre_payment` AS `pre_payment`,`car`.`car_type` AS `car_type`,`car`.`car_name` AS `car_name`,`driver`.`driver_firstname` AS `driver_firstname`,`driver`.`driver_lastname` AS `driver_lastname`,`travel`.`amount` AS `amount` from (((((`admin` join `booking` on((`booking`.`admid` = `admin`.`admid`))) join `car` on((`booking`.`car_id` = `car`.`car_id`))) join `client` on((`client`.`client_id` = `booking`.`client_id`))) join `travel` on((`travel`.`client_id` = `client`.`client_id`))) join `driver` on((`travel`.`driver_id` = `driver`.`driver_id`))));

-- --------------------------------------------------------

--
-- Structure for view `report`
--
DROP TABLE IF EXISTS `report`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `report` AS (select `client`.`client_firstname` AS `client_firstname`,`admin`.`adfname` AS `adfname`,`booking`.`booking_id` AS `booking_id`,`booking`.`destination` AS `destination`,`booking`.`pre_payment` AS `pre_payment`,`car`.`car_type` AS `car_type`,`car`.`car_name` AS `car_name`,`driver`.`driver_firstname` AS `driver_firstname`,`driver`.`driver_lastname` AS `driver_lastname`,`travel`.`amount` AS `amount` from (((((`admin` join `booking` on((`booking`.`admid` = `admin`.`admid`))) join `car` on((`booking`.`car_id` = `car`.`car_id`))) join `client` on((`client`.`client_id` = `booking`.`client_id`))) join `travel` on((`travel`.`client_id` = `client`.`client_id`))) join `driver` on((`travel`.`driver_id` = `driver`.`driver_id`))));

-- --------------------------------------------------------

--
-- Structure for view `reports`
--
DROP TABLE IF EXISTS `reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reports` AS (select `client`.`client_firstname` AS `client_firstname`,`client`.`client_lastname` AS `client_lastname`,`driver`.`driver_firstname` AS `driver_firstname`,`driver`.`driver_lastname` AS `driver_lastname`,`travel`.`location` AS `location`,`travel`.`amount` AS `amount` from ((`client` join `travel` on((`travel`.`client_id` = `client`.`client_id`))) join `driver` on((`travel`.`driver_id` = `driver`.`driver_id`))));

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`admid`) REFERENCES `admin` (`admid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `travel`
--
ALTER TABLE `travel`
  ADD CONSTRAINT `travel_ibfk_1` FOREIGN KEY (`travel_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `travel_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
