-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 11:20 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atm system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertCourse` ()  BEGIN INSERT INTO `course` (`course_id`, `c_title`, `c_code`, `category`) VALUES ('5', 'quantitative', '2301', 'specific'); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listassignment` ()  BEGIN INSERT INTO `asignment` (`assignment_id`, `assignment_code`, `assignment_title`, `given_date`, `submit_date`, `faculty`) VALUES ('8', '2222', 'quantintative work', '05-08-2022', '15-08-2022'); END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listdepartment` ()  BEGIN INSERT INTO `department` (`department_id`, `dep_title`, `level`) VALUES ('8', 'ACC', '2'); END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listlecturer` ()  BEGIN INSERT INTO `lecturer` (`lecturer_id`, `fullname`, `phone_number`, `email`) VALUES ('8', 'NDAYAMBAJE TOM', '0788123456', 'ntom@gmail.com'); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `liststudent` ()  BEGIN select * from student; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateLecturer` ()  BEGIN UPDATE `lecturer` SET `fullname` = 'ellen kucyaro', `phone_number` = '0788223344' WHERE `lecturer`.`Lecturer_id` = 1; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Updateliststudent` ()  BEGIN UPDATE `student` SET `Lname` = 'nambajimana', `Fname` = 'narcise' WHERE `student`.`student_id` = 2; END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `assignment_id` int(5) NOT NULL,
  `assignment_code` varchar(10) NOT NULL,
  `assignment_title` varchar(40) NOT NULL,
  `given_date` date NOT NULL,
  `submit_date` date NOT NULL,
  `course_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`assignment_id`, `assignment_code`, `assignment_title`, `given_date`, `submit_date`, `course_id`) VALUES
(1, '2131', 'SOFTWARE ENGINEERING CAT', '2022-07-01', '2022-07-25', 0),
(2, '2321', 'BUSINESS FUNCTION ASSIGNMENT', '2022-07-15', '2022-07-30', 0),
(3, '1852', 'DATABASE CAT', '2022-07-10', '2022-07-27', 0),
(4, '2854', 'Principle of Economics Work', '2022-06-15', '2022-06-25', 0),
(5, '3020', 'Network Administrator Work', '2022-07-05', '2022-07-20', 0),
(6, '3040', 'Basic Mathematic work', '2022-06-27', '2022-07-10', 0);

--
-- Triggers `assignment`
--
DELIMITER $$
CREATE TRIGGER `insertassignmentAlert` AFTER INSERT ON `assignment` FOR EACH ROW BEGIN INSERT INTO `assignment` (`assignment_id`, `assignment_code`, `assignment_title`, `given_date`, `submit_date`) VALUES ('10', 'KInyarwanda work', '6543', '15-08-2022', '20-08-2022'); END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `c_title` varchar(25) NOT NULL,
  `c_code` varchar(10) NOT NULL,
  `category` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `c_title`, `c_code`, `category`) VALUES
(1, 'DATABASE DESIGN', '1852', 'Specific'),
(2, 'ENGLISH', '2031', 'Specific'),
(4, 'Network Administrator ', '3020', 'Specific'),
(5, 'Basic Mathematic', '3040', 'general');

--
-- Triggers `course`
--
DELIMITER $$
CREATE TRIGGER `insertcourseAlert` AFTER INSERT ON `course` FOR EACH ROW BEGIN  
INSERT INTO `course` (`course_id`, `c_title`, `c_code`, `category`) VALUES ('973', 'KInyarwanda', '6543', 'General'); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(5) NOT NULL,
  `dep_title` varchar(25) NOT NULL,
  `level` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `dep_title`, `level`) VALUES
(1, 'BIT', '2'),
(2, 'ECO', '2'),
(3, 'CST', '2'),
(5, 'ACC', '1'),
(6, 'CBE', '1');

--
-- Triggers `department`
--
DELIMITER $$
CREATE TRIGGER `DELETEdepart` AFTER INSERT ON `department` FOR EACH ROW BEGIN DELETE FROM `department` WHERE `department`.`department_id` = 5; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lecturer_id` int(5) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`lecturer_id`, `fullname`, `gender`, `phone_number`, `email`) VALUES
(1, 'DR HANYURWIMFURA Jean', 'M', '0788811111', 'hanyurwajean@gmail.com'),
(2, 'DR Ange UWAMARIYA', 'F', '0788822222', 'angeuwa@gmail.com'),
(3, 'DR NTWALI Innocent', 'M', '0781112233', 'innocent@gmail.com'),
(4, 'DR BYUKUSENGE Valery', 'M', '0789234567', 'bvalery@gmail.com'),
(5, 'DR NYIRAMANA Clarisse', 'F', '0789876543', 'nclarissegmail.com'),
(6, 'DR HIRWA JOSEPH ', 'M', '0788444777', 'hjoseph@gmail.com');

--
-- Triggers `lecturer`
--
DELIMITER $$
CREATE TRIGGER `DELETEAlert` AFTER INSERT ON `lecturer` FOR EACH ROW BEGIN  
DELETE FROM `lecturer` WHERE `lecturer`.`Lecturer_id` = 5; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Updatelectureralert` AFTER INSERT ON `lecturer` FOR EACH ROW BEGIN  
UPDATE `lecturer` SET `fullname` = 'NAMBAJIMANA', `gender` = 'F' WHERE `lecturer`.`Lecturer_id` = 5;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofdepartments`
-- (See below for the actual view)
--
CREATE TABLE `listofdepartments` (
`department_id` int(5)
,`dep_title` varchar(25)
,`level` varchar(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `liststudent`
-- (See below for the actual view)
--
CREATE TABLE `liststudent` (
`student_id` int(5)
,`Lname` varchar(25)
,`Fname` varchar(25)
,`reg_number` varchar(10)
,`gender` varchar(6)
,`address` varchar(20)
,`faculty` varchar(20)
,`level` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_assignments`
-- (See below for the actual view)
--
CREATE TABLE `list_of_assignments` (
`assignment_id` int(5)
,`assignment_code` varchar(10)
,`assignment_title` varchar(40)
,`given_date` date
,`submit_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_courses`
-- (See below for the actual view)
--
CREATE TABLE `list_of_courses` (
`course_id` int(11)
,`c_title` varchar(25)
,`c_code` varchar(10)
,`category` varchar(15)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `list_of_lecturer`
-- (See below for the actual view)
--
CREATE TABLE `list_of_lecturer` (
`lecturer_id` int(5)
,`fullname` varchar(50)
,`gender` varchar(6)
,`phone_number` varchar(15)
,`email` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(5) NOT NULL,
  `Lname` varchar(25) NOT NULL,
  `Fname` varchar(25) NOT NULL,
  `reg_number` varchar(10) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `address` varchar(20) NOT NULL,
  `faculty` varchar(20) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `Lname`, `Fname`, `reg_number`, `gender`, `address`, `faculty`, `level`) VALUES
(1, 'HIRWA', 'Valentin', '221025409', 'M', 'huye', 'BIT', '2'),
(2, 'KALISA', 'Joseph', '221022102', 'M', 'huye', 'BIT', '2'),
(3, 'MBANIYE', 'Hakim', '221023231', 'M', 'huye', 'ECO', '2'),
(4, 'UWIMANA', 'Marie', '221002202', 'F', 'kigali', 'STAT', '1'),
(5, 'KAYITARE ', 'Gentil', '221006723', 'M', 'kigali', 'CST', '2'),
(6, 'AKARIZA', 'Tonny', '221002525', 'F', 'Nyagatare', 'CASS', '2'),
(7, 'IRADUKUNDA', 'Ben', '221002626', 'M', 'Kayonza', 'CBE', '2');

--
-- Triggers `student`
--
DELIMITER $$
CREATE TRIGGER `Updatestudentlist` AFTER INSERT ON `student` FOR EACH ROW BEGIN UPDATE `student` SET `Lname` = 'NIYONAGIZE', `gender` = 'F' WHERE `student`.`student_id` = 6; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `listofdepartments`
--
DROP TABLE IF EXISTS `listofdepartments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofdepartments`  AS  select `department`.`department_id` AS `department_id`,`department`.`dep_title` AS `dep_title`,`department`.`level` AS `level` from `department` ;

-- --------------------------------------------------------

--
-- Structure for view `liststudent`
--
DROP TABLE IF EXISTS `liststudent`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `liststudent`  AS  select `student`.`student_id` AS `student_id`,`student`.`Lname` AS `Lname`,`student`.`Fname` AS `Fname`,`student`.`reg_number` AS `reg_number`,`student`.`gender` AS `gender`,`student`.`address` AS `address`,`student`.`faculty` AS `faculty`,`student`.`level` AS `level` from `student` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_assignments`
--
DROP TABLE IF EXISTS `list_of_assignments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_assignments`  AS  select `assignment`.`assignment_id` AS `assignment_id`,`assignment`.`assignment_code` AS `assignment_code`,`assignment`.`assignment_title` AS `assignment_title`,`assignment`.`given_date` AS `given_date`,`assignment`.`submit_date` AS `submit_date` from `assignment` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_courses`
--
DROP TABLE IF EXISTS `list_of_courses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_courses`  AS  select `course`.`course_id` AS `course_id`,`course`.`c_title` AS `c_title`,`course`.`c_code` AS `c_code`,`course`.`category` AS `category` from `course` ;

-- --------------------------------------------------------

--
-- Structure for view `list_of_lecturer`
--
DROP TABLE IF EXISTS `list_of_lecturer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `list_of_lecturer`  AS  select `lecturer`.`lecturer_id` AS `lecturer_id`,`lecturer`.`fullname` AS `fullname`,`lecturer`.`gender` AS `gender`,`lecturer`.`phone_number` AS `phone_number`,`lecturer`.`email` AS `email` from `lecturer` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`lecturer_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `assignment_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `lecturer_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
