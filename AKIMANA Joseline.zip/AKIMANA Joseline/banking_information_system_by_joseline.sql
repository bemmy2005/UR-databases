-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 12:00 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banking_information_system_by_joseline`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletefromtransations` (IN `Trans_ID` VARCHAR(10))  BEGIN 
DELETE from transactions WHERE transactions.Trans_ID=Trans_ID; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteinsavings` (IN `Save_ID` INT(5))  BEGIN
delete FROM savings where Save_ID='6';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getaccountinfo` ()  BEGIN
SELECT*from accounts;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcustomerinfo` ()  BEGIN
SELECT*FROM customer;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getemployeeinfo` ()  BEGIN
SELECT*FROM employees;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getloginfo` ()  BEGIN
SELECT*FROM log;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getreportinfo` ()  BEGIN
SELECT*from report;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getsavinginfo` ()  BEGIN 
SELECT*FROM savings;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `gettransactioninfo` ()  BEGIN
SELECT*from transactions;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertdataintoaccount` (IN `Acc_ID` INT(5), `Acc_number` VARCHAR(15), `Acc_type` VARCHAR(15), `Cust_ID` INT(5))  BEGIN
insert into accounts values(Acc_ID,Acc_number,Acc_type,Cust_ID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertdataintocustomer` (IN `Cust_ID` INT(5), `Fname` VARCHAR(10), `Lname` VARCHAR(10), `Address` VARCHAR(20), `Tel` INT(12), `Username` VARCHAR(15), `Passphrase` VARCHAR(10))  BEGIN
insert into customer values(Cust_ID,Fname,Lname,Address,Tel,Username,Passphrase);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertdataintoemployees` (IN `Emp_ID` INT(5), `Fname` VARCHAR(10), `Lname` VARCHAR(10), `Address` VARCHAR(20), `Tel` INT(12), `Username` VARCHAR(15), `Passphrase` VARCHAR(10))  BEGIN
insert into employees VALUES(Emp_ID,Fname,Lname,Address,Tel,Username,Passphrase);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertdataintolog` (IN `Log_ID` INT(5), `Trans_ID` INT(5), `Login_date` DATE, `Login_time` TIME)  BEGIN
insert into log VALUES(Log_ID,Trans_ID,Login_date,Login_time);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertdataintotransactions` (IN `Trans_ID` INT(5), `Emp_ID` INT(5), `Cust_ID` INT(5), `Trans_name` VARCHAR(10))  BEGIN
insert into transactions VALUES(Trans_ID,Emp_ID,Cust_ID,Trans_name);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintoreport` (IN `Rep_ID` INT(5), `Acc_ID` INT(5), `Log_ID` INT(5), `Trans_ID` INT(5), `Rep_name` VARCHAR(12), `Rep_date` DATE)  BEGIN
insert into report VALUES(Rep_ID,Acc_ID,Log_ID,Trans_ID,Rep_name,Rep_date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintosavings` (IN `Save_ID` INT(5), `Save_date` DATE, `Amount` INT(10), `Acc_ID` INT(5), `Cust_ID` INT(5))  BEGIN
insert into savings VALUES(Save_ID,Save_date,Amount,Acc_ID,Cust_ID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `procedureview` ()  BEGIN
SELECT*from transactions where Trans_ID=(select MAX(Trans_ID)FROM transactions);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateaccount` (IN `Acc_ID` INT(5))  BEGIN
UPDATE accounts set Acc_type='Current Account' where Acc_ID='2';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatecustomer` (IN `Cust_ID` INT(5))  BEGIN
update customer set Lname='Alexis' where Cust_ID='7';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatesaving` (IN `Save_ID` INT(5))  BEGIN
update savings set Amount='250000'where Save_ID='6';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `Acc_ID` int(5) NOT NULL,
  `Acc_number` varchar(15) DEFAULT NULL,
  `Acc_type` varchar(15) DEFAULT NULL,
  `Cust_ID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`Acc_ID`, `Acc_number`, `Acc_type`, `Cust_ID`) VALUES
(2, '77765554', 'Saving Account', 2),
(3, '172345666', 'Personal Accoun', 5),
(4, '457823', 'current account', 4),
(9, '411145', 'saving account', 7),
(13, '4411569', 'Personal accoun', 1),
(30, '12531235', 'Current Account', 5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `considersubquery`
-- (See below for the actual view)
--
CREATE TABLE `considersubquery` (
`Cust_ID` int(5)
,`Fname` varchar(10)
,`Lname` varchar(10)
,`Address` varchar(20)
,`Tel` int(12)
,`Username` varchar(15)
,`Passphrase` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Cust_ID` int(5) NOT NULL,
  `Fname` varchar(10) NOT NULL,
  `Lname` varchar(10) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Tel` int(12) NOT NULL,
  `Username` varchar(15) NOT NULL,
  `Passphrase` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Cust_ID`, `Fname`, `Lname`, `Address`, `Tel`, `Username`, `Passphrase`) VALUES
(1, 'UWASE', 'Diane', 'Kicukiro', 784609321, 'dizzydiane', 'dianna45'),
(2, 'NYANDWI', 'Regis', 'Rwintama', 7896585, 'nyandwi32', 'kukimuki'),
(4, 'HAKIZIMANA', 'Djuma', 'Huye', 786731449, 'Djuma48', 'Khalifa_61'),
(5, 'UWIMANA', 'Liliane', 'kayonza', 786551650, 'lily', 'calvin_61'),
(7, 'MUKOBWAJAN', 'Esther', 'Nyaruguru', 2147483647, 'mukobwajana', 'ndiokabisa'),
(8, 'IRAKOZE', 'Liam', 'NYARUGENGE', 782458799, 'Bladdy', 'kilim');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `after_delete_customer` AFTER DELETE ON `customer` FOR EACH ROW BEGIN
DELETE FROM accounts WHERE accounts.Cust_ID=OLD.Cust_ID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_customer` AFTER UPDATE ON `customer` FOR EACH ROW BEGIN
UPDATE accounts SET accounts.Acc_type='Personal account' WHERE accounts.Cust_ID=OLD.Cust_ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `deletefromtransactions`
-- (See below for the actual view)
--
CREATE TABLE `deletefromtransactions` (
`Trans_ID` int(5)
,`Emp_ID` int(5)
,`Cust_ID` int(5)
,`Trans_name` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Emp_ID` int(5) NOT NULL,
  `Fname` varchar(10) NOT NULL,
  `Lname` varchar(10) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Tel` int(12) NOT NULL,
  `Username` varchar(15) NOT NULL,
  `Passphrase` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Emp_ID`, `Fname`, `Lname`, `Address`, `Tel`, `Username`, `Passphrase`) VALUES
(1, 'MUKAMA', 'Jordarn', 'Kigali', 7899999, 'mukama123', '123%mukama'),
(2, 'MUKUNZI', 'Chalon', 'Nyamagabe', 79866565, 'mukunziiii', 'habana123'),
(15, 'KANKIRIHO', 'Godfrey', 'Nyagatare', 789564, 'kankieas', '123£34'),
(20, 'IGIRANEZA', 'Belyse', 'Huye', 788563233, 'Becky_bell', 'Alema_reco'),
(21, 'AMIZERO', 'Christian', 'Kamonyi', 788541670, 'Christian250', 'ricHhigher'),
(22, 'KANKINDI', 'Olivier', 'nyamasheke', 786087653, 'kankoli', '123face');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_accounts`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_accounts` (
`Acc_ID` int(5)
,`Acc_number` varchar(15)
,`Acc_type` varchar(15)
,`Cust_ID` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_customer`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_customer` (
`Cust_ID` int(5)
,`Fname` varchar(10)
,`Lname` varchar(10)
,`Address` varchar(20)
,`Tel` int(12)
,`Username` varchar(15)
,`Passphrase` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_employees`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_employees` (
`Emp_ID` int(5)
,`Fname` varchar(10)
,`Lname` varchar(10)
,`Address` varchar(20)
,`Tel` int(12)
,`Username` varchar(15)
,`Passphrase` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_log`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_log` (
`Log_ID` int(5)
,`Trans_ID` int(5)
,`Login_date` date
,`Login_time` time
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_report`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_report` (
`Rep_ID` int(5)
,`Acc_ID` int(5)
,`Log_ID` int(5)
,`Trans_ID` int(5)
,`Rep_name` varchar(12)
,`Rep_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_saving`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_saving` (
`Save_ID` int(5)
,`Save_date` date
,`Amount` float
,`Acc_ID` int(5)
,`Cust_ID` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_into_transaction`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_into_transaction` (
`Trans_ID` int(5)
,`Emp_ID` int(5)
,`Cust_ID` int(5)
,`Trans_name` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `Log_ID` int(5) NOT NULL,
  `Trans_ID` int(5) DEFAULT NULL,
  `Login_date` date DEFAULT NULL,
  `Login_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`Log_ID`, `Trans_ID`, `Login_date`, `Login_time`) VALUES
(16, 15, '2022-07-26', '13:07:20'),
(17, 16, '2022-07-26', '13:07:20'),
(19, 18, '2022-07-26', '13:15:03');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `Rep_ID` int(5) NOT NULL,
  `Acc_ID` int(5) DEFAULT NULL,
  `Log_ID` int(5) DEFAULT NULL,
  `Trans_ID` int(5) DEFAULT NULL,
  `Rep_name` varchar(12) NOT NULL,
  `Rep_date` date DEFAULT NULL,
  `Done_By` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`Rep_ID`, `Acc_ID`, `Log_ID`, `Trans_ID`, `Rep_name`, `Rep_date`, `Done_By`) VALUES
(27, 9, 17, 15, 'daily withdr', '2022-04-05', 15),
(28, 4, 19, 16, 'D-transactio', '2012-01-12', 15);

-- --------------------------------------------------------

--
-- Table structure for table `savings`
--

CREATE TABLE `savings` (
  `Save_ID` int(5) NOT NULL,
  `Save_date` date DEFAULT NULL,
  `Amount` float DEFAULT NULL,
  `Acc_ID` int(5) DEFAULT NULL,
  `Cust_ID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `savings`
--

INSERT INTO `savings` (`Save_ID`, `Save_date`, `Amount`, `Acc_ID`, `Cust_ID`) VALUES
(2, '2016-07-14', 2200000, 2, 2),
(5, '2022-07-27', 1750000, 3, 4),
(6, '2020-05-21', 2175000, 2, 5),
(21, '2022-06-12', 7200000, 30, 7);

-- --------------------------------------------------------

--
-- Stand-in structure for view `todeletefromsavings`
-- (See below for the actual view)
--
CREATE TABLE `todeletefromsavings` (
`Save_ID` int(5)
,`Save_date` date
,`Amount` float
,`Acc_ID` int(5)
,`Cust_ID` int(5)
);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `Trans_ID` int(5) NOT NULL,
  `Emp_ID` int(5) DEFAULT NULL,
  `Cust_ID` int(5) DEFAULT NULL,
  `Trans_name` varchar(10) DEFAULT NULL,
  `Amount` float NOT NULL,
  `Save_ID` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`Trans_ID`, `Emp_ID`, `Cust_ID`, `Trans_name`, `Amount`, `Save_ID`) VALUES
(15, 2, 2, 'Withdraw', 3000000, 2),
(16, 22, 4, 'Deposit', 500000, 5),
(18, 21, 5, 'Withdraw', 300000, 6);

--
-- Triggers `transactions`
--
DELIMITER $$
CREATE TRIGGER `after_insert_transation` AFTER INSERT ON `transactions` FOR EACH ROW BEGIN
IF(NEW.Trans_name='Withdraw') THEN
UPDATE savings,transactions SET savings.Amount=savings.Amount-new.Amount WHERE transactions.Save_ID=new.Save_ID;
ELSEIF(NEW.Trans_name='Deposit') THEN
UPDATE savings,transactions SET savings.Amount=savings.Amount+new.Amount WHERE transactions.Save_ID=new.Save_ID;
END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_transations` AFTER INSERT ON `transactions` FOR EACH ROW BEGIN
INSERT INTO log VALUES('',New.Trans_ID,NOW(),NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `updateintoaccount`
-- (See below for the actual view)
--
CREATE TABLE `updateintoaccount` (
`Acc_ID` int(5)
,`Acc_number` varchar(15)
,`Acc_type` varchar(15)
,`Cust_ID` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updateintocustomer`
-- (See below for the actual view)
--
CREATE TABLE `updateintocustomer` (
`Cust_ID` int(5)
,`Fname` varchar(10)
,`Lname` varchar(10)
,`Address` varchar(20)
,`Tel` int(12)
,`Username` varchar(15)
,`Passphrase` varchar(10)
);

-- --------------------------------------------------------

--
-- Structure for view `considersubquery`
--
DROP TABLE IF EXISTS `considersubquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `considersubquery`  AS SELECT `customer`.`Cust_ID` AS `Cust_ID`, `customer`.`Fname` AS `Fname`, `customer`.`Lname` AS `Lname`, `customer`.`Address` AS `Address`, `customer`.`Tel` AS `Tel`, `customer`.`Username` AS `Username`, `customer`.`Passphrase` AS `Passphrase` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `deletefromtransactions`
--
DROP TABLE IF EXISTS `deletefromtransactions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deletefromtransactions`  AS SELECT `transactions`.`Trans_ID` AS `Trans_ID`, `transactions`.`Emp_ID` AS `Emp_ID`, `transactions`.`Cust_ID` AS `Cust_ID`, `transactions`.`Trans_name` AS `Trans_name` FROM `transactions` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_accounts`
--
DROP TABLE IF EXISTS `insert_data_into_accounts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_accounts`  AS SELECT `accounts`.`Acc_ID` AS `Acc_ID`, `accounts`.`Acc_number` AS `Acc_number`, `accounts`.`Acc_type` AS `Acc_type`, `accounts`.`Cust_ID` AS `Cust_ID` FROM `accounts` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_customer`
--
DROP TABLE IF EXISTS `insert_data_into_customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_customer`  AS SELECT `customer`.`Cust_ID` AS `Cust_ID`, `customer`.`Fname` AS `Fname`, `customer`.`Lname` AS `Lname`, `customer`.`Address` AS `Address`, `customer`.`Tel` AS `Tel`, `customer`.`Username` AS `Username`, `customer`.`Passphrase` AS `Passphrase` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_employees`
--
DROP TABLE IF EXISTS `insert_data_into_employees`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_employees`  AS SELECT `employees`.`Emp_ID` AS `Emp_ID`, `employees`.`Fname` AS `Fname`, `employees`.`Lname` AS `Lname`, `employees`.`Address` AS `Address`, `employees`.`Tel` AS `Tel`, `employees`.`Username` AS `Username`, `employees`.`Passphrase` AS `Passphrase` FROM `employees` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_log`
--
DROP TABLE IF EXISTS `insert_data_into_log`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_log`  AS SELECT `log`.`Log_ID` AS `Log_ID`, `log`.`Trans_ID` AS `Trans_ID`, `log`.`Login_date` AS `Login_date`, `log`.`Login_time` AS `Login_time` FROM `log` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_report`
--
DROP TABLE IF EXISTS `insert_data_into_report`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_report`  AS SELECT `report`.`Rep_ID` AS `Rep_ID`, `report`.`Acc_ID` AS `Acc_ID`, `report`.`Log_ID` AS `Log_ID`, `report`.`Trans_ID` AS `Trans_ID`, `report`.`Rep_name` AS `Rep_name`, `report`.`Rep_date` AS `Rep_date` FROM `report` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_saving`
--
DROP TABLE IF EXISTS `insert_data_into_saving`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_saving`  AS SELECT `savings`.`Save_ID` AS `Save_ID`, `savings`.`Save_date` AS `Save_date`, `savings`.`Amount` AS `Amount`, `savings`.`Acc_ID` AS `Acc_ID`, `savings`.`Cust_ID` AS `Cust_ID` FROM `savings` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_into_transaction`
--
DROP TABLE IF EXISTS `insert_data_into_transaction`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_into_transaction`  AS SELECT `transactions`.`Trans_ID` AS `Trans_ID`, `transactions`.`Emp_ID` AS `Emp_ID`, `transactions`.`Cust_ID` AS `Cust_ID`, `transactions`.`Trans_name` AS `Trans_name` FROM `transactions` ;

-- --------------------------------------------------------

--
-- Structure for view `todeletefromsavings`
--
DROP TABLE IF EXISTS `todeletefromsavings`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `todeletefromsavings`  AS SELECT `savings`.`Save_ID` AS `Save_ID`, `savings`.`Save_date` AS `Save_date`, `savings`.`Amount` AS `Amount`, `savings`.`Acc_ID` AS `Acc_ID`, `savings`.`Cust_ID` AS `Cust_ID` FROM `savings` ;

-- --------------------------------------------------------

--
-- Structure for view `updateintoaccount`
--
DROP TABLE IF EXISTS `updateintoaccount`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updateintoaccount`  AS SELECT `accounts`.`Acc_ID` AS `Acc_ID`, `accounts`.`Acc_number` AS `Acc_number`, `accounts`.`Acc_type` AS `Acc_type`, `accounts`.`Cust_ID` AS `Cust_ID` FROM `accounts` ;

-- --------------------------------------------------------

--
-- Structure for view `updateintocustomer`
--
DROP TABLE IF EXISTS `updateintocustomer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updateintocustomer`  AS SELECT `customer`.`Cust_ID` AS `Cust_ID`, `customer`.`Fname` AS `Fname`, `customer`.`Lname` AS `Lname`, `customer`.`Address` AS `Address`, `customer`.`Tel` AS `Tel`, `customer`.`Username` AS `Username`, `customer`.`Passphrase` AS `Passphrase` FROM `customer` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`Acc_ID`),
  ADD KEY `Cust_ID` (`Cust_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Cust_ID`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Emp_ID`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`Log_ID`),
  ADD KEY `Trans_ID` (`Trans_ID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`Rep_ID`),
  ADD KEY `Acc_ID` (`Acc_ID`,`Trans_ID`,`Log_ID`),
  ADD KEY `Log_ID` (`Log_ID`),
  ADD KEY `Trans_ID` (`Trans_ID`),
  ADD KEY `Done_By` (`Done_By`);

--
-- Indexes for table `savings`
--
ALTER TABLE `savings`
  ADD PRIMARY KEY (`Save_ID`),
  ADD KEY `Cust_ID` (`Cust_ID`,`Acc_ID`),
  ADD KEY `Acc_ID` (`Acc_ID`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`Trans_ID`),
  ADD KEY `Emp_ID` (`Emp_ID`,`Cust_ID`),
  ADD KEY `Cust_ID` (`Cust_ID`),
  ADD KEY `Save_ID` (`Save_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `Acc_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Cust_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `Emp_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `Log_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `Rep_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `savings`
--
ALTER TABLE `savings`
  MODIFY `Save_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `Trans_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`Cust_ID`) REFERENCES `customer` (`Cust_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `log_ibfk_1` FOREIGN KEY (`Trans_ID`) REFERENCES `transactions` (`Trans_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`Acc_ID`) REFERENCES `accounts` (`Acc_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `report_ibfk_2` FOREIGN KEY (`Log_ID`) REFERENCES `log` (`Log_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `report_ibfk_3` FOREIGN KEY (`Trans_ID`) REFERENCES `transactions` (`Trans_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `report_ibfk_4` FOREIGN KEY (`Done_By`) REFERENCES `employees` (`Emp_ID`);

--
-- Constraints for table `savings`
--
ALTER TABLE `savings`
  ADD CONSTRAINT `savings_ibfk_1` FOREIGN KEY (`Cust_ID`) REFERENCES `customer` (`Cust_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `savings_ibfk_2` FOREIGN KEY (`Acc_ID`) REFERENCES `accounts` (`Acc_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employees` (`Emp_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`Cust_ID`) REFERENCES `customer` (`Cust_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`Save_ID`) REFERENCES `savings` (`Save_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
