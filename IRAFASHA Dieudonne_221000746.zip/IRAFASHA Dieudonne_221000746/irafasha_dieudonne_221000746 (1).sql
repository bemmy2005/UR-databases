-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 10:52 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `irafasha_dieudonne_221000746`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `sector` varchar(100) NOT NULL,
  `trade` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `sector`, `trade`, `title`, `level`) VALUES
(1, 'ICT', 'Software Development', 'SOFTWARE DEVELOPER', 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `clsess`
-- (See below for the actual view)
--
CREATE TABLE `clsess` (
`class_id` int(11)
,`sector` varchar(100)
,`trade` varchar(100)
,`title` varchar(100)
,`level` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `module_id` int(11) NOT NULL,
  `module_code` varchar(100) NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `class_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`module_id`, `module_code`, `module_name`, `class_id`) VALUES
(1, 'SFTB301', 'Database', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `modules`
-- (See below for the actual view)
--
CREATE TABLE `modules` (
`module_id` int(11)
,`module_code` varchar(100)
,`module_name` varchar(100)
,`class_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `my_results`
-- (See below for the actual view)
--
CREATE TABLE `my_results` (
`result_id` int(11)
,`user_id` int(11)
,`class_id` int(11)
,`academic_year` int(11)
,`module_id` int(11)
,`result_type` int(2)
,`student_id` int(11)
,`marks` float
);

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `result_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `academic_year` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `result_type` int(2) NOT NULL,
  `student_id` int(11) NOT NULL,
  `marks` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`result_id`, `user_id`, `class_id`, `academic_year`, `module_id`, `result_type`, `student_id`, `marks`) VALUES
(1, 1, 1, 2021, 1, 1, 1, 70);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `reg_number` varchar(15) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `class_id` int(11) NOT NULL,
  `academic_year` int(11) NOT NULL,
  `reg_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `reg_number`, `student_name`, `class_id`, `academic_year`, `reg_date`) VALUES
(1, '221000746', 'IRAFASHA Dieudonne', 1, 2021, '2022-07-26');

-- --------------------------------------------------------

--
-- Stand-in structure for view `students`
-- (See below for the actual view)
--
CREATE TABLE `students` (
`student_id` int(11)
,`reg_number` varchar(15)
,`student_name` varchar(100)
,`academic_year` int(11)
,`reg_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sub_query`
-- (See below for the actual view)
--
CREATE TABLE `sub_query` (
`student_id` int(11)
,`total_marks` double
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` int(1) NOT NULL,
  `class_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `role`, `class_id`) VALUES
(1, 'Element', '12345', 1, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `users`
-- (See below for the actual view)
--
CREATE TABLE `users` (
`user_id` int(11)
,`username` varchar(100)
,`password` varchar(30)
,`role` int(1)
);

-- --------------------------------------------------------

--
-- Structure for view `clsess`
--
DROP TABLE IF EXISTS `clsess`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clsess`  AS  select `class`.`class_id` AS `class_id`,`class`.`sector` AS `sector`,`class`.`trade` AS `trade`,`class`.`title` AS `title`,`class`.`level` AS `level` from `class` ;

-- --------------------------------------------------------

--
-- Structure for view `modules`
--
DROP TABLE IF EXISTS `modules`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `modules`  AS  select `module`.`module_id` AS `module_id`,`module`.`module_code` AS `module_code`,`module`.`module_name` AS `module_name`,`module`.`class_id` AS `class_id` from `module` ;

-- --------------------------------------------------------

--
-- Structure for view `my_results`
--
DROP TABLE IF EXISTS `my_results`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `my_results`  AS  select `results`.`result_id` AS `result_id`,`results`.`user_id` AS `user_id`,`results`.`class_id` AS `class_id`,`results`.`academic_year` AS `academic_year`,`results`.`module_id` AS `module_id`,`results`.`result_type` AS `result_type`,`results`.`student_id` AS `student_id`,`results`.`marks` AS `marks` from `results` ;

-- --------------------------------------------------------

--
-- Structure for view `students`
--
DROP TABLE IF EXISTS `students`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `students`  AS  select distinct `student`.`student_id` AS `student_id`,`student`.`reg_number` AS `reg_number`,`student`.`student_name` AS `student_name`,`student`.`academic_year` AS `academic_year`,`student`.`reg_date` AS `reg_date` from (`student` join `class` on(`student`.`class_id` = `class`.`class_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `sub_query`
--
DROP TABLE IF EXISTS `sub_query`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sub_query`  AS  select `results`.`student_id` AS `student_id`,sum(`results`.`marks`) AS `total_marks` from `results` group by `results`.`student_id` ;

-- --------------------------------------------------------

--
-- Structure for view `users`
--
DROP TABLE IF EXISTS `users`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users`  AS  select distinct `user`.`user_id` AS `user_id`,`user`.`username` AS `username`,`user`.`password` AS `password`,`user`.`role` AS `role` from (`user` join `class` on(`user`.`class_id` = `class`.`class_id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`module_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `module_id` (`module_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `class_id` (`class_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `module`
--
ALTER TABLE `module`
  ADD CONSTRAINT `module_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`);

--
-- Constraints for table `results`
--
ALTER TABLE `results`
  ADD CONSTRAINT `results_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `module` (`module_id`),
  ADD CONSTRAINT `results_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `results_ibfk_3` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`),
  ADD CONSTRAINT `results_ibfk_4` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
