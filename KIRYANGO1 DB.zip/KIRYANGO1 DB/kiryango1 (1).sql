-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 12:00 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kiryango1`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` varchar(50) NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `Contacts` int(15) NOT NULL,
  `Address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `Fname`, `Lname`, `Contacts`, `Address`) VALUES
('A256', 'GASANA', 'NADEGE', 786803927, 'VIET'),
('B667', 'JOSEPH', 'ISIMBI', 788440749, 'KIGALI');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `DELETEcustomerAlert` AFTER INSERT ON `customer` FOR EACH ROW BEGIN  
DELETE FROM `customer` WHERE `customer`.`customer_id` = 256; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateCUSTOMERAlert` AFTER INSERT ON `customer` FOR EACH ROW BEGIN  
UPDATE `customer` SET `customer_id` = 'B45', `Fname` = 'janvier',`Lname` = 'makenga',`contacts` = '0788658776',`Address` = 'nyagatare' WHERE `customer`.`customer_id` = A256;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertcustomerAlert` AFTER INSERT ON `customer` FOR EACH ROW BEGIN  
INSERT INTO `customer` (`customer_id`, `Fname`, `Lname`, `contacts`,`address`) VALUES ('A55', 'KIBWA', 'JOE', '0789383',`KIGALI`); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `deliverie_id` varchar(50) NOT NULL,
  `Customer_id` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`deliverie_id`, `Customer_id`, `Date`) VALUES
('AT258', 'A34', '12-08-2021');

-- --------------------------------------------------------

--
-- Stand-in structure for view `kiryango_customer`
-- (See below for the actual view)
--
CREATE TABLE `kiryango_customer` (
`customer_id` varchar(50)
,`Fname` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `ordername`
-- (See below for the actual view)
--
CREATE TABLE `ordername` (
`order_id` varchar(50)
,`customer_id` varchar(50)
,`date` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_id` varchar(50) NOT NULL,
  `Category_id` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_id`, `Category_id`, `Date`) VALUES
('655', 'A34', '14-07-2021');

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `DELETEpaymentAlert` AFTER INSERT ON `payment` FOR EACH ROW BEGIN  
DELETE FROM `payment` WHERE `payment`.`payment_id` = 655; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdatepaymentAlert` AFTER INSERT ON `payment` FOR EACH ROW BEGIN  
UPDATE `payment` SET `payment_id` = 'Z456', `category_id` = 'A5678',`date` = '13-06-2020' WHERE `payment`.`payment_id` = 655;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `paymentname`
-- (See below for the actual view)
--
CREATE TABLE `paymentname` (
`payment_id` varchar(50)
,`category_id` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `Product_id` varchar(50) NOT NULL,
  `Category_id` varchar(50) NOT NULL,
  `Product_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Product_id`, `Category_id`, `Product_name`) VALUES
('Q22', 'A55', 'Kiryango jumper');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `Seller_id` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`Seller_id`, `product_id`, `Fname`, `Lname`) VALUES
('B44', '766', 'FURAHA', 'GENTIL');

-- --------------------------------------------------------

--
-- Table structure for table `shopping order`
--

CREATE TABLE `shopping order` (
  `order_id` varchar(50) NOT NULL,
  `Customer_id` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shopping order`
--

INSERT INTO `shopping order` (`order_id`, `Customer_id`, `Date`) VALUES
('A22', 'A34', '14-05-2021'),
('A28', 'A84', '14-05-2021');

-- --------------------------------------------------------

--
-- Structure for view `kiryango_customer`
--
DROP TABLE IF EXISTS `kiryango_customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `kiryango_customer`  AS  select `customer`.`customer_id` AS `customer_id`,`customer`.`Fname` AS `Fname` from `customer` where `customer`.`Address` = 'KIGALI' ;

-- --------------------------------------------------------

--
-- Structure for view `ordername`
--
DROP TABLE IF EXISTS `ordername`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ordername`  AS  select `shopping order`.`order_id` AS `order_id`,`shopping order`.`Customer_id` AS `customer_id`,`shopping order`.`Date` AS `date` from `shopping order` where `shopping order`.`order_id` = 'A22' ;

-- --------------------------------------------------------

--
-- Structure for view `paymentname`
--
DROP TABLE IF EXISTS `paymentname`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `paymentname`  AS  select `payment`.`Payment_id` AS `payment_id`,`payment`.`Category_id` AS `category_id` from `payment` where `payment`.`Category_id` = 'A34' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`deliverie_id`),
  ADD KEY `Customer_id` (`Customer_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Category_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`Product_id`),
  ADD KEY `Category_id` (`Category_id`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`Seller_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `shopping order`
--
ALTER TABLE `shopping order`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `Customer_id` (`Customer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
