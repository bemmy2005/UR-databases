-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 08:20 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hugues_denotredame`
--
CREATE DATABASE IF NOT EXISTS `hugues_denotredame` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hugues_denotredame`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `deletej_giver`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletej_giver` (IN `job_giver_ID` INT(10))  BEGIN DELETE FROM job_givers WHERE job_giver_ID=jobgiver_id; END$$

DROP PROCEDURE IF EXISTS `deletej_seeker`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletej_seeker` (IN `job_seeker_id` INT(10))  BEGIN DELETE FROM job_seekers WHERE job_seeker_id=job_seeker_id; END$$

DROP PROCEDURE IF EXISTS `into_epayment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `into_epayment` (IN `pay_id` INT(10), IN `pay_mode` VARCHAR(20), IN `amount` INT(7), IN `date_of_payment` DATE, IN `job_seeker_id` INT(10), IN `job_giver_id` INT(10), IN `payment_per_hour` INT(5), IN `reason` VARCHAR(20))  BEGIN insert into epayments values(pay_id,pay_mode,amount,date_of_payment,job_seeker_id,job_giver_id,payment_per_hour); END$$

DROP PROCEDURE IF EXISTS `Into_j_givers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Into_j_givers` (`job_giver_id` INT(10), `national_id` INT(10), `Fname` VARCHAR(20), `L_name` VARCHAR(20), `DOB` DATE, `gender` VARCHAR(6), `address` VARCHAR(20), `contacts` VARCHAR(15), `email` VARCHAR(25))  BEGIN insert into job_givers VALUEs(job_giver_id, national_id,fname,lname,dob,gender,address,contacts,Email); END$$

DROP PROCEDURE IF EXISTS `job_giver_info`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `job_giver_info` ()  BEGIN SELECT * FROM job_giversver; END$$

DROP PROCEDURE IF EXISTS `job_seeke_info`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `job_seeke_info` ()  BEGIN SELECT* FROM job_seekers; END$$

DROP PROCEDURE IF EXISTS `sq_task`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sq_task` (`task_ID` INT(10), `task_name` VARCHAR(20), `type_of_task` VARCHAR(20), `duration` VARCHAR(20), `start_date` DATE, `job_giver_id` INT(10), `job_seeker_ID` INT(10), `pay_per_hour` INT(5))  BEGIN SELECT* from tasks where task_ID<(SELECT(task_ID) from tasks); END$$

DROP PROCEDURE IF EXISTS `updatej_givers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updatej_givers` (IN `job_giver_id` VARCHAR(10))  BEGIN UPDATE job_seekers SET address='Ruhango-centre' WHERE job_giver_id=job_giver_id; END$$

DROP PROCEDURE IF EXISTS `updatej_seekers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updatej_seekers` (IN `job_seeker_id` INT(10))  BEGIN UPDATE job_seekers set Fname='muyomba' where job_seeker_id=job_seeker_ID; END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `considersubquery`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `considersubquery`;
CREATE TABLE `considersubquery` (
`pay_id` int(10)
,`pay_model` varchar(20)
,`amount` int(7)
,`date_of_payment` date
,`job_giver_id` int(10)
,`job_seeker_id` int(10)
,`task_id` int(10)
,`reason_of_payment` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `epayments`
--

DROP TABLE IF EXISTS `epayments`;
CREATE TABLE `epayments` (
  `pay_id` int(10) NOT NULL,
  `pay_model` varchar(20) NOT NULL,
  `amount` int(7) NOT NULL,
  `date_of_payment` date NOT NULL,
  `job_giver_id` int(10) NOT NULL,
  `job_seeker_id` int(10) NOT NULL,
  `task_id` int(10) NOT NULL,
  `reason_of_payment` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `epayments`
--

INSERT INTO `epayments` (`pay_id`, `pay_model`, `amount`, `date_of_payment`, `job_giver_id`, `job_seeker_id`, `task_id`, `reason_of_payment`) VALUES
(1, 'Bank', 50000, '2022-07-27', 1, 1, 1, 'half payment'),
(3, 'Bank', 27000, '2022-07-27', 3, 2, 3, 'Completion of task');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertintojob_seekers`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `insertintojob_seekers`;
CREATE TABLE `insertintojob_seekers` (
`job_seeker_id` int(10)
,`national_id` int(16)
,`fname` varchar(20)
,`lname` varchar(15)
,`DOB` date
,`gender` varchar(6)
,`address` varchar(20)
,`contacts` int(15)
,`email` varchar(25)
,`field_of_interest` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_into_epayments`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `insert_into_epayments`;
CREATE TABLE `insert_into_epayments` (
`pay_id` int(10)
,`pay_model` varchar(20)
,`amount` int(7)
,`date_of_payment` date
,`job_giver_id` int(10)
,`job_seeker_id` int(10)
,`task_id` int(10)
,`reason_of_payment` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_into_job_giver`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `insert_into_job_giver`;
CREATE TABLE `insert_into_job_giver` (
`job_giver_id` int(10)
,`national_id` int(16)
,`fname` varchar(20)
,`lname` varchar(15)
,`DOB` date
,`gender` varchar(6)
,`address` varchar(20)
,`contacts` int(15)
,`email` varchar(25)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_into_tasks`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `insert_into_tasks`;
CREATE TABLE `insert_into_tasks` (
`task_id` int(10)
,`task_name` varchar(20)
,`type_of_task` varchar(20)
,`duration` varchar(20)
,`starting_dates` date
,`job_giver_id` int(10)
,`job_seeker_id` int(10)
,`payment_per_hour` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_into_users`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `insert_into_users`;
CREATE TABLE `insert_into_users` (
`user_id` int(10)
,`user_type` varchar(10)
,`username` varchar(20)
,`passphrase` varchar(10)
,`job_giver_id` int(10)
,`job_seeker_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `job_givers`
--

DROP TABLE IF EXISTS `job_givers`;
CREATE TABLE `job_givers` (
  `job_giver_id` int(10) NOT NULL,
  `national_id` int(16) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `DOB` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `address` varchar(20) NOT NULL,
  `contacts` int(15) NOT NULL,
  `email` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job_givers`
--

INSERT INTO `job_givers` (`job_giver_id`, `national_id`, `fname`, `lname`, `DOB`, `gender`, `address`, `contacts`, `email`) VALUES
(1, 1199780646, 'RUGWIRO', 'Eric', '1997-01-01', 'Male', 'Muhanga-Nyamabuye', 786412456, 'rugwiro@gmail.com'),
(3, 1199580646, 'MUKAMA', 'Godrey', '1995-01-01', 'Male', 'Kigali-kanombe', 786112457, 'mukama@gmail.com'),
(4, 1199580685, 'HAKIZIMANA', 'Muhajiri', '1995-01-01', 'Male', 'Rwamagana-kigabiro', 786112454, 'hakizimana@gmail.com'),
(5, 1199580679, 'HAKuZIMANA', 'Cedric', '1995-01-23', 'Male', 'Rwamagana-sovu', 786112454, 'hakuzimana@gmail.com'),
(6, 2147483647, 'RUKUNDO', '', '1993-12-01', 'male', 'muhanga-nyamabuye', 788456754, 'rukundo@gmail.com');

--
-- Triggers `job_givers`
--
DROP TRIGGER IF EXISTS `after_delete_job_giver`;
DELIMITER $$
CREATE TRIGGER `after_delete_job_giver` AFTER DELETE ON `job_givers` FOR EACH ROW BEGIN
DELETE from users where users.job_giver_id=OLD.job_giver_id;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `after_update_job_givers`;
DELIMITER $$
CREATE TRIGGER `after_update_job_givers` AFTER UPDATE ON `job_givers` FOR EACH ROW BEGIN
UPDATE users set users.natoinal_Id=CONCAT(NEW.Fname,'@',NEW.Lname )WHERE users.job_giver_id
=NEW.job_giver_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `job_seekers`
--

DROP TABLE IF EXISTS `job_seekers`;
CREATE TABLE `job_seekers` (
  `job_seeker_id` int(10) NOT NULL,
  `national_id` int(16) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `DOB` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `address` varchar(20) NOT NULL,
  `contacts` int(15) NOT NULL,
  `email` varchar(25) NOT NULL,
  `field_of_interest` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job_seekers`
--

INSERT INTO `job_seekers` (`job_seeker_id`, `national_id`, `fname`, `lname`, `DOB`, `gender`, `address`, `contacts`, `email`, `field_of_interest`) VALUES
(1, 1199880646, 'muyomba', '', '1995-01-01', 'Male', 'Ruhango-centre', 786112456, 'mugisha@gmail.co', 'Carpentry'),
(2, 1199580647, 'muyomba', '', '2000-01-01', 'Female', 'Ruhango-centre', 786112456, 'cyakwera@gmail.com', 'Tailoring'),
(3, 1199580674, 'muyomba', '', '2000-01-23', 'Male', 'Ruhango-centre', 786112455, 'cyusa@gmail.com', 'Electrician'),
(4, 1199580674, 'muyomba', '', '1997-01-01', 'Male', 'Ruhango-centre', 786112454, 'micasa@gmail.com', 'Carpentry');

--
-- Triggers `job_seekers`
--
DROP TRIGGER IF EXISTS `after_delete_job_seeker`;
DELIMITER $$
CREATE TRIGGER `after_delete_job_seeker` AFTER DELETE ON `job_seekers` FOR EACH ROW BEGIN
DELETE from users where users.job_seeker_id_ID=OLD.job_seeker_ID;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `after_insert_new_job_seeker`;
DELIMITER $$
CREATE TRIGGER `after_insert_new_job_seeker` AFTER INSERT ON `job_seekers` FOR EACH ROW BEGIN
UPDATE job_seekers set job_seekers.Comments='you are at the right place to find  whta to do' WHERE job_seekers.job_seeker_ID=NEW.job_seeker_ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `task_id` int(10) NOT NULL,
  `task_name` varchar(20) NOT NULL,
  `type_of_task` varchar(20) NOT NULL,
  `duration` varchar(20) DEFAULT NULL,
  `starting_dates` date NOT NULL,
  `job_giver_id` int(10) NOT NULL,
  `job_seeker_id` int(10) NOT NULL,
  `payment_per_hour` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `task_name`, `type_of_task`, `duration`, `starting_dates`, `job_giver_id`, `job_seeker_id`, `payment_per_hour`) VALUES
(1, 'Carpentry', 'on field', '24_hours', '2022-07-26', 1, 1, 1000),
(3, 'tailoring', 'own place', '24-hours', '2022-06-26', 3, 2, 500);

--
-- Triggers `tasks`
--
DROP TRIGGER IF EXISTS `after_insert_new_task`;
DELIMITER $$
CREATE TRIGGER `after_insert_new_task` AFTER INSERT ON `tasks` FOR EACH ROW BEGIN
UPDATE borrow set tasks.Comments='task added' WHERE tasks.task_ID=NEW.task_ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `updateusers`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `updateusers`;
CREATE TABLE `updateusers` (
`user_id` int(10)
,`user_type` varchar(10)
,`username` varchar(20)
,`passphrase` varchar(10)
,`job_giver_id` int(10)
,`job_seeker_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `passphrase` varchar(10) NOT NULL,
  `job_giver_id` int(10) DEFAULT NULL,
  `job_seeker_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_type`, `username`, `passphrase`, `job_giver_id`, `job_seeker_id`) VALUES
(2, 'job giver', 'alexis123', 'rugwi123', 1, NULL),
(3, 'job giver', 'rugwiro', 'rugwi123', 1, NULL),
(4, 'job giver', 'mukama', 'mukamana', 3, NULL),
(6, 'job seeker', 'cyakwera', 'cyakwera12', NULL, 2),
(7, 'job seeker', 'cyusa', 'cyusaaaaa', NULL, 3);

-- --------------------------------------------------------

--
-- Structure for view `considersubquery`
--
DROP TABLE IF EXISTS `considersubquery`;

DROP VIEW IF EXISTS `considersubquery`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `considersubquery`  AS  select `epayments`.`pay_id` AS `pay_id`,`epayments`.`pay_model` AS `pay_model`,`epayments`.`amount` AS `amount`,`epayments`.`date_of_payment` AS `date_of_payment`,`epayments`.`job_giver_id` AS `job_giver_id`,`epayments`.`job_seeker_id` AS `job_seeker_id`,`epayments`.`task_id` AS `task_id`,`epayments`.`reason_of_payment` AS `reason_of_payment` from `epayments` ;

-- --------------------------------------------------------

--
-- Structure for view `insertintojob_seekers`
--
DROP TABLE IF EXISTS `insertintojob_seekers`;

DROP VIEW IF EXISTS `insertintojob_seekers`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertintojob_seekers`  AS  select `job_seekers`.`job_seeker_id` AS `job_seeker_id`,`job_seekers`.`national_id` AS `national_id`,`job_seekers`.`fname` AS `fname`,`job_seekers`.`lname` AS `lname`,`job_seekers`.`DOB` AS `DOB`,`job_seekers`.`gender` AS `gender`,`job_seekers`.`address` AS `address`,`job_seekers`.`contacts` AS `contacts`,`job_seekers`.`email` AS `email`,`job_seekers`.`field_of_interest` AS `field_of_interest` from `job_seekers` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_into_epayments`
--
DROP TABLE IF EXISTS `insert_into_epayments`;

DROP VIEW IF EXISTS `insert_into_epayments`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_into_epayments`  AS  select `epayments`.`pay_id` AS `pay_id`,`epayments`.`pay_model` AS `pay_model`,`epayments`.`amount` AS `amount`,`epayments`.`date_of_payment` AS `date_of_payment`,`epayments`.`job_giver_id` AS `job_giver_id`,`epayments`.`job_seeker_id` AS `job_seeker_id`,`epayments`.`task_id` AS `task_id`,`epayments`.`reason_of_payment` AS `reason_of_payment` from `epayments` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_into_job_giver`
--
DROP TABLE IF EXISTS `insert_into_job_giver`;

DROP VIEW IF EXISTS `insert_into_job_giver`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_into_job_giver`  AS  select `job_givers`.`job_giver_id` AS `job_giver_id`,`job_givers`.`national_id` AS `national_id`,`job_givers`.`fname` AS `fname`,`job_givers`.`lname` AS `lname`,`job_givers`.`DOB` AS `DOB`,`job_givers`.`gender` AS `gender`,`job_givers`.`address` AS `address`,`job_givers`.`contacts` AS `contacts`,`job_givers`.`email` AS `email` from `job_givers` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_into_tasks`
--
DROP TABLE IF EXISTS `insert_into_tasks`;

DROP VIEW IF EXISTS `insert_into_tasks`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_into_tasks`  AS  select `tasks`.`task_id` AS `task_id`,`tasks`.`task_name` AS `task_name`,`tasks`.`type_of_task` AS `type_of_task`,`tasks`.`duration` AS `duration`,`tasks`.`starting_dates` AS `starting_dates`,`tasks`.`job_giver_id` AS `job_giver_id`,`tasks`.`job_seeker_id` AS `job_seeker_id`,`tasks`.`payment_per_hour` AS `payment_per_hour` from `tasks` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_into_users`
--
DROP TABLE IF EXISTS `insert_into_users`;

DROP VIEW IF EXISTS `insert_into_users`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_into_users`  AS  select `users`.`user_id` AS `user_id`,`users`.`user_type` AS `user_type`,`users`.`username` AS `username`,`users`.`passphrase` AS `passphrase`,`users`.`job_giver_id` AS `job_giver_id`,`users`.`job_seeker_id` AS `job_seeker_id` from `users` ;

-- --------------------------------------------------------

--
-- Structure for view `updateusers`
--
DROP TABLE IF EXISTS `updateusers`;

DROP VIEW IF EXISTS `updateusers`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updateusers`  AS  select `users`.`user_id` AS `user_id`,`users`.`user_type` AS `user_type`,`users`.`username` AS `username`,`users`.`passphrase` AS `passphrase`,`users`.`job_giver_id` AS `job_giver_id`,`users`.`job_seeker_id` AS `job_seeker_id` from `users` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `epayments`
--
ALTER TABLE `epayments`
  ADD PRIMARY KEY (`pay_id`),
  ADD KEY `job_giver_id` (`job_giver_id`,`job_seeker_id`,`task_id`),
  ADD KEY `job_seeker_id` (`job_seeker_id`);

--
-- Indexes for table `job_givers`
--
ALTER TABLE `job_givers`
  ADD PRIMARY KEY (`job_giver_id`);

--
-- Indexes for table `job_seekers`
--
ALTER TABLE `job_seekers`
  ADD PRIMARY KEY (`job_seeker_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `job_giver_id` (`job_giver_id`,`job_seeker_id`),
  ADD KEY `job_seeker_id` (`job_seeker_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `job_seeker_id` (`job_seeker_id`,`job_giver_id`),
  ADD KEY `job_giver_id` (`job_giver_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `epayments`
--
ALTER TABLE `epayments`
  MODIFY `pay_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_givers`
--
ALTER TABLE `job_givers`
  MODIFY `job_giver_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `job_seekers`
--
ALTER TABLE `job_seekers`
  MODIFY `job_seeker_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `task_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `epayments`
--
ALTER TABLE `epayments`
  ADD CONSTRAINT `epayments_ibfk_1` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`job_seeker_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `epayments_ibfk_2` FOREIGN KEY (`job_giver_id`) REFERENCES `job_givers` (`job_giver_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`job_seeker_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`job_giver_id`) REFERENCES `job_givers` (`job_giver_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`job_giver_id`) REFERENCES `job_givers` (`job_giver_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`job_seeker_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
