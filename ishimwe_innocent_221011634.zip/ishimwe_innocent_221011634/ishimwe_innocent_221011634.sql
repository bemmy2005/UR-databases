-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2022 at 10:42 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ishimwe_innocent_221011634`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DELETENURSE` ()  BEGIN
DELETE FROM `nurse` WHERE `nurse`.`nid` = 4;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DELETERECEPTIONIST` ()  BEGIN
DELETE FROM `receptonist` WHERE `receptonist`.`recid` = 6;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GETCASHIEER` ()  BEGIN
SELECT * FROM `cashier`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDOCTOR` ()  BEGIN
SELECT * FROM `doctor`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMEDECINE` ()  BEGIN
SELECT * FROM `releasemedecine`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNURSE` ()  BEGIN
SELECT * FROM `nurse`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPATIENT` ()  BEGIN
SELECT * FROM `patient`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPAYMENT` ()  BEGIN
SELECT * FROM `payment`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPHARMACIST` ()  BEGIN
SELECT * FROM `pharmacist`s;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getreceptionist` ()  BEGIN
SELECT * FROM `receptionist`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTREATMENT` ()  BEGIN
SELECT * FROM `treatment`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getVERIFY_PAY` ()  BEGIN
SELECT * FROM `verify_pay`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTCASHIER` ()  BEGIN
INSERT INTO `cashier` (`cid`, `cfname`, `clname`, `cemail`, `ctellnumber`, `cusername`, `cpassword`) VALUES ('1', 'Ngabonziza', 'olvier', 'ngabonziza@gmail.com', '0735673927', 'olvierngabo', 'ngabo123');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTDOCTOR` ()  BEGIN
INSERT INTO `doctor` (`did`, `dfname`, `dlname`, `demail`, `dtellnumber`, `dusername`, `dpassword`) VALUES ('1', 'Rurangwa', 'Alexis', 'rurangwaa@gmail.com', '0788845673', 'rurangwaalexis', 'alex456');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTMEDECINE` ()  BEGIN
INSERT INTO `medecine` (`mid`, `mname`, `mprice_unit`, `mquantity`, `mmfgdate`, `mexpdate`, `mtotal`) VALUES ('3', 'Coaltem', '1000', '100mg', '2022-07-07', '2031-07-18', '200000');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTNURSE` ()  BEGIN
INSERT INTO `nurse` (`nid`, `nfname`, `nlname`, `nemail`, `ntellnumber`, `nusername`, `npassword`) VALUES ('1', 'Maniriho', 'paul', 'maniriho@gmail.com', '078886786', 'maniriho', 'maniriho123'), ('2', 'Serugo', 'Alex', 'serugoalex@gmail.com', '0734579279', 'serugoalex', 'serugo123');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `iNSERTpATIENT` ()  BEGIN
INSERT INTO `patient` (`pid`, `pfname`, `plname`, `pgender`, `pbirthdate`, `pcountry`, `pprovince`, `pdistrict`, `psector`, `pcell`, `pvillage`, `pinsurance`, `pidnumber`, `recid`) VALUES (NULL, 'Uwera', 'bernadete', 'F', '1999-07-06', 'Rwanda', 'East', 'Kayonza', 'Bugarama', 'Cyarwa', 'Nzove', 'Mituel', '1119997659', '3');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTPHARMACIST` ()  BEGIN
INSERT INTO `pharmacist` (`phid`, `phfname`, `phlname`, `phemail`, `phtellnumber`, `phusername`, `phpassword`) VALUES ('1', 'Uwase', 'Kelia', 'uwasekwlia@gmail.com', '0788564978', 'uwasekeli', 'uwase123'), ('2', 'Uwase', 'Mami', 'uwasemami@gmail.com', '078856375', 'uwasemami', 'mami345');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTRECEPTIONIST` ()  BEGIN
INSERT INTO `receptionist` (`recid`, `rfname`, `rlname`, `remail`, `rtellnumber`, `rusername`, `rpassword`) VALUES (NULL, 'Ishimwe', 'Icent', 'ishimwe@gmail.com', '078857578855', 'Icentkings', '0785228278'), (NULL, 'Pacifique', 'gggggg', 'pgg@gmail.com', '0785275572', 'gagaclaide', '123456789');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTRELEASEMEDECINE` ()  BEGIN
INSERT INTO `releasemedecine` (`reid`, `phid`, `tid`, `decision`) VALUES ('1', '1', '1', 'got medicine'), ('2', '2', '2', 'got medicine');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTTREATMENT` ()  BEGIN
INSERT INTO `treatment` (`tid`, `nid`, `did`, `pid`, `theight`, `tsymptoms`, `texams`, `tquantity`, `tpressure`, `tkg`, `mid`, `ttotal`) VALUES ('1', '1', '1', '1', '1.60', 'diarhea', 'chorela', '1', '130', '65', '2', '3000'), ('2', '2', '2', '2', '60', 'headache', 'bloodpressure', '1', '180', '90', '1', '7000');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERTVERIFY_PAY` ()  BEGIN
INSERT INTO `verify_pay` (`vid`, `paid`, `cid`) VALUES ('1', '1', '1'), ('2', '2', '2');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Storedpwithsubquery` ()  BEGIN
    CREATE VIEW viewwithsubquery as (SELECT mname,mprice_unit,mquantity,mmfgdate,mexpdate,mtotal,paamount FROM medecine join treatment on medecine.mid=treatment.mid join payment on treatment.tid=payment.tid WHERE paamount>(SELECT AVG(paamount) from payment));
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UPDATECASHIER` ()  BEGIN
UPDATE `cashier` SET `clname` = 'Pacifique' WHERE `cashier`.`cid` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UPDATEDOCTOR` ()  BEGIN
UPDATE `doctor` SET `dfname` = 'Kamana', `dlname` = 'Issa' WHERE `doctor`.`did` = 1;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `cid` int(5) NOT NULL,
  `cfname` varchar(10) NOT NULL,
  `clname` varchar(10) NOT NULL,
  `cemail` varchar(15) NOT NULL,
  `ctellnumber` bigint(12) NOT NULL,
  `cusername` varchar(10) NOT NULL,
  `cpassword` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`cid`, `cfname`, `clname`, `cemail`, `ctellnumber`, `cusername`, `cpassword`) VALUES
(1, 'Ngabonziza', 'Pacifique', 'ngabonziza@gmai', 735673927, 'olvierngab', 'ngabo123'),
(2, 'Semana', 'Kalim', 'semana@gmail.co', 781239755, 'kalimsema', 'kalim123'),
(3, 'Teta', 'Frolance', 'frolnce@gmail.c', 788456893, 'tetafrola', 'frolance12'),
(5, 'Ngabonziza', 'olbhuovier', 'ngabonziza@gmai', 735673927, 'olviernhkg', 'ngabo123'),
(7, 'Ngabonziza', 'olbhuovier', 'ngabonziza@gmai', 735673927, 'olviernhkg', 'ngabo123');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `did` int(5) NOT NULL,
  `dfname` varchar(10) NOT NULL,
  `dlname` varchar(10) NOT NULL,
  `demail` varchar(15) NOT NULL,
  `dtellnumber` bigint(12) NOT NULL,
  `dusername` varchar(10) NOT NULL,
  `dpassword` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`did`, `dfname`, `dlname`, `demail`, `dtellnumber`, `dusername`, `dpassword`) VALUES
(1, 'Kamana', 'Issa', 'rurangwaa@gmail', 788845673, 'rurangwaal', 'alex456'),
(2, 'Rugaragara', 'Joseph', 'rugaragara@gmai', 788888123, 'josephruga', 'ruga1245'),
(3, 'MUKASEKURU', 'Alice', 'mukasekuru@gmai', 788888888, 'alicemuka@', 'alice7890'),
(5, 'Rurangwa', 'Alhoexis', 'rurangwaa@gmail', 788845673, 'rurhvjangw', 'alex456'),
(9, 'Rurangwa', 'Alhoexis', 'rurangwaa@gmail', 788845673, 'rurhvjangw', 'alex456');

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofcashier`
-- (See below for the actual view)
--
CREATE TABLE `listofcashier` (
`cid` int(5)
,`cfname` varchar(10)
,`clname` varchar(10)
,`cemail` varchar(15)
,`ctellnumber` bigint(12)
,`cusername` varchar(10)
,`cpassword` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofdoctor`
-- (See below for the actual view)
--
CREATE TABLE `listofdoctor` (
`did` int(5)
,`dfname` varchar(10)
,`dlname` varchar(10)
,`demail` varchar(15)
,`dtellnumber` bigint(12)
,`dusername` varchar(10)
,`dpassword` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofmedecine`
-- (See below for the actual view)
--
CREATE TABLE `listofmedecine` (
`mid` int(5)
,`mname` varchar(20)
,`mprice_unit` float
,`mquantity` varchar(5)
,`mmfgdate` date
,`mexpdate` date
,`mtotal` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofnurse`
-- (See below for the actual view)
--
CREATE TABLE `listofnurse` (
`nid` int(5)
,`nfname` varchar(10)
,`nlname` varchar(10)
,`nemail` varchar(10)
,`ntellnumber` bigint(12)
,`nusername` varchar(10)
,`npassword` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofpatient`
-- (See below for the actual view)
--
CREATE TABLE `listofpatient` (
`pid` int(7)
,`pfname` varchar(15)
,`plname` varchar(15)
,`pgender` varchar(1)
,`pbirthdate` date
,`pcountry` varchar(10)
,`pprovince` varchar(10)
,`pdistrict` varchar(10)
,`psector` varchar(10)
,`pcell` varchar(10)
,`pvillage` varchar(10)
,`pinsurance` varchar(15)
,`pidnumber` int(16)
,`recid` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofpayment`
-- (See below for the actual view)
--
CREATE TABLE `listofpayment` (
`paid` int(5)
,`padate` date
,`paamount` int(11)
,`tid` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofpharmacist`
-- (See below for the actual view)
--
CREATE TABLE `listofpharmacist` (
`phid` int(5)
,`phfname` varchar(10)
,`phlname` varchar(10)
,`phemail` varchar(15)
,`phtellnumber` bigint(12)
,`phusername` varchar(10)
,`phpassword` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofreceptonist`
-- (See below for the actual view)
--
CREATE TABLE `listofreceptonist` (
`recid` int(5)
,`rfname` varchar(10)
,`rlname` varchar(10)
,`remail` varchar(15)
,`rtellnumber` bigint(12)
,`rusername` varchar(10)
,`rpassword` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofreleasemedecine`
-- (See below for the actual view)
--
CREATE TABLE `listofreleasemedecine` (
`reid` int(5)
,`phid` int(5)
,`tid` int(5)
,`decision` varchar(15)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listoftreatment`
-- (See below for the actual view)
--
CREATE TABLE `listoftreatment` (
`tid` int(5)
,`nid` int(5)
,`did` int(5)
,`pid` int(5)
,`theight` float
,`tsymptoms` varchar(50)
,`texams` varchar(50)
,`tquantity` int(10)
,`tpressure` float
,`tkg` float
,`mid` int(5)
,`ttotal` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listofverify_pay`
-- (See below for the actual view)
--
CREATE TABLE `listofverify_pay` (
`vid` int(5)
,`paid` int(5)
,`cid` int(5)
);

-- --------------------------------------------------------

--
-- Table structure for table `medecine`
--

CREATE TABLE `medecine` (
  `mid` int(5) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `mprice_unit` float NOT NULL,
  `mquantity` varchar(5) NOT NULL,
  `mmfgdate` date NOT NULL,
  `mexpdate` date NOT NULL,
  `mtotal` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medecine`
--

INSERT INTO `medecine` (`mid`, `mname`, `mprice_unit`, `mquantity`, `mmfgdate`, `mexpdate`, `mtotal`) VALUES
(1, 'Palctamol', 500, '100mg', '2022-07-02', '2028-07-21', 100000),
(2, 'Asprin', 500, '50mg', '2022-07-18', '2027-07-28', 50000),
(3, 'Coaltem', 1000, '100mg', '2022-07-07', '2031-07-18', 200000),
(11, 'Palctamol', 500, '130mg', '2022-07-02', '2028-09-21', 180000);

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE `nurse` (
  `nid` int(5) NOT NULL,
  `nfname` varchar(10) NOT NULL,
  `nlname` varchar(10) NOT NULL,
  `nemail` varchar(10) NOT NULL,
  `ntellnumber` bigint(12) NOT NULL,
  `nusername` varchar(10) NOT NULL,
  `npassword` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`nid`, `nfname`, `nlname`, `nemail`, `ntellnumber`, `nusername`, `npassword`) VALUES
(1, 'Maniriho', 'paul', 'maniriho@g', 78886786, 'maniriho', 'maniriho12'),
(2, 'Serugo', 'Alex', 'serugoalex', 734579279, 'serugoalex', 'serugo123'),
(3, 'Uwayo', 'Samuel', 'uwayosamue', 72476885, 'uwayosamue', 'uwayo123');

--
-- Triggers `nurse`
--
DELIMITER $$
CREATE TRIGGER `DELETENURSE` AFTER INSERT ON `nurse` FOR EACH ROW BEGIN  
DELETE FROM `nurse` WHERE `listofnurse`.`nid` = 4; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(7) NOT NULL,
  `pfname` varchar(15) NOT NULL,
  `plname` varchar(15) NOT NULL,
  `pgender` varchar(1) NOT NULL,
  `pbirthdate` date NOT NULL,
  `pcountry` varchar(10) NOT NULL,
  `pprovince` varchar(10) NOT NULL,
  `pdistrict` varchar(10) NOT NULL,
  `psector` varchar(10) NOT NULL,
  `pcell` varchar(10) NOT NULL,
  `pvillage` varchar(10) NOT NULL,
  `pinsurance` varchar(15) NOT NULL,
  `pidnumber` int(16) NOT NULL,
  `recid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pfname`, `plname`, `pgender`, `pbirthdate`, `pcountry`, `pprovince`, `pdistrict`, `psector`, `pcell`, `pvillage`, `pinsurance`, `pidnumber`, `recid`) VALUES
(1, 'Gakuru', 'Jean cluade', 'F', '2022-07-06', 'kumbuto', 'kuturabo', 'kumababi', 'kushami', 'kugiti', 'umuzi', 'Misur', 1224557886, 1),
(2, 'Habiyaremye', 'joseph', 'M', '2022-07-04', 'Rwanda', 'West', 'Rubavu', 'Mahoko', 'kanama', 'kanam', 'Rama', 220224252, 2),
(3, 'Uwera', 'bernadete', 'F', '1999-07-06', 'Rwanda', 'East', 'Kayonza', 'Bugarama', 'cyarwa', 'nzove', 'Mituel', 1119997659, 3),
(4, 'Gaghhhkuru', 'Jean cluade', 'F', '2022-07-06', 'kumbuto', 'kuturabo', 'kumayugbab', 'kushami', 'kugiti', 'umuzi', 'Misur', 1224557886, 1),
(5, 'Gaghhhkuru', 'Jean cluade', 'F', '2022-07-06', 'kumbuto', 'kuturabo', 'kumayugbab', 'kushami', 'kugiti', 'umuzi', 'Misur', 1224557886, 1),
(6, 'Gaghhhkuru', 'Jean cluade', 'F', '2022-07-06', 'kumbuto', 'kuturabo', 'kumayugbab', 'kushami', 'kugiti', 'umuzi', 'Misur', 1224557886, 1);

--
-- Triggers `patient`
--
DELIMITER $$
CREATE TRIGGER `UPDATEPATIENT` AFTER INSERT ON `patient` FOR EACH ROW BEGIN  
UPDATE `patient` SET `pfname` = 'Habiyaremye', `plname` = 'joseph' WHERE `patient`.`pid` = 2; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertPATIENT` AFTER INSERT ON `patient` FOR EACH ROW BEGIN  
INSERT INTO `patient` (`pid`, `pfname`, `plname`, `pgender`, `pbirthdate`, `pcountry`, `pprovince`, `pdistrict`, `psector`, `pcell`, `pvillage`, `pinsurance`, `pidnumber`, `recid`) VALUES (NULL, 'Uwera', 'bernadete', 'F', '1999-07-06', 'Rwanda', 'East', 'Kayonza', 'Bugarama', 'Cyarwa', 'Nzove', 'Mituel', '1119997659', '3'); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paid` int(5) NOT NULL,
  `padate` date NOT NULL,
  `paamount` int(11) NOT NULL,
  `tid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`paid`, `padate`, `paamount`, `tid`) VALUES
(1, '2022-07-30', 3000, 1),
(2, '2022-07-20', 4000, 2),
(3, '2022-07-31', 2500, 3);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `phid` int(5) NOT NULL,
  `phfname` varchar(10) NOT NULL,
  `phlname` varchar(10) NOT NULL,
  `phemail` varchar(15) NOT NULL,
  `phtellnumber` bigint(12) NOT NULL,
  `phusername` varchar(10) NOT NULL,
  `phpassword` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`phid`, `phfname`, `phlname`, `phemail`, `phtellnumber`, `phusername`, `phpassword`) VALUES
(1, 'Uwase', 'Kelia', 'uwasekwlia@gmai', 788564978, 'uwasekeli', 'uwase123'),
(2, 'Uwase', 'Mami', 'uwasemami@gmail', 78856375, 'uwasemami', 'mami345'),
(3, 'Umukundwa', 'Caline', 'kevine@gmail.co', 723586654, 'uwusakevin', 'uwusa1245'),
(8, 'Uwase', 'Kejiolia', 'uwasekwlia@gmai', 788564978, 'uwasehuoke', 'uwase123');

--
-- Triggers `pharmacist`
--
DELIMITER $$
CREATE TRIGGER `UPDATEPHARMACIST` AFTER INSERT ON `pharmacist` FOR EACH ROW BEGIN  
UPDATE `pharmacist` SET `phfname` = 'Umukundwa', `phlname` = 'Caline' WHERE `pharmacist`.`phid` = 3; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `receptionist`
--

CREATE TABLE `receptionist` (
  `recid` int(5) NOT NULL,
  `rfname` varchar(10) NOT NULL,
  `rlname` varchar(10) NOT NULL,
  `remail` varchar(15) NOT NULL,
  `rtellnumber` bigint(12) NOT NULL,
  `rusername` varchar(10) NOT NULL,
  `rpassword` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receptionist`
--

INSERT INTO `receptionist` (`recid`, `rfname`, `rlname`, `remail`, `rtellnumber`, `rusername`, `rpassword`) VALUES
(1, 'Ishimwe', 'Icent', 'ishimwe@gmail.c', 78857578855, 'Icentkings', '0785228278'),
(2, 'Pacifique', 'gggggg', 'pgg@gmail.com', 785275572, 'gagaclaide', '123456789'),
(3, 'uwimana', 'marie', 'uwimana@gmail.c', 726578945, 'uwimanamar', '135790135'),
(4, 'Ishimwevvj', 'Icentctut', 'ishimwe@gmail.c', 78857578855, 'Icentkings', '0785228278'),
(5, 'Ishimwevvj', 'Icentctut', 'ishimwe@gmail.c', 78857578855, 'Icentkings', '0785228278');

--
-- Triggers `receptionist`
--
DELIMITER $$
CREATE TRIGGER `DELETERECEPTIONIST` AFTER INSERT ON `receptionist` FOR EACH ROW BEGIN  
DELETE FROM `listofreceptonist` WHERE `listofreceptonist`.`recid` = 6; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `inserRECEPTIONIST` AFTER INSERT ON `receptionist` FOR EACH ROW BEGIN  
INSERT INTO `receptionist` (`recid`, `rfname`, `rlname`, `remail`, `rtellnumber`, `rusername`, `rpassword`) VALUES (NULL, 'Ishimwe', 'Icent', 'ishimwe@gmail.com', '078857578855', 'Icentkings', '0785228278'), (NULL, 'Pacifique', 'gggggg', 'pgg@gmail.com', '0785275572', 'gagaclaide', '123456789'); 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `releasemedecine`
--

CREATE TABLE `releasemedecine` (
  `reid` int(5) NOT NULL,
  `phid` int(5) NOT NULL,
  `tid` int(5) NOT NULL,
  `decision` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `releasemedecine`
--

INSERT INTO `releasemedecine` (`reid`, `phid`, `tid`, `decision`) VALUES
(1, 1, 1, 'got medicine'),
(2, 2, 2, 'got medicine'),
(3, 3, 3, 'got medicine'),
(5, 3, 2, 'got medicine');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `tid` int(5) NOT NULL,
  `nid` int(5) NOT NULL,
  `did` int(5) NOT NULL,
  `pid` int(5) NOT NULL,
  `theight` float NOT NULL,
  `tsymptoms` varchar(50) NOT NULL,
  `texams` varchar(50) NOT NULL,
  `tquantity` int(10) NOT NULL,
  `tpressure` float NOT NULL,
  `tkg` float NOT NULL,
  `mid` int(5) NOT NULL,
  `ttotal` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`tid`, `nid`, `did`, `pid`, `theight`, `tsymptoms`, `texams`, `tquantity`, `tpressure`, `tkg`, `mid`, `ttotal`) VALUES
(1, 1, 1, 1, 1.6, 'diarhea', 'chorela', 1, 130, 65, 2, 3000),
(2, 2, 2, 2, 60, 'headache', 'bloodpressure', 1, 180, 90, 1, 7000),
(3, 3, 3, 3, 1.8, 'headech', 'Malaria', 1, 140, 70, 3, 2500),
(10, 1, 1, 1, 1.6, 'diarhea', 'chorela', 1, 180, 65, 2, 3000);

-- --------------------------------------------------------

--
-- Table structure for table `verify_pay`
--

CREATE TABLE `verify_pay` (
  `vid` int(5) NOT NULL,
  `paid` int(5) NOT NULL,
  `cid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `verify_pay`
--

INSERT INTO `verify_pay` (`vid`, `paid`, `cid`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(9, 3, 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewwithsubquery`
-- (See below for the actual view)
--
CREATE TABLE `viewwithsubquery` (
`mname` varchar(20)
,`mprice_unit` float
,`mquantity` varchar(5)
,`mmfgdate` date
,`mexpdate` date
,`mtotal` int(10)
,`paamount` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `listofcashier`
--
DROP TABLE IF EXISTS `listofcashier`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofcashier`  AS   (select `cashier`.`cid` AS `cid`,`cashier`.`cfname` AS `cfname`,`cashier`.`clname` AS `clname`,`cashier`.`cemail` AS `cemail`,`cashier`.`ctellnumber` AS `ctellnumber`,`cashier`.`cusername` AS `cusername`,`cashier`.`cpassword` AS `cpassword` from `cashier`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofdoctor`
--
DROP TABLE IF EXISTS `listofdoctor`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofdoctor`  AS   (select `doctor`.`did` AS `did`,`doctor`.`dfname` AS `dfname`,`doctor`.`dlname` AS `dlname`,`doctor`.`demail` AS `demail`,`doctor`.`dtellnumber` AS `dtellnumber`,`doctor`.`dusername` AS `dusername`,`doctor`.`dpassword` AS `dpassword` from `doctor`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofmedecine`
--
DROP TABLE IF EXISTS `listofmedecine`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofmedecine`  AS   (select `medecine`.`mid` AS `mid`,`medecine`.`mname` AS `mname`,`medecine`.`mprice_unit` AS `mprice_unit`,`medecine`.`mquantity` AS `mquantity`,`medecine`.`mmfgdate` AS `mmfgdate`,`medecine`.`mexpdate` AS `mexpdate`,`medecine`.`mtotal` AS `mtotal` from `medecine`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofnurse`
--
DROP TABLE IF EXISTS `listofnurse`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofnurse`  AS   (select `nurse`.`nid` AS `nid`,`nurse`.`nfname` AS `nfname`,`nurse`.`nlname` AS `nlname`,`nurse`.`nemail` AS `nemail`,`nurse`.`ntellnumber` AS `ntellnumber`,`nurse`.`nusername` AS `nusername`,`nurse`.`npassword` AS `npassword` from `nurse`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofpatient`
--
DROP TABLE IF EXISTS `listofpatient`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofpatient`  AS   (select `patient`.`pid` AS `pid`,`patient`.`pfname` AS `pfname`,`patient`.`plname` AS `plname`,`patient`.`pgender` AS `pgender`,`patient`.`pbirthdate` AS `pbirthdate`,`patient`.`pcountry` AS `pcountry`,`patient`.`pprovince` AS `pprovince`,`patient`.`pdistrict` AS `pdistrict`,`patient`.`psector` AS `psector`,`patient`.`pcell` AS `pcell`,`patient`.`pvillage` AS `pvillage`,`patient`.`pinsurance` AS `pinsurance`,`patient`.`pidnumber` AS `pidnumber`,`patient`.`recid` AS `recid` from `patient`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofpayment`
--
DROP TABLE IF EXISTS `listofpayment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofpayment`  AS   (select `payment`.`paid` AS `paid`,`payment`.`padate` AS `padate`,`payment`.`paamount` AS `paamount`,`payment`.`tid` AS `tid` from `payment`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofpharmacist`
--
DROP TABLE IF EXISTS `listofpharmacist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofpharmacist`  AS   (select `pharmacist`.`phid` AS `phid`,`pharmacist`.`phfname` AS `phfname`,`pharmacist`.`phlname` AS `phlname`,`pharmacist`.`phemail` AS `phemail`,`pharmacist`.`phtellnumber` AS `phtellnumber`,`pharmacist`.`phusername` AS `phusername`,`pharmacist`.`phpassword` AS `phpassword` from `pharmacist`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofreceptonist`
--
DROP TABLE IF EXISTS `listofreceptonist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofreceptonist`  AS   (select `receptionist`.`recid` AS `recid`,`receptionist`.`rfname` AS `rfname`,`receptionist`.`rlname` AS `rlname`,`receptionist`.`remail` AS `remail`,`receptionist`.`rtellnumber` AS `rtellnumber`,`receptionist`.`rusername` AS `rusername`,`receptionist`.`rpassword` AS `rpassword` from `receptionist`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofreleasemedecine`
--
DROP TABLE IF EXISTS `listofreleasemedecine`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofreleasemedecine`  AS   (select `releasemedecine`.`reid` AS `reid`,`releasemedecine`.`phid` AS `phid`,`releasemedecine`.`tid` AS `tid`,`releasemedecine`.`decision` AS `decision` from `releasemedecine`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listoftreatment`
--
DROP TABLE IF EXISTS `listoftreatment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listoftreatment`  AS   (select `treatment`.`tid` AS `tid`,`treatment`.`nid` AS `nid`,`treatment`.`did` AS `did`,`treatment`.`pid` AS `pid`,`treatment`.`theight` AS `theight`,`treatment`.`tsymptoms` AS `tsymptoms`,`treatment`.`texams` AS `texams`,`treatment`.`tquantity` AS `tquantity`,`treatment`.`tpressure` AS `tpressure`,`treatment`.`tkg` AS `tkg`,`treatment`.`mid` AS `mid`,`treatment`.`ttotal` AS `ttotal` from `treatment`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listofverify_pay`
--
DROP TABLE IF EXISTS `listofverify_pay`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listofverify_pay`  AS   (select `verify_pay`.`vid` AS `vid`,`verify_pay`.`paid` AS `paid`,`verify_pay`.`cid` AS `cid` from `verify_pay`)  ;

-- --------------------------------------------------------

--
-- Structure for view `viewwithsubquery`
--
DROP TABLE IF EXISTS `viewwithsubquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewwithsubquery`  AS   (select `medecine`.`mname` AS `mname`,`medecine`.`mprice_unit` AS `mprice_unit`,`medecine`.`mquantity` AS `mquantity`,`medecine`.`mmfgdate` AS `mmfgdate`,`medecine`.`mexpdate` AS `mexpdate`,`medecine`.`mtotal` AS `mtotal`,`payment`.`paamount` AS `paamount` from ((`medecine` join `treatment` on(`medecine`.`mid` = `treatment`.`mid`)) join `payment` on(`treatment`.`tid` = `payment`.`tid`)) where `payment`.`paamount` > (select avg(`payment`.`paamount`) from `payment`))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `medecine`
--
ALTER TABLE `medecine`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `nurse`
--
ALTER TABLE `nurse`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `recid` (`recid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paid`),
  ADD KEY `tid` (`tid`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`phid`);

--
-- Indexes for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD PRIMARY KEY (`recid`);

--
-- Indexes for table `releasemedecine`
--
ALTER TABLE `releasemedecine`
  ADD PRIMARY KEY (`reid`),
  ADD KEY `phid` (`phid`),
  ADD KEY `tid` (`tid`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `nid` (`nid`),
  ADD KEY `did` (`did`),
  ADD KEY `pid` (`pid`),
  ADD KEY `mid` (`mid`);

--
-- Indexes for table `verify_pay`
--
ALTER TABLE `verify_pay`
  ADD PRIMARY KEY (`vid`),
  ADD KEY `paid` (`paid`),
  ADD KEY `cid` (`cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cashier`
--
ALTER TABLE `cashier`
  MODIFY `cid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `did` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `medecine`
--
ALTER TABLE `medecine`
  MODIFY `mid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `nurse`
--
ALTER TABLE `nurse`
  MODIFY `nid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `phid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `receptionist`
--
ALTER TABLE `receptionist`
  MODIFY `recid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `releasemedecine`
--
ALTER TABLE `releasemedecine`
  MODIFY `reid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `treatment`
--
ALTER TABLE `treatment`
  MODIFY `tid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `verify_pay`
--
ALTER TABLE `verify_pay`
  MODIFY `vid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `patient_ibfk_1` FOREIGN KEY (`recid`) REFERENCES `receptionist` (`recid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`tid`) REFERENCES `treatment` (`tid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `releasemedecine`
--
ALTER TABLE `releasemedecine`
  ADD CONSTRAINT `releasemedecine_ibfk_1` FOREIGN KEY (`tid`) REFERENCES `treatment` (`tid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `releasemedecine_ibfk_2` FOREIGN KEY (`phid`) REFERENCES `pharmacist` (`phid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `treatment`
--
ALTER TABLE `treatment`
  ADD CONSTRAINT `treatment_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `medecine` (`mid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `treatment_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `patient` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `treatment_ibfk_3` FOREIGN KEY (`did`) REFERENCES `doctor` (`did`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `treatment_ibfk_4` FOREIGN KEY (`nid`) REFERENCES `nurse` (`nid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `verify_pay`
--
ALTER TABLE `verify_pay`
  ADD CONSTRAINT `verify_pay_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `cashier` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `verify_pay_ibfk_2` FOREIGN KEY (`paid`) REFERENCES `payment` (`paid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
