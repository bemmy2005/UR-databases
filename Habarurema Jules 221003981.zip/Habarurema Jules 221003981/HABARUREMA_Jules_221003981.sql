-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 27, 2022 at 06:21 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `HABARUREMA_Jules_221003981`
--

-- --------------------------------------------------------

--
-- Table structure for table `Amount`
--

CREATE TABLE `Amount` (
  `amountId` int(6) NOT NULL,
  `amount` int(6) NOT NULL,
  `amountDescription` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Amount`
--

INSERT INTO `Amount` (`amountId`, `amount`, `amountDescription`) VALUES
(1, 500, 'amount of one meal');

-- --------------------------------------------------------

--
-- Table structure for table `Customers`
--

CREATE TABLE `Customers` (
  `customerID` int(11) NOT NULL,
  `names` varchar(250) NOT NULL,
  `phone` int(10) NOT NULL,
  `address` varchar(250) NOT NULL DEFAULT 'UR student',
  `registedDate` date NOT NULL DEFAULT current_timestamp(),
  `email` varchar(100) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Customers`
--

INSERT INTO `Customers` (`customerID`, `names`, `phone`, `address`, `registedDate`, `email`, `password`) VALUES
(1, 'HABARUREMA Jules', 789028283, 'UR student', '2022-07-26', 'habaruremajules@gmail.com', 'Jules2020');

-- --------------------------------------------------------

--
-- Table structure for table `Employer`
--

CREATE TABLE `Employer` (
  `userID` int(6) NOT NULL,
  `Names` varchar(250) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` int(250) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `roleId` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Employer`
--

INSERT INTO `Employer` (`userID`, `Names`, `Email`, `Phone`, `Password`, `roleId`) VALUES
(1, 'Jules hb 250', 'habaruremajules@gmail.com', 789028283, 'kiki@2020', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Payment`
--

CREATE TABLE `Payment` (
  `customerID` int(6) NOT NULL,
  `amount` int(6) NOT NULL,
  `paymentDate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Payment`
--

INSERT INTO `Payment` (`customerID`, `amount`, `paymentDate`) VALUES
(1, 20000, '2022-07-26');

-- --------------------------------------------------------

--
-- Table structure for table `Permissions`
--

CREATE TABLE `Permissions` (
  `permissionId` int(6) NOT NULL,
  `permissionName` varchar(250) NOT NULL,
  `permissionDescription` varchar(250) NOT NULL,
  `permissionCreatedDate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Permissions`
--

INSERT INTO `Permissions` (`permissionId`, `permissionName`, `permissionDescription`, `permissionCreatedDate`) VALUES
(1, 'you are allowed to manage all users', '', '2022-07-26');

-- --------------------------------------------------------

--
-- Table structure for table `Reservation`
--

CREATE TABLE `Reservation` (
  `customerID` int(6) NOT NULL,
  `amountId` int(6) NOT NULL DEFAULT 1,
  `time` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Reservation`
--

INSERT INTO `Reservation` (`customerID`, `amountId`, `time`) VALUES
(1, 1, '2022-07-26');

-- --------------------------------------------------------

--
-- Table structure for table `Roles`
--

CREATE TABLE `Roles` (
  `roleId` int(6) NOT NULL,
  `roleName` varchar(50) NOT NULL,
  `roleDescription` varchar(250) NOT NULL,
  `roleCreatedDate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Roles`
--

INSERT INTO `Roles` (`roleId`, `roleName`, `roleDescription`, `roleCreatedDate`) VALUES
(1, 'Adimin', 'admins allows to manage all users of the company', '2022-07-26');

-- --------------------------------------------------------

--
-- Table structure for table `Roles and Permissions`
--

CREATE TABLE `Roles and Permissions` (
  `roleId` int(6) NOT NULL,
  `permissionId` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Roles and Permissions`
--

INSERT INTO `Roles and Permissions` (`roleId`, `permissionId`) VALUES
(1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Amount`
--
ALTER TABLE `Amount`
  ADD PRIMARY KEY (`amountId`);

--
-- Indexes for table `Customers`
--
ALTER TABLE `Customers`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `Employer`
--
ALTER TABLE `Employer`
  ADD PRIMARY KEY (`userID`),
  ADD KEY `roles_ibfk_1` (`roleId`);

--
-- Indexes for table `Payment`
--
ALTER TABLE `Payment`
  ADD KEY `Payment_ibfk_1` (`customerID`);

--
-- Indexes for table `Permissions`
--
ALTER TABLE `Permissions`
  ADD PRIMARY KEY (`permissionId`);

--
-- Indexes for table `Reservation`
--
ALTER TABLE `Reservation`
  ADD KEY `Reservation_ibfk_1` (`customerID`),
  ADD KEY `Reservation1_ibfk_1` (`amountId`);

--
-- Indexes for table `Roles`
--
ALTER TABLE `Roles`
  ADD PRIMARY KEY (`roleId`);

--
-- Indexes for table `Roles and Permissions`
--
ALTER TABLE `Roles and Permissions`
  ADD KEY `Roles and Permissions_ibfk_1` (`permissionId`),
  ADD KEY `Roles and Permission_ibfk_1` (`roleId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Amount`
--
ALTER TABLE `Amount`
  MODIFY `amountId` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Customers`
--
ALTER TABLE `Customers`
  MODIFY `customerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Employer`
--
ALTER TABLE `Employer`
  MODIFY `userID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Permissions`
--
ALTER TABLE `Permissions`
  MODIFY `permissionId` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Roles`
--
ALTER TABLE `Roles`
  MODIFY `roleId` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Employer`
--
ALTER TABLE `Employer`
  ADD CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `Roles` (`roleId`);

--
-- Constraints for table `Payment`
--
ALTER TABLE `Payment`
  ADD CONSTRAINT `Payment_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `Customers` (`customerID`);

--
-- Constraints for table `Reservation`
--
ALTER TABLE `Reservation`
  ADD CONSTRAINT `Reservation1_ibfk_1` FOREIGN KEY (`amountId`) REFERENCES `Amount` (`amountId`),
  ADD CONSTRAINT `Reservation_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `Customers` (`customerID`);

--
-- Constraints for table `Roles and Permissions`
--
ALTER TABLE `Roles and Permissions`
  ADD CONSTRAINT `Roles and Permission_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `Roles` (`roleId`),
  ADD CONSTRAINT `Roles and Permissions_ibfk_1` FOREIGN KEY (`permissionId`) REFERENCES `Permissions` (`permissionId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
