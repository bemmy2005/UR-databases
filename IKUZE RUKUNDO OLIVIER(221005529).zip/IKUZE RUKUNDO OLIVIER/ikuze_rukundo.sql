-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 26, 2022 at 04:16 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ikuze_rukundo`
--

-- --------------------------------------------------------

--
-- Table structure for table `credit_c_no`
--

DROP TABLE IF EXISTS `credit_c_no`;
CREATE TABLE IF NOT EXISTS `credit_c_no` (
  `credit_c_no` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `residence` varchar(50) NOT NULL,
  `amount` int(20) NOT NULL,
  PRIMARY KEY (`credit_c_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `credit_c_no`
--

INSERT INTO `credit_c_no` (`credit_c_no`, `username`, `password`, `first_name`, `last_name`, `residence`, `amount`) VALUES
('23456789', 'koloty', '09866', 'rukundo', 'king', 'rwandan', 300000),
('0987654', 'kubwimana', 'olivier', 'byiringiro', 'cyuzuzo', 'rwandan', 43000),
('7545678', 'stiven', 'cyuzuzo', 'pascal', 'olivier', 'rwandan', 98000);

-- --------------------------------------------------------

--
-- Table structure for table `house`
--

DROP TABLE IF EXISTS `house`;
CREATE TABLE IF NOT EXISTS `house` (
  `house_id` int(50) NOT NULL AUTO_INCREMENT,
  `price` varchar(50) NOT NULL,
  `details` varchar(50) NOT NULL,
  `picture` varchar(50) NOT NULL,
  PRIMARY KEY (`house_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `house`
--

INSERT INTO `house` (`house_id`, `price`, `details`, `picture`) VALUES
(1, '50000', 'musanze', ''),
(2, '39000', 'kigali', '');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `message_id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7654346 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `name`, `email`, `phone`, `message`) VALUES
(1, 'olivier', 'ikuzeolivier@gmail.com', '250788989654', 'house in rwanda, karongi,twumba,gakuta'),
(34567, 'rukundo', 'byiringiroolivier@gmail.com', '250788985280', 'kigali,karongi'),
(7654345, 'cyuzuzo', 'olivierikuze@gmail.com', '2507865456789765', 'kigali,huye');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

DROP TABLE IF EXISTS `owner`;
CREATE TABLE IF NOT EXISTS `owner` (
  `owner_id` int(50) NOT NULL AUTO_INCREMENT,
  `credit_no` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `residence` varchar(50) NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`owner_id`, `credit_no`, `username`, `password`, `first_name`, `last_name`, `email`, `phone`, `residence`) VALUES
(67, '5678', 'olivier', '123456', 'ikuze', 'olivier', 'ikuzeolivier@gmail.com', '250788989654', 'rwandan'),
(2, '345678678', 'koloty', '09866', 'kibwa', 'king', 'kibwaking@gmail.com', '250788985280', 'rwandan'),
(45, '5677788', 'olivier', 'olivier', 'rukundo', 'king', 'ikuzeolivier@gmail.com', '25073891829393', 'congoles');

-- --------------------------------------------------------

--
-- Table structure for table `seeker`
--

DROP TABLE IF EXISTS `seeker`;
CREATE TABLE IF NOT EXISTS `seeker` (
  `seeker_id` int(50) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `credit_no` varchar(50) NOT NULL,
  PRIMARY KEY (`seeker_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeker`
--

INSERT INTO `seeker` (`seeker_id`, `first_name`, `last_name`, `email`, `phone`, `credit_no`) VALUES
(1, 'byiringiroi', 'olivier', 'byiringiroolivier@gmail.com', '250788989654', '5677788'),
(2, 'byiringiroi', 'olivier', 'byiringiroolivier@gmail.com', '250788989654', '5677788');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
