-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 04:55 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hashakimana_olivier_221020809`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ghghj` ()  BEGIN
 CREATE VIEW selectwithsubquery as (SELECT fullnames,phone_number,product_name,prce_unit,pquantity,brand_name,quality,dateofexpiry,amount FROM client join buying on client.client_id=buying.client_id join product on product.product_id=buying.product_id where amount<(SELECT AVG(amount) from buying));   
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listbuying` ()  BEGIN
    select * from buying;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listclient` ()  BEGIN
    UPDATE `listclient` SET `fullnames` = 'innocent' WHERE `listclient`.`client_id` = 9;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listclients` ()  BEGIN
    DELETE FROM `listclient` WHERE `listclient`.`client_id` = 56;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listpayment` ()  BEGIN
    select * from payment;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listproduct` ()  BEGIN
    select * from product;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listseller` ()  BEGIN
    DELETE FROM `listseller` WHERE `listseller`.`seller_id`=7;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listsellerseller` ()  BEGIN
UPDATE `listseller` SET `sfname` = 'chris', `slname` = 'eazy' WHERE `listseller`.`seller_id` = 1020;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `listselling` ()  BEGIN
    select * from selling;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `listbuying`
-- (See below for the actual view)
--
CREATE TABLE `listbuying` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listclient`
-- (See below for the actual view)
--
CREATE TABLE `listclient` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listpayment`
-- (See below for the actual view)
--
CREATE TABLE `listpayment` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listproduct`
-- (See below for the actual view)
--
CREATE TABLE `listproduct` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listseller`
-- (See below for the actual view)
--
CREATE TABLE `listseller` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `listselling`
-- (See below for the actual view)
--
CREATE TABLE `listselling` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `selectwithsubquery`
-- (See below for the actual view)
--
CREATE TABLE `selectwithsubquery` (
);

-- --------------------------------------------------------

--
-- Structure for view `listbuying`
--
DROP TABLE IF EXISTS `listbuying`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listbuying`  AS   (select `buying`.`buying_id` AS `buying_id`,`buying`.`bdate` AS `bdate`,`buying`.`client_id` AS `client_id`,`buying`.`product_id` AS `product_id`,`buying`.`bquantity` AS `bquantity`,`buying`.`amount` AS `amount` from `buying`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listclient`
--
DROP TABLE IF EXISTS `listclient`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listclient`  AS SELECT `client`.`client_id` AS `client_id`, `client`.`fullnames` AS `fullnames`, `client`.`phone_number` AS `phone_number` FROM `client` ;

-- --------------------------------------------------------

--
-- Structure for view `listpayment`
--
DROP TABLE IF EXISTS `listpayment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listpayment`  AS SELECT `payment`.`payment_id` AS `payment_id`, `payment`.`payment_date` AS `payment_date`, `payment`.`payment_amount` AS `payment_amount`, `payment`.`selling_id` AS `selling_id` FROM `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `listproduct`
--
DROP TABLE IF EXISTS `listproduct`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listproduct`  AS   (select `product`.`product_id` AS `product_id`,`product`.`product_name` AS `product_name`,`product`.`prce_unit` AS `prce_unit`,`product`.`pquantity` AS `pquantity`,`product`.`brand_name` AS `brand_name`,`product`.`quality` AS `quality`,`product`.`dateofexpiry` AS `dateofexpiry` from `product`)  ;

-- --------------------------------------------------------

--
-- Structure for view `listseller`
--
DROP TABLE IF EXISTS `listseller`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listseller`  AS SELECT `seller`.`seller_id` AS `seller_id`, `seller`.`sfname` AS `sfname`, `seller`.`slname` AS `slname`, `seller`.`sphonenumber` AS `sphonenumber` FROM `seller` ;

-- --------------------------------------------------------

--
-- Structure for view `listselling`
--
DROP TABLE IF EXISTS `listselling`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listselling`  AS SELECT `selling`.`selling_id` AS `selling_id`, `selling`.`selling_date` AS `selling_date`, `selling`.`buying_id` AS `buying_id`, `selling`.`seller_id` AS `seller_id`, `selling`.`amount` AS `amount`, `selling`.`quantity` AS `quantity`, `selling`.`quality` AS `quality`, `selling`.`brand_name` AS `brand_name` FROM `selling` ;

-- --------------------------------------------------------

--
-- Structure for view `selectwithsubquery`
--
DROP TABLE IF EXISTS `selectwithsubquery`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `selectwithsubquery`  AS   (select `client`.`fullnames` AS `fullnames`,`client`.`phone_number` AS `phone_number`,`product`.`product_name` AS `product_name`,`product`.`prce_unit` AS `prce_unit`,`product`.`pquantity` AS `pquantity`,`product`.`brand_name` AS `brand_name`,`product`.`quality` AS `quality`,`product`.`dateofexpiry` AS `dateofexpiry`,`buying`.`amount` AS `amount` from ((`client` join `buying` on(`client`.`client_id` = `buying`.`client_id`)) join `product` on(`product`.`product_id` = `buying`.`product_id`)) where `buying`.`amount` < (select avg(`buying`.`amount`) from `buying`))  ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
