-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 12:14 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yves_chadrack`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `Class_Id` int(100) NOT NULL,
  `Class_Name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`Class_Id`, `Class_Name`) VALUES
(10012, 'L1BIT'),
(10013, 'Electrical');

-- --------------------------------------------------------

--
-- Stand-in structure for view `classview`
-- (See below for the actual view)
--
CREATE TABLE `classview` (
`Class_Id` int(100)
,`Class_Name` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `Mark_Id` int(16) NOT NULL,
  `Student_Id` int(16) DEFAULT NULL,
  `Class_Id` int(16) DEFAULT NULL,
  `mod_id` int(16) DEFAULT NULL,
  `Results` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`Mark_Id`, `Student_Id`, `Class_Id`, `mod_id`, `Results`) VALUES
(1, 221021667, 10012, 213, 70),
(2, 221021668, 10013, 213, 50);

-- --------------------------------------------------------

--
-- Stand-in structure for view `marksview`
-- (See below for the actual view)
--
CREATE TABLE `marksview` (
`Mark_Id` int(16)
,`Student_Id` int(16)
,`Class_Id` int(16)
,`mod_id` int(16)
,`Results` int(3)
);

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `mod_id` int(16) NOT NULL,
  `mod_name` varchar(10) DEFAULT NULL,
  `mod_credit` int(10) DEFAULT NULL,
  `mod_teacher` int(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`mod_id`, `mod_name`, `mod_credit`, `mod_teacher`) VALUES
(213, 'Mathematic', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Id` int(100) NOT NULL,
  `FullNames` varchar(55) DEFAULT NULL,
  `Birthdate` date DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Id`, `FullNames`, `Birthdate`, `gender`) VALUES
(221021667, 'IRA Yves', '0000-00-00', 'M'),
(221021668, 'KEZA Yvonne', '0000-00-00', 'F');

-- --------------------------------------------------------

--
-- Stand-in structure for view `studentsyview`
-- (See below for the actual view)
--
CREATE TABLE `studentsyview` (
`Id` int(100)
,`FullNames` varchar(55)
,`Birthdate` date
,`gender` varchar(1)
);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `Teacher_Id` int(16) NOT NULL,
  `Teacher_Name` varchar(50) DEFAULT NULL,
  `Teacher_Gender` varchar(1) DEFAULT NULL,
  `Teacher_Phone` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`Teacher_Id`, `Teacher_Name`, `Teacher_Gender`, `Teacher_Phone`) VALUES
(1, 'CYUBAHIRO Bonheur', 'M', 788888887),
(2, 'Yves Chadrack', 'M', 7822222);

-- --------------------------------------------------------

--
-- Stand-in structure for view `teacherview`
-- (See below for the actual view)
--
CREATE TABLE `teacherview` (
`Teacher_Id` int(16)
,`Teacher_Name` varchar(50)
,`Teacher_Gender` varchar(1)
,`Teacher_Phone` int(10)
);

-- --------------------------------------------------------

--
-- Structure for view `classview`
--
DROP TABLE IF EXISTS `classview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `classview`  AS SELECT `class`.`Class_Id` AS `Class_Id`, `class`.`Class_Name` AS `Class_Name` FROM `class``class`  ;

-- --------------------------------------------------------

--
-- Structure for view `marksview`
--
DROP TABLE IF EXISTS `marksview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `marksview`  AS SELECT `marks`.`Mark_Id` AS `Mark_Id`, `marks`.`Student_Id` AS `Student_Id`, `marks`.`Class_Id` AS `Class_Id`, `marks`.`mod_id` AS `mod_id`, `marks`.`Results` AS `Results` FROM `marks``marks`  ;

-- --------------------------------------------------------

--
-- Structure for view `studentsyview`
--
DROP TABLE IF EXISTS `studentsyview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `studentsyview`  AS SELECT `students`.`Id` AS `Id`, `students`.`FullNames` AS `FullNames`, `students`.`Birthdate` AS `Birthdate`, `students`.`gender` AS `gender` FROM `students``students`  ;

-- --------------------------------------------------------

--
-- Structure for view `teacherview`
--
DROP TABLE IF EXISTS `teacherview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `teacherview`  AS SELECT `teachers`.`Teacher_Id` AS `Teacher_Id`, `teachers`.`Teacher_Name` AS `Teacher_Name`, `teachers`.`Teacher_Gender` AS `Teacher_Gender`, `teachers`.`Teacher_Phone` AS `Teacher_Phone` FROM `teachers``teachers`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`Class_Id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`Mark_Id`),
  ADD KEY `Student_Id` (`Student_Id`),
  ADD KEY `mod_id` (`mod_id`),
  ADD KEY `Class_Id` (`Class_Id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`mod_id`),
  ADD KEY `mod_teacher` (`mod_teacher`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`Teacher_Id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`mod_id`) REFERENCES `modules` (`mod_id`),
  ADD CONSTRAINT `marks_ibfk_2` FOREIGN KEY (`Student_Id`) REFERENCES `students` (`Id`),
  ADD CONSTRAINT `marks_ibfk_3` FOREIGN KEY (`mod_id`) REFERENCES `modules` (`mod_id`),
  ADD CONSTRAINT `marks_ibfk_4` FOREIGN KEY (`Class_Id`) REFERENCES `class` (`Class_Id`);

--
-- Constraints for table `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`mod_teacher`) REFERENCES `teachers` (`Teacher_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
