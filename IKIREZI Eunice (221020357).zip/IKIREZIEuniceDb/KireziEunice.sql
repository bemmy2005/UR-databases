-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 27, 2022 at 01:59 PM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `KireziEunice`
--

-- --------------------------------------------------------

--
-- Table structure for table `Administration`
--

CREATE TABLE `Administration` (
  `Admin_id` int(11) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Administration`
--

INSERT INTO `Administration` (`Admin_id`, `Fname`, `Lname`, `Password`, `Email`) VALUES
(1, 'Kirezi', 'Eunice', '12345678', 'kireziEunice@gmail.com'),
(2, 'Gatesi', 'Kevine', '15362728', 'GatesiKevine@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `Announcement`
--

CREATE TABLE `Announcement` (
  `Id` int(11) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Content` varchar(100) NOT NULL,
  `Ursu_id` int(11) NOT NULL,
  `Reg_id` int(11) NOT NULL,
  `Admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Announcement`
--

INSERT INTO `Announcement` (`Id`, `Title`, `Content`, `Ursu_id`, `Reg_id`, `Admin_id`) VALUES
(1, 'Application of Student 2022', 'Application of Student 2022Application of Student 2022Application of Student 2022', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE `Student` (
  `Reg_No` int(11) NOT NULL,
  `Pin` int(11) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `College` varchar(100) NOT NULL,
  `Department` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Level` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`Reg_No`, `Pin`, `Fname`, `Lname`, `College`, `Department`, `Email`, `Level`) VALUES
(1, 109, 'Kevin', 'Kenny', 'KennyK@gmail.com', 'BIT', 'CBE', '2');

-- --------------------------------------------------------

--
-- Table structure for table `Ursu`
--

CREATE TABLE `Ursu` (
  `Reg_no` int(11) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `Pin` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Post` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Ursu`
--

INSERT INTO `Ursu` (`Reg_no`, `Fname`, `Lname`, `Pin`, `Email`, `Post`) VALUES
(1, 'Urs', 'Ullah', 1237, 'ursullah@gmail.com', 'Manager');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Administration`
--
ALTER TABLE `Administration`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `Announcement`
--
ALTER TABLE `Announcement`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Ursu_id` (`Ursu_id`),
  ADD KEY `Reg_id` (`Reg_id`),
  ADD KEY `Admin_id` (`Admin_id`);

--
-- Indexes for table `Student`
--
ALTER TABLE `Student`
  ADD PRIMARY KEY (`Reg_No`);

--
-- Indexes for table `Ursu`
--
ALTER TABLE `Ursu`
  ADD PRIMARY KEY (`Reg_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Administration`
--
ALTER TABLE `Administration`
  MODIFY `Admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Announcement`
--
ALTER TABLE `Announcement`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Student`
--
ALTER TABLE `Student`
  MODIFY `Reg_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Ursu`
--
ALTER TABLE `Ursu`
  MODIFY `Reg_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Announcement`
--
ALTER TABLE `Announcement`
  ADD CONSTRAINT `announcement_ibfk_1` FOREIGN KEY (`Admin_id`) REFERENCES `Administration` (`Admin_id`),
  ADD CONSTRAINT `announcement_ibfk_2` FOREIGN KEY (`Reg_id`) REFERENCES `Student` (`Reg_No`);

--
-- Constraints for table `Ursu`
--
ALTER TABLE `Ursu`
  ADD CONSTRAINT `ursu_ibfk_1` FOREIGN KEY (`Reg_no`) REFERENCES `Announcement` (`Ursu_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
