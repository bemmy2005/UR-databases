-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20220715.346923e20a
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2022 at 11:06 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletecustomer` (IN `custIDParam` INT(16))   BEGIN
    delete from customer_information where cust_id=custIDParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteemployee` (IN `employeeidp` INT(16))   BEGIN
    delete from employees where employee_id=employeeidp;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteroom` (IN `roomidp` INT(10))   BEGIN
    delete from room_information where price < (SELECT AVG(price));
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getclassifo` ()   BEGIN
    select * from room_class;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getcustomers` ()   BEGIN
    select * from customer_information;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getemployeees` ()   BEGIN
    select * from employees;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getpayments` ()   BEGIN
    select * from payments;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getreports` ()   BEGIN
    select * from reports;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getreservation` ()   BEGIN
    select * from reservation;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getroomifo` ()   BEGIN
    select * from room_information;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `gettransaction` ()   BEGIN
    select * from transaction;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertclassinfo` (IN `Class_Id` INT(10), `Name` VARCHAR(30))   BEGIN
insert into room_class values (Class_Id,Name);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertCust` (IN `custIDParam` INT(16), `FirstNamep` VARCHAR(30), `LastNamep` VARCHAR(30), `Addressp` VARCHAR(20))   BEGIN
    insert into customer_information values (Cust_id,FirstName,LastName,Address);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertemployee` (IN `EmployeeIdp` INT(16), `FirstNamep` VARCHAR(30), `LastNamep` VARCHAR(30), `Job_DepartmentP` VARCHAR(20), `Addressp` VARCHAR(20), `Contact_AddP` VARCHAR(20), `User_NameP` VARCHAR(20), `PasswordP` VARCHAR(10))   BEGIN
    insert into employees values (Employee_Id, FirstName, LastName, Job_Department, Address, Contact_Add, User_Name, Password);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertpayments` (IN `Payment_Idp` INT(11), `Cust_idp` INT(16), `Payment_Datep` DATE)   BEGIN
    insert into payments values (Payment_Id,Cust_id,Payment_Date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertreports` (IN `Report_Idp` INT(10), `Transaction_Idp` VARCHAR(10), `Information` VARCHAR(30), `Datep` DATE)   BEGIN
insert into reports values (Report_Id,Transaction_Id,Information,Date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertreservation` (IN `Reservation_Id` VARCHAR(10), `Customer_Id` INT(16), `Room_Id` INT(10), `Reservation_Date` DATE, `Date_In` DATE, `Date_Out` DATE, `Date_Range` VARCHAR(20))   BEGIN
insert into reservation values (Reservation_Id,Customer_Id,Room_Id,Reservation_Date,Date_In,Date_Out,Date_Range);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertroominfo` (IN `room_id` INT(10), `Class_Id` INT(10), `Description` VARCHAR(30), `Price` INT(10))   BEGIN
insert into room_information values (Room_Id,Class_Id,Description,Price);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserttransaction` (`transaction_Id` VARCHAR(10), `Transaction_Name` VARCHAR(20), `Cust_Id` INT(16), `Payment_Id` INT(16), `Employee_Id` INT(16), `Reservation_Id` VARCHAR(10), `Transaction_Date` DATE)   BEGIN
INSERT INTO transaction VALUES (transaction_Id,Transaction_Name,Cust_Id,Payment_Id,Employee_Id,Reservation_Id,Transaction_Date);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatecustomers` (IN `custidp` INT(16))   BEGIN
    update customer_information set Lastname="karenzi" where cust_Id=custidp;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateemployee` (IN `employeeidp` INT(16))   BEGIN
    update employees set job_department="finance" where employee_Id=employeeidp;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `cheap_room`
-- (See below for the actual view)
--
CREATE TABLE `cheap_room` (
`Room_Id` int(10)
,`Price` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `classinfo`
-- (See below for the actual view)
--
CREATE TABLE `classinfo` (
`Class_Id` int(10)
,`Name` varchar(30)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `customerinfo`
-- (See below for the actual view)
--
CREATE TABLE `customerinfo` (
`Cust_id` int(16)
,`FirstName` varchar(30)
,`LastName` varchar(30)
,`Address` varchar(20)
,`Status` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer_information`
--

CREATE TABLE `customer_information` (
  `Cust_id` int(16) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_information`
--

INSERT INTO `customer_information` (`Cust_id`, `FirstName`, `LastName`, `Address`, `Status`) VALUES
(1, 'mugisha ', 'john', 'gitarama', 'single'),
(2, 'mugabo', 'benjamin', 'Nyaruguru', 'married');

--
-- Triggers `customer_information`
--
DELIMITER $$
CREATE TRIGGER `afterinsert triger` BEFORE INSERT ON `customer_information` FOR EACH ROW INSERT INTO room_class VALUES(1,'conference')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `afterupdate` AFTER UPDATE ON `customer_information` FOR EACH ROW INSERT INTO reports VALUES(3,'12','one record has been deleted',10/7/2020)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `afterupdate2` BEFORE UPDATE ON `customer_information` FOR EACH ROW INSERT INTO report VALUES(1,'yes','done',10/7/2020)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `employeeinfo`
-- (See below for the actual view)
--
CREATE TABLE `employeeinfo` (
`Employee_Id` int(16)
,`FirstName` varchar(30)
,`LastName` varchar(30)
,`Job_Department` varchar(20)
,`Address` varchar(20)
,`Contact_Add` varchar(20)
,`User_Name` varchar(20)
,`Password` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Employee_Id` int(16) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `Job_Department` varchar(20) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Contact_Add` varchar(20) NOT NULL,
  `User_Name` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Employee_Id`, `FirstName`, `LastName`, `Job_Department`, `Address`, `Contact_Add`, `User_Name`, `Password`) VALUES
(1, 'kalisa', 'jonathan', 'managements', 'kacyiru', '0782332323', 'klijo', '121212'),
(2, 'muzungu ', 'frederic', 'auditing', 'Nyanza', '0723428838', 'muzung@', '1212@');

-- --------------------------------------------------------

--
-- Stand-in structure for view `payinfo`
-- (See below for the actual view)
--
CREATE TABLE `payinfo` (
`Payment_Id` int(11)
,`Cust_id` int(16)
,`Payment_Date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `Payment_Id` int(11) NOT NULL,
  `Cust_id` int(16) NOT NULL,
  `Payment_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`Payment_Id`, `Cust_id`, `Payment_Date`) VALUES
(1122, 2, '2022-07-27');

--
-- Triggers `payments`
--
DELIMITER $$
CREATE TRIGGER `afredelete` AFTER DELETE ON `payments` FOR EACH ROW DELETE FROM customer_information WHERE customer_information.Cust_id=payments.Cust_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `Report_Id` int(10) NOT NULL,
  `Transaction_Id` varchar(10) NOT NULL,
  `Information` varchar(30) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`Report_Id`, `Transaction_Id`, `Information`, `Date`) VALUES
(11221, '112', 'payments for room reservation', '2022-11-15'),
(11223, '112', 'payments for room reservation', '2022-11-15');

-- --------------------------------------------------------

--
-- Stand-in structure for view `reportsinfo`
-- (See below for the actual view)
--
CREATE TABLE `reportsinfo` (
`Report_Id` int(10)
,`Transaction_Id` varchar(10)
,`Information` varchar(30)
,`Date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `Reservation_Id` varchar(10) NOT NULL,
  `Customer_Id` int(16) NOT NULL,
  `Room_Id` int(10) NOT NULL,
  `Reservation_Date` date NOT NULL,
  `Date_In` date NOT NULL,
  `Date_Out` date NOT NULL,
  `Date_Range` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`Reservation_Id`, `Customer_Id`, `Room_Id`, `Reservation_Date`, `Date_In`, `Date_Out`, `Date_Range`) VALUES
('12', 1, 1, '2022-07-06', '2022-07-26', '2022-07-30', '4 days'),
('13', 1, 1, '2022-07-06', '2022-07-26', '2022-07-30', '4 days');

-- --------------------------------------------------------

--
-- Stand-in structure for view `reservationinfo`
-- (See below for the actual view)
--
CREATE TABLE `reservationinfo` (
`Reservation_Id` varchar(10)
,`Customer_Id` int(16)
,`Room_Id` int(10)
,`Reservation_Date` date
,`Date_In` date
,`Date_Out` date
,`Date_Range` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `roominfo`
-- (See below for the actual view)
--
CREATE TABLE `roominfo` (
`Room_Id` int(10)
,`Class_Id` int(10)
,`Description` varchar(30)
,`Price` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `room_class`
--

CREATE TABLE `room_class` (
  `Class_Id` int(10) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_class`
--

INSERT INTO `room_class` (`Class_Id`, `Name`) VALUES
(1, 'vip'),
(2, 'vvip'),
(3, 'general');

--
-- Triggers `room_class`
--
DELIMITER $$
CREATE TRIGGER `afterinsert` AFTER INSERT ON `room_class` FOR EACH ROW INSERT INTO room_information VALUES(12,123,'for children',25000)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `room_information`
--

CREATE TABLE `room_information` (
  `Room_Id` int(10) NOT NULL,
  `Class_Id` int(10) NOT NULL,
  `Description` varchar(30) NOT NULL,
  `Price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_information`
--

INSERT INTO `room_information` (`Room_Id`, `Class_Id`, `Description`, `Price`) VALUES
(1, 1, 'for man or woman', 30000),
(2, 3, 'for man or woman', 30000),
(4, 3, 'for woman', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_Id` varchar(10) NOT NULL,
  `Transaction_Name` varchar(20) NOT NULL,
  `Cust_Id` int(16) NOT NULL,
  `Payment_Id` int(16) NOT NULL,
  `Employee_Id` int(16) NOT NULL,
  `Reservation_Id` varchar(10) NOT NULL,
  `Transaction_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_Id`, `Transaction_Name`, `Cust_Id`, `Payment_Id`, `Employee_Id`, `Reservation_Id`, `Transaction_Date`) VALUES
('112', 'forall', 1, 1122, 1, '12', '2022-07-28'),
('113', 'for all', 1, 1122, 2, '12', '2022-07-28');

--
-- Triggers `transaction`
--
DELIMITER $$
CREATE TRIGGER `afterdelete2` AFTER DELETE ON `transaction` FOR EACH ROW DELETE FROM reservation WHERE transaction.Reservation_Id= reservation.Reservation_Id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `transactioninfo`
-- (See below for the actual view)
--
CREATE TABLE `transactioninfo` (
`transaction_Id` varchar(10)
,`Transaction_Name` varchar(20)
,`Cust_Id` int(16)
,`Payment_Id` int(16)
,`Employee_Id` int(16)
,`Reservation_Id` varchar(10)
,`Transaction_Date` date
);

-- --------------------------------------------------------

--
-- Structure for view `cheap_room`
--
DROP TABLE IF EXISTS `cheap_room`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cheap_room`  AS SELECT `room_information`.`Room_Id` AS `Room_Id`, `room_information`.`Price` AS `Price` FROM `room_information` WHERE `room_information`.`Price` > (select avg(`room_information`.`Price`) from `room_information`)  ;

-- --------------------------------------------------------

--
-- Structure for view `classinfo`
--
DROP TABLE IF EXISTS `classinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `classinfo`  AS SELECT `room_class`.`Class_Id` AS `Class_Id`, `room_class`.`Name` AS `Name` FROM `room_class``room_class`  ;

-- --------------------------------------------------------

--
-- Structure for view `customerinfo`
--
DROP TABLE IF EXISTS `customerinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customerinfo`  AS SELECT `customer_information`.`Cust_id` AS `Cust_id`, `customer_information`.`FirstName` AS `FirstName`, `customer_information`.`LastName` AS `LastName`, `customer_information`.`Address` AS `Address`, `customer_information`.`Status` AS `Status` FROM `customer_information``customer_information`  ;

-- --------------------------------------------------------

--
-- Structure for view `employeeinfo`
--
DROP TABLE IF EXISTS `employeeinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employeeinfo`  AS SELECT `employees`.`Employee_Id` AS `Employee_Id`, `employees`.`FirstName` AS `FirstName`, `employees`.`LastName` AS `LastName`, `employees`.`Job_Department` AS `Job_Department`, `employees`.`Address` AS `Address`, `employees`.`Contact_Add` AS `Contact_Add`, `employees`.`User_Name` AS `User_Name`, `employees`.`Password` AS `Password` FROM `employees``employees`  ;

-- --------------------------------------------------------

--
-- Structure for view `payinfo`
--
DROP TABLE IF EXISTS `payinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payinfo`  AS SELECT `payments`.`Payment_Id` AS `Payment_Id`, `payments`.`Cust_id` AS `Cust_id`, `payments`.`Payment_Date` AS `Payment_Date` FROM `payments``payments`  ;

-- --------------------------------------------------------

--
-- Structure for view `reportsinfo`
--
DROP TABLE IF EXISTS `reportsinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reportsinfo`  AS SELECT `reports`.`Report_Id` AS `Report_Id`, `reports`.`Transaction_Id` AS `Transaction_Id`, `reports`.`Information` AS `Information`, `reports`.`Date` AS `Date` FROM `reports``reports`  ;

-- --------------------------------------------------------

--
-- Structure for view `reservationinfo`
--
DROP TABLE IF EXISTS `reservationinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reservationinfo`  AS SELECT `reservation`.`Reservation_Id` AS `Reservation_Id`, `reservation`.`Customer_Id` AS `Customer_Id`, `reservation`.`Room_Id` AS `Room_Id`, `reservation`.`Reservation_Date` AS `Reservation_Date`, `reservation`.`Date_In` AS `Date_In`, `reservation`.`Date_Out` AS `Date_Out`, `reservation`.`Date_Range` AS `Date_Range` FROM `reservation``reservation`  ;

-- --------------------------------------------------------

--
-- Structure for view `roominfo`
--
DROP TABLE IF EXISTS `roominfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `roominfo`  AS SELECT `room_information`.`Room_Id` AS `Room_Id`, `room_information`.`Class_Id` AS `Class_Id`, `room_information`.`Description` AS `Description`, `room_information`.`Price` AS `Price` FROM `room_information``room_information`  ;

-- --------------------------------------------------------

--
-- Structure for view `transactioninfo`
--
DROP TABLE IF EXISTS `transactioninfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transactioninfo`  AS SELECT `transaction`.`transaction_Id` AS `transaction_Id`, `transaction`.`Transaction_Name` AS `Transaction_Name`, `transaction`.`Cust_Id` AS `Cust_Id`, `transaction`.`Payment_Id` AS `Payment_Id`, `transaction`.`Employee_Id` AS `Employee_Id`, `transaction`.`Reservation_Id` AS `Reservation_Id`, `transaction`.`Transaction_Date` AS `Transaction_Date` FROM `transaction``transaction`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_information`
--
ALTER TABLE `customer_information`
  ADD PRIMARY KEY (`Cust_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Employee_Id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`Payment_Id`),
  ADD KEY `cos1` (`Cust_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD KEY `cos10` (`Transaction_Id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`Reservation_Id`),
  ADD KEY `cos2` (`Customer_Id`),
  ADD KEY `cos4` (`Room_Id`);

--
-- Indexes for table `room_class`
--
ALTER TABLE `room_class`
  ADD PRIMARY KEY (`Class_Id`);

--
-- Indexes for table `room_information`
--
ALTER TABLE `room_information`
  ADD PRIMARY KEY (`Room_Id`),
  ADD KEY `cos6` (`Class_Id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_Id`),
  ADD KEY `cos3` (`Cust_Id`),
  ADD KEY `cos7` (`Payment_Id`),
  ADD KEY `cos8` (`Employee_Id`),
  ADD KEY `cos9` (`Reservation_Id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `cos1` FOREIGN KEY (`Cust_id`) REFERENCES `customer_information` (`Cust_id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `cos10` FOREIGN KEY (`Transaction_Id`) REFERENCES `transaction` (`transaction_Id`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `cos2` FOREIGN KEY (`Customer_Id`) REFERENCES `customer_information` (`Cust_id`),
  ADD CONSTRAINT `cos4` FOREIGN KEY (`Room_Id`) REFERENCES `room_information` (`Room_Id`);

--
-- Constraints for table `room_information`
--
ALTER TABLE `room_information`
  ADD CONSTRAINT `cos6` FOREIGN KEY (`Class_Id`) REFERENCES `room_class` (`Class_Id`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `cos3` FOREIGN KEY (`Cust_Id`) REFERENCES `customer_information` (`Cust_id`),
  ADD CONSTRAINT `cos7` FOREIGN KEY (`Payment_Id`) REFERENCES `payments` (`Payment_Id`),
  ADD CONSTRAINT `cos8` FOREIGN KEY (`Employee_Id`) REFERENCES `employees` (`Employee_Id`),
  ADD CONSTRAINT `cos9` FOREIGN KEY (`Reservation_Id`) REFERENCES `reservation` (`Reservation_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
