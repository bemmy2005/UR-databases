-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 09:51 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `icyishatse_deny_221012798`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletecustomer` (IN `ID` INT(6))  BEGIN
DELETE FROM customer where customer.customer_Id='ID';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deletepayment` (IN `status` VARCHAR(10))  BEGIN 
delete from payment WHERE payment.status='yes';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertcustomer` (IN `customer_Id` INT(5), `customer_Fname` VARCHAR(40), `customer_Lname` VARCHAR(30), `Gender` VARCHAR(6), `customer_phonenumber` VARCHAR(15), `customer_Address` VARCHAR(10))  BEGIN
INSERT INTO customer values(customer_Id ,customer_Fname ,customer_Lname ,Gender ,customer_phonenumber,customer_Address);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertdelivery` (IN `delivery_Id` INT(10), `Address` VARCHAR(20), `delivery_Date` DATE, `customer_Id` INT(10), `order_Id` INT(10), `status` VARCHAR(10))  BEGIN

insert into delivery values(delivery_Id,Address,delivery_Date,customer_Id ,order_Id,status);
                                                                                           
                                                                                           
                                                                                           
  END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertfood` (IN `food_Id` INT(10), `food_Name` VARCHAR(20), `food_Quality` VARCHAR(10), `foopd_Quantity` VARCHAR(10), `price` DECIMAL(8), `total` DECIMAL(8))  BEGIN

 insert into food values(food_Id,food_Name,food_Quality,food_Quantity,price,total);
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertorderr` (IN `order_Id` INT(4), `food_Id` INT(10), `customer_Id` INT(10), `order_date` DATE, `quantity` VARCHAR(10), `seller_Id` INT(10))  BEGIN

insert into orderr values(order_Id ,food_Id ,customer_Id ,order_date ,quantity ,seller_Id );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertpayment` (IN `payId` INT(5), `customer_Id` INT(4), `order_Id` INT(4), `amount` DECIMAL(8), `status` VARCHAR(10))  BEGIN

insert into payment values(payId ,customer_Id ,order_Id,amount ,status );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertseller` (IN `seller_Id` INT(4), `seller_name` VARCHAR(20), `seller_phone` INT(12), `username` VARCHAR(10), `password` VARCHAR(10))  BEGIN

 insert into seller values(seller_Id,seller_name,seller_phone ,username ,password);
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectcustomers` ()  BEGIN 
select * from customer;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectdelivey` ()  BEGIN
select*FROM delivery;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectfood` ()  BEGIN
select*from food;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectorderr` ()  BEGIN

select*from orderr;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectpayment` ()  BEGIN

select*from payment;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectseller` ()  BEGIN
select*from seller;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatecustomer` (IN `ID` INT(6), `FIRSTNAME` VARCHAR(20))  BEGIN
UPDATE customer set customer.customer_Fname='FIRSTNAME' WHERE customer.customer_Id='ID';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatedelivery` (IN `delivery_Id` INT(10), `Address` VARCHAR(10))  BEGIN
update delivery SET delivery.Address='HUYE' WHERE delivery.delivery_Id='002';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_Id` int(5) NOT NULL,
  `customer_Fname` varchar(40) DEFAULT NULL,
  `customer_Lname` varchar(30) DEFAULT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `customer_phonenumber` varchar(15) DEFAULT NULL,
  `customer_Address` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_Id`, `customer_Fname`, `customer_Lname`, `Gender`, `customer_phonenumber`, `customer_Address`) VALUES
(1, 'Deny', 'UWIHIRWE', 'Male', '079000772', 'Gicumbi'),
(2, 'Janette', 'UWIHIRWE', 'male', '079000772', 'Gicumbi'),
(3, 'John', 'denzo', 'male', '07888888888', 'musanze'),
(4, 'Janine', 'UMURERWA', 'Female', '0782288888', 'Gikondo'),
(5, 'Jmukasa', 'manzi', 'male', '07338888888', 'Nyanza'),
(6, 'Josee', 'Iradukunda', 'Female', '0780088888', 'Muhanga'),
(1000, 'Susuruka', 'Samuel', 'Male', '0786409253', 'Rwamagana'),
(1122, 'Janette', 'UWIHIRWE', 'male', '079000772', 'Gicumbi'),
(1133, 'Ange', 'UMUHOZA', 'Female', '0783004772', 'GICUMBI'),
(1144, 'Enock', 'BYARUHANGA', 'Male', '078811772', 'GATSIBO'),
(1155, 'Fideli', 'HABAKURAMA', 'Male', '072000782', 'MUHANGA'),
(1166, 'Denys', 'UWAMURERA', 'FEmale', '073000112', 'KARONGI'),
(1177, 'Deni', 'UWIHIRWE', 'Male', '078000772', 'HUYE');

-- --------------------------------------------------------

--
-- Table structure for table `customer_view`
--

CREATE TABLE `customer_view` (
  `customer_Id` int(5) DEFAULT NULL,
  `customer_Fname` varchar(40) DEFAULT NULL,
  `customer_Lname` varchar(30) DEFAULT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `customer_phonenumber` varchar(15) DEFAULT NULL,
  `customer_Address` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_view`
--

CREATE TABLE `delivery_view` (
  `delivery_Id` int(10) DEFAULT NULL,
  `Address` varchar(20) DEFAULT NULL,
  `delivery_Date` date DEFAULT NULL,
  `customer_Id` int(10) DEFAULT NULL,
  `order_Id` int(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `food_view`
--

CREATE TABLE `food_view` (
  `food_Id` int(10) DEFAULT NULL,
  `food_Name` varchar(20) DEFAULT NULL,
  `food_Quality` varchar(10) DEFAULT NULL,
  `food_Quantity` varchar(10) DEFAULT NULL,
  `price` decimal(8,0) DEFAULT NULL,
  `total` decimal(8,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orderr_view`
--

CREATE TABLE `orderr_view` (
  `order_Id` int(4) DEFAULT NULL,
  `food_Id` int(10) DEFAULT NULL,
  `customer_Id` int(5) DEFAULT NULL,
  `orderDate` date DEFAULT NULL,
  `quantity` varchar(10) DEFAULT NULL,
  `seller_Id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment_view`
--

CREATE TABLE `payment_view` (
  `payId` int(5) DEFAULT NULL,
  `customer_Id` int(5) DEFAULT NULL,
  `order_Id` int(4) DEFAULT NULL,
  `amount` decimal(8,0) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `seller_view`
--

CREATE TABLE `seller_view` (
  `seller_Id` int(5) DEFAULT NULL,
  `seller_name` varchar(20) DEFAULT NULL,
  `seller_phone` int(12) DEFAULT NULL,
  `username` varchar(10) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1178;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
