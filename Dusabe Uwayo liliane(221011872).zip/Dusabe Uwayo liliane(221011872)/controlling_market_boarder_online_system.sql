-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2022 at 10:37 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `controlling market boarder online system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `clientp` ()   BEGIN
    select * from client;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `productp` (IN `PIDParam` INT(30))   BEGIN
    update procductp set PIDParam=PIDParam where PIDParam<=3216;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `receptionistp` (IN `RIDParam` INT(30))   BEGIN
    delete from receptionist where ridparam=32161;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `taxp` (IN `TIDParam` INT(30))   BEGIN
    delete from tax where Tidparam=3216;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Aid` int(15) NOT NULL,
  `L_name` varchar(90) NOT NULL,
  `F_name` varchar(90) NOT NULL,
  `Workplace` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Aid`, `L_name`, `F_name`, `Workplace`) VALUES
(12333, 'Mahoro', 'Jeanne', 'Rugari');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `Cid` int(15) NOT NULL,
  `Fname` varchar(40) NOT NULL,
  `Lname` varchar(40) NOT NULL,
  `Date` date NOT NULL,
  `Idnumber` int(16) NOT NULL,
  `Homeregion` varchar(25) NOT NULL,
  `Gender` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`Cid`, `Fname`, `Lname`, `Date`, `Idnumber`, `Homeregion`, `Gender`) VALUES
(1234, 'MUTOKAMBARI', 'Alphred', '2022-07-18', 1122345, 'Bwina', 'M');

--
-- Triggers `client`
--
DELIMITER $$
CREATE TRIGGER `clientT` AFTER INSERT ON `client` FOR EACH ROW BEGIN update CID set CID =CID+1; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `clienttm` AFTER DELETE ON `client` FOR EACH ROW BEGIN  
update homeregion set homeregion= bwina+RDC; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `clientview`
-- (See below for the actual view)
--
CREATE TABLE `clientview` (
`Cid` int(15)
,`Fname` varchar(40)
,`Lname` varchar(40)
,`Date` date
,`Idnumber` int(16)
,`Homeregion` varchar(25)
,`Gender` varchar(6)
);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Pid` int(15) NOT NULL,
  `Importproductname` varchar(40) NOT NULL,
  `productbuy` varchar(30) NOT NULL,
  `Quantityproduct` varchar(10) DEFAULT NULL,
  `Productsell` varchar(30) NOT NULL,
  `Date` date DEFAULT NULL,
  `Amountproduct` varchar(20) DEFAULT NULL,
  `Cid` int(15) NOT NULL,
  `tid` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Pid`, `Importproductname`, `productbuy`, `Quantityproduct`, `Productsell`, `Date`, `Amountproduct`, `Cid`, `tid`) VALUES
(9876, 'Coffe', 'rice, meat', '100kg', 'coffe', '2022-07-25', '1234000', 1234, 7654),
(9877, 'tea', 'rice, meat', '300kg', 'tea', '2022-07-27', '1234000', 1234, 7654);

--
-- Triggers `product`
--
DELIMITER $$
CREATE TRIGGER `productT` AFTER INSERT ON `product` FOR EACH ROW BEGIN update PID set PID =PID+1; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `productTM` AFTER UPDATE ON `product` FOR EACH ROW BEGIN  
update amountofproduct set amountofproduct = amountofproduct+ 3; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `productview`
-- (See below for the actual view)
--
CREATE TABLE `productview` (
`Pid` int(15)
,`Importproductname` varchar(40)
,`productbuy` varchar(30)
,`Quantityproduct` varchar(10)
,`Productsell` varchar(30)
,`Date` date
,`Amountproduct` varchar(20)
,`Cid` int(15)
,`tid` int(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `receptionist`
--

CREATE TABLE `receptionist` (
  `Rid` int(15) NOT NULL,
  `lname` varchar(90) NOT NULL,
  `fname` varchar(90) NOT NULL,
  `Regnumber` int(15) NOT NULL,
  `Date` date NOT NULL,
  `Workplace` varchar(40) NOT NULL,
  `Cid` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receptionist`
--

INSERT INTO `receptionist` (`Rid`, `lname`, `fname`, `Regnumber`, `Date`, `Workplace`, `Cid`) VALUES
(22345, 'Mwiza', 'Justine', 1122334, '2022-07-27', 'Rugari', 1234),
(22346, 'Justine', 'mwiza', 1122334, '2022-07-22', 'Rugari', 1234);

--
-- Triggers `receptionist`
--
DELIMITER $$
CREATE TRIGGER `receptionistt` AFTER DELETE ON `receptionist` FOR EACH ROW BEGIN  
update fname set fname= fname+lname; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `receptionistview`
-- (See below for the actual view)
--
CREATE TABLE `receptionistview` (
`Rid` int(15)
,`lname` varchar(90)
,`fname` varchar(90)
,`Regnumber` int(15)
,`Date` date
,`Workplace` varchar(40)
,`Cid` int(15)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `subqueries`
-- (See below for the actual view)
--
CREATE TABLE `subqueries` (
`lname` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `systemtable`
-- (See below for the actual view)
--
CREATE TABLE `systemtable` (
`Cid` int(15)
,`Fname` varchar(40)
,`Lname` varchar(40)
,`Date` date
,`Idnumber` int(16)
,`Homeregion` varchar(25)
,`Gender` varchar(6)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `systemtable1`
-- (See below for the actual view)
--
CREATE TABLE `systemtable1` (
`Tid` int(15)
,`Taxforproduct` varchar(5)
,`Lnameoftaxpayer` varchar(90)
,`Fnameoftaxpayer` varchar(90)
,`Date` date
,`Amountoftax` int(20)
,`Kindoftax` varchar(20)
,`Cid` int(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

CREATE TABLE `tax` (
  `Tid` int(15) NOT NULL,
  `Taxforproduct` varchar(5) NOT NULL,
  `Lnameoftaxpayer` varchar(90) NOT NULL,
  `Fnameoftaxpayer` varchar(90) NOT NULL,
  `Date` date DEFAULT NULL,
  `Amountoftax` int(20) NOT NULL,
  `Kindoftax` varchar(20) DEFAULT NULL,
  `Cid` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`Tid`, `Taxforproduct`, `Lnameoftaxpayer`, `Fnameoftaxpayer`, `Date`, `Amountoftax`, `Kindoftax`, `Cid`) VALUES
(7654, '5%', 'MUSHI', 'Alphred', '2022-07-18', 120000, 'umusoro kunyungu', 1234),
(7655, '5%', 'MUTOKAMBARI', 'Alphred', '2022-07-31', 2000, 'umusoro wisuku', 1234);

--
-- Triggers `tax`
--
DELIMITER $$
CREATE TRIGGER `taxT` AFTER UPDATE ON `tax` FOR EACH ROW BEGIN  
update kindoftax set kindoftax = kindoftax+ RRA; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `taxview`
-- (See below for the actual view)
--
CREATE TABLE `taxview` (
`Tid` int(15)
,`Taxforproduct` varchar(5)
,`Lnameoftaxpayer` varchar(90)
,`Fnameoftaxpayer` varchar(90)
,`Date` date
,`Amountoftax` int(20)
,`Kindoftax` varchar(20)
,`Cid` int(15)
);

-- --------------------------------------------------------

--
-- Structure for view `clientview`
--
DROP TABLE IF EXISTS `clientview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clientview`  AS SELECT `client`.`Cid` AS `Cid`, `client`.`Fname` AS `Fname`, `client`.`Lname` AS `Lname`, `client`.`Date` AS `Date`, `client`.`Idnumber` AS `Idnumber`, `client`.`Homeregion` AS `Homeregion`, `client`.`Gender` AS `Gender` FROM `client``client`  ;

-- --------------------------------------------------------

--
-- Structure for view `productview`
--
DROP TABLE IF EXISTS `productview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `productview`  AS SELECT `product`.`Pid` AS `Pid`, `product`.`Importproductname` AS `Importproductname`, `product`.`productbuy` AS `productbuy`, `product`.`Quantityproduct` AS `Quantityproduct`, `product`.`Productsell` AS `Productsell`, `product`.`Date` AS `Date`, `product`.`Amountproduct` AS `Amountproduct`, `product`.`Cid` AS `Cid`, `product`.`tid` AS `tid` FROM `product``product`  ;

-- --------------------------------------------------------

--
-- Structure for view `receptionistview`
--
DROP TABLE IF EXISTS `receptionistview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `receptionistview`  AS SELECT `receptionist`.`Rid` AS `Rid`, `receptionist`.`lname` AS `lname`, `receptionist`.`fname` AS `fname`, `receptionist`.`Regnumber` AS `Regnumber`, `receptionist`.`Date` AS `Date`, `receptionist`.`Workplace` AS `Workplace`, `receptionist`.`Cid` AS `Cid` FROM `receptionist``receptionist`  ;

-- --------------------------------------------------------

--
-- Structure for view `subqueries`
--
DROP TABLE IF EXISTS `subqueries`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subqueries`  AS SELECT `client`.`Fname` AS `lname` FROM `client` WHERE `client`.`Cid` = '1234''1234'  ;

-- --------------------------------------------------------

--
-- Structure for view `systemtable`
--
DROP TABLE IF EXISTS `systemtable`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `systemtable`  AS SELECT `receptionist`.`Cid` AS `Cid`, `receptionist`.`Fname` AS `Fname`, `receptionist`.`Lname` AS `Lname`, `receptionist`.`Date` AS `Date`, `receptionist`.`Idnumber` AS `Idnumber`, `receptionist`.`Homeregion` AS `Homeregion`, `receptionist`.`Gender` AS `Gender` FROM `client` AS `receptionist``receptionist`  ;

-- --------------------------------------------------------

--
-- Structure for view `systemtable1`
--
DROP TABLE IF EXISTS `systemtable1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `systemtable1`  AS SELECT `product`.`Tid` AS `Tid`, `product`.`Taxforproduct` AS `Taxforproduct`, `product`.`Lnameoftaxpayer` AS `Lnameoftaxpayer`, `product`.`Fnameoftaxpayer` AS `Fnameoftaxpayer`, `product`.`Date` AS `Date`, `product`.`Amountoftax` AS `Amountoftax`, `product`.`Kindoftax` AS `Kindoftax`, `product`.`Cid` AS `Cid` FROM `tax` AS `product``product`  ;

-- --------------------------------------------------------

--
-- Structure for view `taxview`
--
DROP TABLE IF EXISTS `taxview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `taxview`  AS SELECT `tax`.`Tid` AS `Tid`, `tax`.`Taxforproduct` AS `Taxforproduct`, `tax`.`Lnameoftaxpayer` AS `Lnameoftaxpayer`, `tax`.`Fnameoftaxpayer` AS `Fnameoftaxpayer`, `tax`.`Date` AS `Date`, `tax`.`Amountoftax` AS `Amountoftax`, `tax`.`Kindoftax` AS `Kindoftax`, `tax`.`Cid` AS `Cid` FROM `tax``tax`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Aid`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`Cid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Pid`),
  ADD KEY `product` (`Cid`),
  ADD KEY `tax` (`tid`);

--
-- Indexes for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD PRIMARY KEY (`Rid`),
  ADD KEY `Receptionist` (`Cid`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`Tid`),
  ADD KEY `client` (`Cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Aid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12334;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `Cid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1236;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Pid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9878;

--
-- AUTO_INCREMENT for table `receptionist`
--
ALTER TABLE `receptionist`
  MODIFY `Rid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22347;

--
-- AUTO_INCREMENT for table `tax`
--
ALTER TABLE `tax`
  MODIFY `Tid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7656;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product` FOREIGN KEY (`Cid`) REFERENCES `client` (`Cid`),
  ADD CONSTRAINT `tax` FOREIGN KEY (`tid`) REFERENCES `tax` (`Tid`);

--
-- Constraints for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD CONSTRAINT `Receptionist` FOREIGN KEY (`Cid`) REFERENCES `client` (`Cid`);

--
-- Constraints for table `tax`
--
ALTER TABLE `tax`
  ADD CONSTRAINT `client` FOREIGN KEY (`Cid`) REFERENCES `client` (`Cid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
