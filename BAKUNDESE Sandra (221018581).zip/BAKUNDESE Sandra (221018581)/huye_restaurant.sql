-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 05:56 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `huye_restaurant`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `amount_AVG` ()  SELECT * FROM payment WHERE Amount>(SELECT AVG(Amount) FROM payment)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_client` (`Client_Id` VARCHAR(20))  DELETE FROM client WHERE Client_Id=Client_Id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertclient` (`Client_Id` VARCHAR(20), `Client_Names` VARCHAR(20), `Amount` VARCHAR(20), `Type` VARCHAR(20), `Date` DATE)  insert into client values (Client_Id,Client_Names,Amount, Type, Date)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `the_list_of_client` ()  SELECT * FROM client$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_client` (`Client_Id` VARCHAR(20), `Client_Names` VARCHAR(20))  UPDATE client SET Client_Id=Client_Id WHERE Client_Names=Client_Names$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `Client_Id` varchar(20) NOT NULL,
  `Client_Names` varchar(20) NOT NULL,
  `Amount` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`Client_Id`, `Client_Names`, `Amount`, `Type`, `Date`) VALUES
('001', 'Bakundese', '55555', 'VIP', '2022-07-18'),
('002', 'Bakundese Sandra', '30000', 'VIP', '2022-07-18');

--
-- Triggers `client`
--
DELIMITER $$
CREATE TRIGGER `del_trigger` AFTER DELETE ON `client` FOR EACH ROW DELETE FROM clients WHERE Client_Id=002
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insert_trigger` AFTER INSERT ON `client` FOR EACH ROW INSERT INTO client VALUES(Client_Id,Client_Names,Amount,Type,Date)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_trigger` AFTER UPDATE ON `client` FOR EACH ROW UPDATE client SET Type='Regular'where Client_Id=002
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `client_view`
-- (See below for the actual view)
--
CREATE TABLE `client_view` (
`Client_Id` varchar(20)
,`Client_Names` varchar(20)
,`Amount` varchar(20)
,`Type` varchar(20)
,`Date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Manager_Id` varchar(20) NOT NULL,
  `Client_Id` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Mealcard_Id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `manager_view`
-- (See below for the actual view)
--
CREATE TABLE `manager_view` (
`Manager_Id` varchar(20)
,`Client_Id` varchar(20)
,`Type` varchar(20)
,`Mealcard_Id` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `mealcard`
--

CREATE TABLE `mealcard` (
  `Client_Id` varchar(20) NOT NULL,
  `Mealcard_Id` varchar(20) NOT NULL,
  `Days_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mealcard`
--

INSERT INTO `mealcard` (`Client_Id`, `Mealcard_Id`, `Days_Date`) VALUES
('002', '101', '2022-07-18');

-- --------------------------------------------------------

--
-- Stand-in structure for view `mealcard_view`
-- (See below for the actual view)
--
CREATE TABLE `mealcard_view` (
`Client_Id` varchar(20)
,`Mealcard_Id` varchar(20)
,`Days_Date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Client_Id` varchar(20) NOT NULL,
  `Date_created` date NOT NULL,
  `Amount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Client_Id`, `Date_created`, `Amount`) VALUES
('002', '2022-07-18', '30000'),
('001', '2022-07-18', '7000');

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `pay_trigger` AFTER INSERT ON `payment` FOR EACH ROW INSERT INTO payment VALUES(Client_Id,Date_created,Amount)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `payment_view`
-- (See below for the actual view)
--
CREATE TABLE `payment_view` (
);

-- --------------------------------------------------------

--
-- Structure for view `client_view`
--
DROP TABLE IF EXISTS `client_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `client_view`  AS  select `client`.`Client_Id` AS `Client_Id`,`client`.`Client_Names` AS `Client_Names`,`client`.`Amount` AS `Amount`,`client`.`Type` AS `Type`,`client`.`Date` AS `Date` from `client` ;

-- --------------------------------------------------------

--
-- Structure for view `manager_view`
--
DROP TABLE IF EXISTS `manager_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `manager_view`  AS  select `manager`.`Manager_Id` AS `Manager_Id`,`manager`.`Client_Id` AS `Client_Id`,`manager`.`Type` AS `Type`,`manager`.`Mealcard_Id` AS `Mealcard_Id` from `manager` ;

-- --------------------------------------------------------

--
-- Structure for view `mealcard_view`
--
DROP TABLE IF EXISTS `mealcard_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `mealcard_view`  AS  select `mealcard`.`Client_Id` AS `Client_Id`,`mealcard`.`Mealcard_Id` AS `Mealcard_Id`,`mealcard`.`Days_Date` AS `Days_Date` from `mealcard` ;

-- --------------------------------------------------------

--
-- Structure for view `payment_view`
--
DROP TABLE IF EXISTS `payment_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payment_view`  AS  select `payment`.`Client-Id` AS `Client-Id`,`payment`.`Date_created` AS `Date_created`,`payment`.`Amount` AS `Amount` from `payment` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`Client_Id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`Manager_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
